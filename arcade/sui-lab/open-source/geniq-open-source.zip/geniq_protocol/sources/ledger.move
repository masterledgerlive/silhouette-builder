/// GENIQ ledger — the chain layer (L0) of the GENIQ protocol.
///
/// GENIQ is a closed-loop compute credit metered against real quantum-compute
/// jobs (priced in HQCs). It is NOT a coin: no `Coin<GENIQ>` object ever
/// exists. Balances are numbers inside one shared `Ledger` object, so
/// transfer between users is impossible at the type level — there is no
/// transfer function in this module, by design, forever.
///
/// Authorities are capabilities, not addresses:
/// - `MintCap`   — the only way GENIQ comes into existence (issuance against
///   payment, per the v2 design; held by the issuing service).
/// - `SettleCap` — the only way reserved GENIQ is burned (on verified
///   delivery) or receipts are issued. Held by the Lamp. It cannot move a
///   balance from one user to another; no such operation exists.
///
/// Spending flows through a `SpendingCap` the user owns: per-transaction and
/// per-epoch ceilings enforced HERE, in Move, so an agent (or a jailbroken
/// agent front end) cannot overspend no matter what it asks for — the
/// protocol refuses.
module geniq_protocol::ledger;

use sui::table::{Self, Table};

// ===== Errors =====
const EInsufficientBalance: u64 = 1;
const EInsufficientReserved: u64 = 2;
const EPerTxCapExceeded: u64 = 3;
const EPeriodCapExceeded: u64 = 4;
const ENotCapOwner: u64 = 5;
const EZeroAmount: u64 = 6;
const EPaused: u64 = 7;
const EBadEscrowState: u64 = 8;
const EOverTolerance: u64 = 9;

// ===== Objects =====

/// The single shared ledger. Balances and escrow reservations live here and
/// nowhere else.
public struct Ledger has key {
    id: UID,
    balances: Table<address, u64>,
    reserved: Table<address, u64>,
    total_minted: u64,
    total_burned: u64,
    /// Emergency stop, flipped only by PauseCap. While paused: no mint, no
    /// new reserves, no settles. Releases ALWAYS work — user funds can
    /// always escape.
    paused: bool,
}

/// Emergency-stop capability, owner-held (David), separate from the Lamp's
/// operational caps: the Lamp cannot unpause what it did not pause.
public struct PauseCap has key, store { id: UID }

/// One escrow lock for one job — the on-chain state machine the review
/// panel demanded (Unused is implicit: the object is born Locked).
/// LOCKED (0) -> SETTLED (1) | RELEASED (2). Terminal states are final:
/// a settled escrow can never be released, a released one never settled,
/// and neither can settle twice. The lock's lifetime is the JOB's lifetime
/// (hardware queues run days to weeks) — the v2 hole where a quote expired
/// mid-queue and left a running job unescrowed cannot happen here, because
/// the lock does not expire; the job's own deadline discipline (Lamp-side
/// timeout -> release) closes it.
public struct Escrow has key {
    id: UID,
    owner: address,
    /// GENIQ locked (the quoted charge).
    amount: u64,
    /// The quote this lock binds to, in milli-HQC.
    hqc_quoted_milli: u64,
    state: u8,
    /// GENIQ actually burned at settlement (0 until settled).
    burned: u64,
}

/// Restricted issuance capability. Mint-only: holding it grants no power
/// over existing balances.
public struct MintCap has key, store { id: UID }

/// Restricted settlement capability: burn reserved funds on verified
/// delivery, release them on failure/cancel/timeout, issue receipts.
/// Cannot mint, cannot move balances between users.
public struct SettleCap has key, store { id: UID }

/// A user's spending ceiling, enforced by `reserve`. Owned by the user; the
/// agent acts under it. Revocable by destroying it (owner only) — a revoked
/// cap means the agent can spend nothing further.
public struct SpendingCap has key {
    id: UID,
    owner: address,
    per_tx_cap: u64,
    period_cap: u64,
    period_epoch: u64,
    period_spent: u64,
}

// ===== Init =====

fun init(ctx: &mut TxContext) {
    let ledger = Ledger {
        id: object::new(ctx),
        balances: table::new(ctx),
        reserved: table::new(ctx),
        total_minted: 0,
        total_burned: 0,
        paused: false,
    };
    transfer::share_object(ledger);
    transfer::transfer(MintCap { id: object::new(ctx) }, ctx.sender());
    transfer::transfer(SettleCap { id: object::new(ctx) }, ctx.sender());
    transfer::transfer(PauseCap { id: object::new(ctx) }, ctx.sender());
}

// ===== Helpers =====

fun bal(t: &Table<address, u64>, a: address): u64 {
    if (t.contains(a)) *t.borrow(a) else 0
}

fun set(t: &mut Table<address, u64>, a: address, v: u64) {
    if (t.contains(a)) *t.borrow_mut(a) = v else t.add(a, v)
}

// ===== Issuance (MintCap only) =====

/// The ONLY way GENIQ comes into existence. V2 rule: mint only against
/// payment received off-chain; this function is the on-chain half of that
/// rule and it has no other caller path.
public fun mint(_cap: &MintCap, ledger: &mut Ledger, to: address, amount: u64) {
    assert!(!ledger.paused, EPaused);
    assert!(amount > 0, EZeroAmount);
    let new_bal = bal(&ledger.balances, to) + amount;
    set(&mut ledger.balances, to, new_bal);
    ledger.total_minted = ledger.total_minted + amount;
}

// ===== Spending caps =====

public fun create_spending_cap(
    per_tx_cap: u64,
    period_cap: u64,
    ctx: &mut TxContext,
) {
    let cap = SpendingCap {
        id: object::new(ctx),
        owner: ctx.sender(),
        per_tx_cap,
        period_cap,
        period_epoch: ctx.epoch(),
        period_spent: 0,
    };
    transfer::transfer(cap, ctx.sender());
}

/// Owner-only revocation: destroy the cap and the agent's spending power
/// with it.
public fun revoke_spending_cap(cap: SpendingCap, ctx: &TxContext) {
    assert!(cap.owner == ctx.sender(), ENotCapOwner);
    let SpendingCap { id, owner: _, per_tx_cap: _, period_cap: _,
                      period_epoch: _, period_spent: _ } = cap;
    id.delete();
}

fun authorize(cap: &mut SpendingCap, amount: u64, ctx: &TxContext) {
    assert!(amount <= cap.per_tx_cap, EPerTxCapExceeded);
    let e = ctx.epoch();
    if (e > cap.period_epoch) {
        cap.period_epoch = e;
        cap.period_spent = 0;
    };
    assert!(cap.period_spent + amount <= cap.period_cap, EPeriodCapExceeded);
    cap.period_spent = cap.period_spent + amount;
}

// ===== Pause (PauseCap only, owner-held) =====

public fun pause(_cap: &PauseCap, ledger: &mut Ledger) { ledger.paused = true }
public fun unpause(_cap: &PauseCap, ledger: &mut Ledger) { ledger.paused = false }
public fun is_paused(ledger: &Ledger): bool { ledger.paused }

// ===== Escrow: reserve -> settle (burn at verified price) | release =====

/// Lock the sender's GENIQ against a quoted job and create its Escrow.
/// Requires the sender's own SpendingCap — the protocol, not the agent,
/// enforces the ceilings. The escrow binds the quote (milli-HQC) so the
/// settlement price is verifiable on-chain later.
public fun reserve(
    ledger: &mut Ledger,
    cap: &mut SpendingCap,
    amount: u64,
    hqc_quoted_milli: u64,
    ctx: &mut TxContext,
) {
    assert!(!ledger.paused, EPaused);
    assert!(amount > 0, EZeroAmount);
    let a = ctx.sender();
    assert!(cap.owner == a, ENotCapOwner);
    authorize(cap, amount, ctx);
    let b = bal(&ledger.balances, a);
    assert!(b >= amount, EInsufficientBalance);
    set(&mut ledger.balances, a, b - amount);
    let new_res = bal(&ledger.reserved, a) + amount;
    set(&mut ledger.reserved, a, new_res);
    let esc = Escrow {
        id: object::new(ctx),
        owner: a,
        amount,
        hqc_quoted_milli,
        state: 0,
        burned: 0,
    };
    transfer::share_object(esc);
}

/// Settle an escrow on verified delivery. THE PRICE RULE IS VERIFIED HERE,
/// in Move, not trusted from the Lamp: settlement is legal only when the
/// actual cost is within the published tolerance of the quote (actual <=
/// 1.2 x quoted, integer-checked as actual*5 <= quoted*6). On success the
/// full locked charge burns — the quote IS the price (the v2 rule, and the
/// price the user saw). Out-of-tolerance actuals are refused here; the
/// Lamp's response is abort + full release, also enforced here (release is
/// the only other transition, and only from LOCKED).
public fun settle(
    _cap: &SettleCap,
    ledger: &mut Ledger,
    esc: &mut Escrow,
    hqc_actual_milli: u64,
) {
    assert!(!ledger.paused, EPaused);
    assert!(esc.state == 0, EBadEscrowState);
    assert!(hqc_actual_milli * 5 <= esc.hqc_quoted_milli * 6, EOverTolerance);
    let owner = esc.owner;
    let r = bal(&ledger.reserved, owner);
    assert!(r >= esc.amount, EInsufficientReserved);
    set(&mut ledger.reserved, owner, r - esc.amount);
    ledger.total_burned = ledger.total_burned + esc.amount;
    esc.burned = esc.amount;
    esc.state = 1;
}

/// Return the whole lock to the owner — failure, cancellation, timeout, or
/// cost-divergence abort. Full release is the v2 rule for every
/// non-delivery path, and release is NEVER blocked by the pause: user
/// funds can always escape.
public fun release(_cap: &SettleCap, ledger: &mut Ledger, esc: &mut Escrow) {
    assert!(esc.state == 0, EBadEscrowState);
    let owner = esc.owner;
    let r = bal(&ledger.reserved, owner);
    assert!(r >= esc.amount, EInsufficientReserved);
    set(&mut ledger.reserved, owner, r - esc.amount);
    let new_bal = bal(&ledger.balances, owner) + esc.amount;
    set(&mut ledger.balances, owner, new_bal);
    esc.state = 2;
}

// ===== Escrow views =====

public fun escrow_owner(esc: &Escrow): address { esc.owner }
public fun escrow_amount(esc: &Escrow): u64 { esc.amount }
public fun escrow_state(esc: &Escrow): u8 { esc.state }
public fun escrow_burned(esc: &Escrow): u64 { esc.burned }
public fun escrow_quoted_milli(esc: &Escrow): u64 { esc.hqc_quoted_milli }

// ===== Views =====

public fun balance_of(ledger: &Ledger, a: address): u64 { bal(&ledger.balances, a) }
public fun reserved_of(ledger: &Ledger, a: address): u64 { bal(&ledger.reserved, a) }
public fun total_minted(ledger: &Ledger): u64 { ledger.total_minted }
public fun total_burned(ledger: &Ledger): u64 { ledger.total_burned }

// ===== Test-only scaffolding =====

#[test_only]
public fun init_for_testing(ctx: &mut TxContext) { init(ctx) }
