/// GENIQ receipts — proof-of-delivery objects.
///
/// A Receipt carries ONLY a salted commitment to the result plus the meter
/// readings (HQC quoted/actual in milli-HQC, GENIQ charged). No question
/// text, no circuit, no raw result — a bare result hash for a low-entropy
/// answer would be brute-forceable, so the commitment is salted off-chain
/// by the Lamp and only the commitment lands here (v2 decision D18).
///
/// Receipts have `key` only (no `store`): they cannot be publicly
/// transferred, wrapped, or traded. Soulbound to the caller who paid.
module geniq_protocol::receipts;

use geniq_protocol::ledger::SettleCap;

public struct Receipt has key {
    id: UID,
    /// sha256 commitment to the delivered result (salt held off-chain).
    result_commitment: vector<u8>,
    /// Meter readings, milli-HQC (HQC x 1000) to stay in integers.
    hqc_quoted_milli: u64,
    hqc_actual_milli: u64,
    /// GENIQ burned for this job (the settled charge).
    charge_geniq: u64,
    /// 0 = emulator, 1 = hardware.
    backend: u8,
    /// Epoch at settlement.
    settled_epoch: u64,
}

/// Issue a receipt to the caller. Settlement authority only — a receipt is
/// minted at the same moment the escrow settles, never before delivery.
public fun issue_receipt(
    _cap: &SettleCap,
    recipient: address,
    result_commitment: vector<u8>,
    hqc_quoted_milli: u64,
    hqc_actual_milli: u64,
    charge_geniq: u64,
    backend: u8,
    ctx: &mut TxContext,
) {
    let r = Receipt {
        id: object::new(ctx),
        result_commitment,
        hqc_quoted_milli,
        hqc_actual_milli,
        charge_geniq,
        backend,
        settled_epoch: ctx.epoch(),
    };
    transfer::transfer(r, recipient);
}

// ===== Views =====

public fun commitment(r: &Receipt): vector<u8> { r.result_commitment }
public fun hqc_quoted_milli(r: &Receipt): u64 { r.hqc_quoted_milli }
public fun hqc_actual_milli(r: &Receipt): u64 { r.hqc_actual_milli }
public fun charge_geniq(r: &Receipt): u64 { r.charge_geniq }
public fun backend(r: &Receipt): u8 { r.backend }
