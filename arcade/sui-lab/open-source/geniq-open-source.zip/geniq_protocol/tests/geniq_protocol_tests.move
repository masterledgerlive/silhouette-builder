#[test_only]
module geniq_protocol::geniq_protocol_tests;

use sui::test_scenario as ts;
use geniq_protocol::ledger::{Self, Ledger, MintCap, SettleCap, PauseCap, SpendingCap, Escrow};
use geniq_protocol::receipts::{Self, Receipt};

const ADMIN: address = @0xAD;      // package publisher; holds Mint/Settle/Pause caps in tests
const ALICE: address = @0xA11CE;
const BOB: address = @0xB0B;

// abort codes from ledger.move
const E_INSUF_BAL: u64 = 1;
const E_PER_TX: u64 = 3;
const E_PERIOD: u64 = 4;
const E_PAUSED: u64 = 7;
const E_BAD_STATE: u64 = 8;
const E_OVER_TOL: u64 = 9;

fun setup(sc: &mut ts::Scenario) {
    ledger::init_for_testing(sc.ctx());
    sc.next_tx(ADMIN);
}

fun mint_to(sc: &mut ts::Scenario, to: address, amount: u64) {
    let mut led = sc.take_shared<Ledger>();
    let cap = sc.take_from_sender<MintCap>();
    ledger::mint(&cap, &mut led, to, amount);
    sc.return_to_sender(cap);
    ts::return_shared(led);
    sc.next_tx(ADMIN);
}

/// ALICE creates a spending cap, then reserves `amount` against a quote of
/// `quoted_milli` milli-HQC. Leaves the scenario at ALICE's next tx; the
/// Escrow is the most recent shared object.
fun alice_reserve(sc: &mut ts::Scenario, per_tx: u64, period: u64, amount: u64, quoted_milli: u64) {
    sc.next_tx(ALICE);
    ledger::create_spending_cap(per_tx, period, sc.ctx());
    sc.next_tx(ALICE);
    let mut led = sc.take_shared<Ledger>();
    let mut cap = sc.take_from_sender<SpendingCap>();
    ledger::reserve(&mut led, &mut cap, amount, quoted_milli, sc.ctx());
    sc.return_to_sender(cap);
    ts::return_shared(led);
    sc.next_tx(ALICE);
}

#[test]
fun mint_and_balance() {
    let mut sc = ts::begin(ADMIN);
    setup(&mut sc);
    mint_to(&mut sc, ALICE, 1000);
    let led = sc.take_shared<Ledger>();
    assert!(ledger::balance_of(&led, ALICE) == 1000);
    assert!(ledger::total_minted(&led) == 1000);
    assert!(ledger::total_burned(&led) == 0);
    ts::return_shared(led);
    sc.end();
}

#[test]
fun reserve_then_settle_burns_and_conserves() {
    let mut sc = ts::begin(ADMIN);
    setup(&mut sc);
    mint_to(&mut sc, ALICE, 1000);
    // quote 100 HQC (100_000 milli) -> charge ceil(100 x 1.2) = 120
    alice_reserve(&mut sc, 200, 500, 120, 100_000);
    {
        let led = sc.take_shared<Ledger>();
        assert!(ledger::balance_of(&led, ALICE) == 880);
        assert!(ledger::reserved_of(&led, ALICE) == 120);
        ts::return_shared(led);
    };
    sc.next_tx(ADMIN);
    {
        let mut led = sc.take_shared<Ledger>();
        let mut esc = sc.take_shared<Escrow>();
        let scap = sc.take_from_sender<SettleCap>();
        // actual == quoted: inside tolerance, full locked charge burns
        ledger::settle(&scap, &mut led, &mut esc, 100_000);
        assert!(ledger::escrow_state(&esc) == 1);
        assert!(ledger::escrow_burned(&esc) == 120);
        assert!(ledger::reserved_of(&led, ALICE) == 0);
        assert!(ledger::total_burned(&led) == 120);
        let total = ledger::balance_of(&led, ALICE) + ledger::reserved_of(&led, ALICE)
                  + ledger::total_burned(&led);
        assert!(total == ledger::total_minted(&led));
        sc.return_to_sender(scap);
        ts::return_shared(esc);
        ts::return_shared(led);
    };
    sc.end();
}

#[test]
fun reserve_then_release_restores() {
    let mut sc = ts::begin(ADMIN);
    setup(&mut sc);
    mint_to(&mut sc, ALICE, 300);
    alice_reserve(&mut sc, 200, 500, 75, 62_500);
    sc.next_tx(ADMIN);
    {
        let mut led = sc.take_shared<Ledger>();
        let mut esc = sc.take_shared<Escrow>();
        let scap = sc.take_from_sender<SettleCap>();
        ledger::release(&scap, &mut led, &mut esc);
        assert!(ledger::escrow_state(&esc) == 2);
        assert!(ledger::balance_of(&led, ALICE) == 300);
        assert!(ledger::reserved_of(&led, ALICE) == 0);
        assert!(ledger::total_burned(&led) == 0);
        sc.return_to_sender(scap);
        ts::return_shared(esc);
        ts::return_shared(led);
    };
    sc.end();
}

#[test, expected_failure(abort_code = E_PER_TX, location = geniq_protocol::ledger)]
fun per_tx_cap_aborts() {
    let mut sc = ts::begin(ADMIN);
    setup(&mut sc);
    mint_to(&mut sc, ALICE, 1000);
    alice_reserve(&mut sc, 50, 500, 51, 1_000_000); // 51 > per-tx 50 -> abort
    abort 999
}

#[test, expected_failure(abort_code = E_PERIOD, location = geniq_protocol::ledger)]
fun period_cap_aborts() {
    let mut sc = ts::begin(ADMIN);
    setup(&mut sc);
    mint_to(&mut sc, ALICE, 1000);
    alice_reserve(&mut sc, 100, 150, 100, 1_000_000);
    // second reserve in the same epoch: 100 + 60 > period 150 -> abort
    let mut led = sc.take_shared<Ledger>();
    let mut cap = sc.take_from_sender<SpendingCap>();
    ledger::reserve(&mut led, &mut cap, 60, 1_000_000, sc.ctx());
    abort 999
}

#[test, expected_failure(abort_code = E_INSUF_BAL, location = geniq_protocol::ledger)]
fun reserve_more_than_balance_aborts() {
    let mut sc = ts::begin(ADMIN);
    setup(&mut sc);
    mint_to(&mut sc, ALICE, 40);
    alice_reserve(&mut sc, 200, 500, 41, 1_000_000);
    abort 999
}

#[test, expected_failure(abort_code = E_OVER_TOL, location = geniq_protocol::ledger)]
fun settle_over_tolerance_aborts() {
    let mut sc = ts::begin(ADMIN);
    setup(&mut sc);
    mint_to(&mut sc, ALICE, 100);
    // documented example: quote 5.66 HQC -> charge 7
    alice_reserve(&mut sc, 200, 500, 7, 5660);
    sc.next_tx(ADMIN);
    let mut led = sc.take_shared<Ledger>();
    let mut esc = sc.take_shared<Escrow>();
    let scap = sc.take_from_sender<SettleCap>();
    // actual 7.0 HQC: 7000*5 = 35000 > 5660*6 = 33960 -> protocol refuses
    ledger::settle(&scap, &mut led, &mut esc, 7000);
    abort 999
}

#[test]
fun settle_at_tolerance_boundary_ok() {
    let mut sc = ts::begin(ADMIN);
    setup(&mut sc);
    mint_to(&mut sc, ALICE, 100);
    alice_reserve(&mut sc, 200, 500, 7, 5660);
    sc.next_tx(ADMIN);
    {
        let mut led = sc.take_shared<Ledger>();
        let mut esc = sc.take_shared<Escrow>();
        let scap = sc.take_from_sender<SettleCap>();
        // actual 6.792 HQC = exactly 1.2 x quote: 6792*5 = 33960 <= 33960 OK
        ledger::settle(&scap, &mut led, &mut esc, 6792);
        assert!(ledger::escrow_state(&esc) == 1);
        assert!(ledger::total_burned(&led) == 7);
        sc.return_to_sender(scap);
        ts::return_shared(esc);
        ts::return_shared(led);
    };
    sc.end();
}

#[test, expected_failure(abort_code = E_BAD_STATE, location = geniq_protocol::ledger)]
fun double_settle_aborts() {
    let mut sc = ts::begin(ADMIN);
    setup(&mut sc);
    mint_to(&mut sc, ALICE, 100);
    alice_reserve(&mut sc, 200, 500, 7, 5660);
    sc.next_tx(ADMIN);
    {
        let mut led = sc.take_shared<Ledger>();
        let mut esc = sc.take_shared<Escrow>();
        let scap = sc.take_from_sender<SettleCap>();
        ledger::settle(&scap, &mut led, &mut esc, 5660);
        sc.return_to_sender(scap);
        ts::return_shared(esc);
        ts::return_shared(led);
    };
    sc.next_tx(ADMIN);
    let mut led = sc.take_shared<Ledger>();
    let mut esc = sc.take_shared<Escrow>();
    let scap = sc.take_from_sender<SettleCap>();
    ledger::settle(&scap, &mut led, &mut esc, 5660); // already settled -> abort
    abort 999
}

#[test, expected_failure(abort_code = E_BAD_STATE, location = geniq_protocol::ledger)]
fun release_after_settle_aborts() {
    let mut sc = ts::begin(ADMIN);
    setup(&mut sc);
    mint_to(&mut sc, ALICE, 100);
    alice_reserve(&mut sc, 200, 500, 7, 5660);
    sc.next_tx(ADMIN);
    {
        let mut led = sc.take_shared<Ledger>();
        let mut esc = sc.take_shared<Escrow>();
        let scap = sc.take_from_sender<SettleCap>();
        ledger::settle(&scap, &mut led, &mut esc, 5660);
        sc.return_to_sender(scap);
        ts::return_shared(esc);
        ts::return_shared(led);
    };
    sc.next_tx(ADMIN);
    let mut led = sc.take_shared<Ledger>();
    let mut esc = sc.take_shared<Escrow>();
    let scap = sc.take_from_sender<SettleCap>();
    ledger::release(&scap, &mut led, &mut esc); // settled is final -> abort
    abort 999
}

#[test]
fun pause_blocks_reserve_but_release_still_escapes() {
    let mut sc = ts::begin(ADMIN);
    setup(&mut sc);
    mint_to(&mut sc, ALICE, 300);
    alice_reserve(&mut sc, 200, 500, 75, 62_500);
    sc.next_tx(ADMIN);
    {
        let mut led = sc.take_shared<Ledger>();
        let pcap = sc.take_from_sender<PauseCap>();
        ledger::pause(&pcap, &mut led);
        assert!(ledger::is_paused(&led));
        sc.return_to_sender(pcap);
        ts::return_shared(led);
    };
    // release works while paused — user funds always escape
    sc.next_tx(ADMIN);
    {
        let mut led = sc.take_shared<Ledger>();
        let mut esc = sc.take_shared<Escrow>();
        let scap = sc.take_from_sender<SettleCap>();
        ledger::release(&scap, &mut led, &mut esc);
        assert!(ledger::balance_of(&led, ALICE) == 300);
        sc.return_to_sender(scap);
        ts::return_shared(esc);
        ts::return_shared(led);
    };
    sc.end();
}

#[test, expected_failure(abort_code = E_PAUSED, location = geniq_protocol::ledger)]
fun reserve_while_paused_aborts() {
    let mut sc = ts::begin(ADMIN);
    setup(&mut sc);
    mint_to(&mut sc, ALICE, 300);
    sc.next_tx(ADMIN);
    {
        let mut led = sc.take_shared<Ledger>();
        let pcap = sc.take_from_sender<PauseCap>();
        ledger::pause(&pcap, &mut led);
        sc.return_to_sender(pcap);
        ts::return_shared(led);
    };
    alice_reserve(&mut sc, 200, 500, 10, 1_000_000); // paused -> abort
    abort 999
}

#[test]
fun receipt_issued_on_settle_with_documented_example() {
    let mut sc = ts::begin(ADMIN);
    setup(&mut sc);
    mint_to(&mut sc, ALICE, 500);
    alice_reserve(&mut sc, 200, 500, 7, 5660);
    sc.next_tx(ADMIN);
    {
        let mut led = sc.take_shared<Ledger>();
        let mut esc = sc.take_shared<Escrow>();
        let scap = sc.take_from_sender<SettleCap>();
        ledger::settle(&scap, &mut led, &mut esc, 5660);
        // the documented 5.66 HQC example: quoted 5660 milli, actual 5660, charge 7 GENIQ, hardware
        receipts::issue_receipt(&scap, ALICE, x"deadbeef", 5660, 5660, 7, 1, sc.ctx());
        sc.return_to_sender(scap);
        ts::return_shared(esc);
        ts::return_shared(led);
    };
    sc.next_tx(ALICE);
    {
        let r = sc.take_from_sender<Receipt>();
        assert!(receipts::commitment(&r) == x"deadbeef");
        assert!(receipts::hqc_quoted_milli(&r) == 5660);
        assert!(receipts::charge_geniq(&r) == 7);
        assert!(receipts::backend(&r) == 1);
        sc.return_to_sender(r);
    };
    sc.end();
}

#[test]
fun two_users_isolated_and_conservation() {
    let mut sc = ts::begin(ADMIN);
    setup(&mut sc);
    mint_to(&mut sc, ALICE, 1000);
    mint_to(&mut sc, BOB, 500);
    // Bob runs two jobs: escrow 100 (settles) + escrow 150 (releases)
    sc.next_tx(BOB);
    ledger::create_spending_cap(300, 900, sc.ctx());
    sc.next_tx(BOB);
    {
        let mut led = sc.take_shared<Ledger>();
        let mut cap = sc.take_from_sender<SpendingCap>();
        ledger::reserve(&mut led, &mut cap, 100, 1_000_000, sc.ctx());
        ledger::reserve(&mut led, &mut cap, 150, 1_000_000, sc.ctx());
        assert!(ledger::balance_of(&led, ALICE) == 1000);
        assert!(ledger::reserved_of(&led, ALICE) == 0);
        assert!(ledger::balance_of(&led, BOB) == 250);
        sc.return_to_sender(cap);
        ts::return_shared(led);
    };
    sc.next_tx(ADMIN);
    {
        let mut led = sc.take_shared<Ledger>();
        let scap = sc.take_from_sender<SettleCap>();
        // most-recent escrow is the 150 one: release it; then the 100 one settles
        let mut esc150 = sc.take_shared<Escrow>();
        assert!(ledger::escrow_amount(&esc150) == 150);
        ledger::release(&scap, &mut led, &mut esc150);
        ts::return_shared(esc150);
        let mut esc100 = sc.take_shared<Escrow>();
        assert!(ledger::escrow_amount(&esc100) == 100);
        ledger::settle(&scap, &mut led, &mut esc100, 900_000);
        ts::return_shared(esc100);
        let total = ledger::balance_of(&led, ALICE) + ledger::balance_of(&led, BOB)
                  + ledger::reserved_of(&led, ALICE) + ledger::reserved_of(&led, BOB)
                  + ledger::total_burned(&led);
        assert!(total == ledger::total_minted(&led));
        assert!(ledger::balance_of(&led, BOB) == 400);
        sc.return_to_sender(scap);
        ts::return_shared(led);
    };
    sc.end();
}

#[test]
fun cap_revocation_ends_spending_power() {
    let mut sc = ts::begin(ADMIN);
    setup(&mut sc);
    mint_to(&mut sc, ALICE, 100);
    sc.next_tx(ALICE);
    ledger::create_spending_cap(50, 50, sc.ctx());
    sc.next_tx(ALICE);
    {
        let cap = sc.take_from_sender<SpendingCap>();
        ledger::revoke_spending_cap(cap, sc.ctx());
        assert!(!sc.has_most_recent_for_sender<SpendingCap>());
    };
    sc.end();
}
