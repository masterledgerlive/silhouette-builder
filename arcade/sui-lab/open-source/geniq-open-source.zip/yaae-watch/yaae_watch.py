#!/usr/bin/env python3
"""Yaae's Watch — local results-queue watcher (prototype, internal only).

Pipeline position (HIVE-AND-KIDS-DESIGN §5): result settles -> receipt lands
in the queue -> watcher verifies it -> Yaae files a learning note -> a
peer-review podcast entry is queued for the runner.

This build is the LOCAL prototype of that watcher: folders stand in for the
Walrus blob queue, a JSONL file stands in for the podcast trigger queue.
Nothing here touches a network, a chain, or a wallet.

Receipt hash rule: sha256 over the compact JSON of the receipt WITHOUT its
"hash" field, keys in file order, UTF-8 — the same construction the Kids Lab
and the Gateway page use (sim.js sha256 over JSON.stringify).
"""
import hashlib
import json
import sys
from datetime import datetime, timezone
from pathlib import Path

BASE = Path(__file__).resolve().parent
INBOX = BASE / "inbox"
PROCESSED = BASE / "processed"
STATE = BASE / "state.json"
WATCH_LOG = BASE / "watch-log.md"
PODCAST_QUEUE = BASE / "podcast-queue.jsonl"

REVIEW_ASKS = [
    "Did the classical cross-check agree with the quantum result?",
    "What result would have proven this run WRONG?",
    "Do the counts match the promised physics (within luck-of-the-flip)?",
]

NOTES = {
    "coin": "Randomness, witnessed and counted — entropy an auditor can re-check.",
    "bell": "The tie held (mixed pairs at zero) — entanglement, behaving.",
    "grover": "Amplitude amplification did the finding — one peek, honestly counted.",
    "chsh": "The classical ceiling (75%) was beaten again — evidence, accumulating.",
    "impossible": "The classical ceiling (75%) was beaten again — evidence, accumulating.",
}
GENERIC_NOTE = "A settled result, verified and filed — the hive's memory grows by one receipt."


def canonical_hash(receipt: dict) -> str:
    body = {k: v for k, v in receipt.items() if k != "hash"}
    blob = json.dumps(body, separators=(",", ":"), ensure_ascii=False)
    return hashlib.sha256(blob.encode("utf-8")).hexdigest()


def note_for(receipt: dict) -> str:
    label = (receipt.get("puzzle") or receipt.get("job") or "").lower()
    for key, note in NOTES.items():
        if key in label:
            return note
    return GENERIC_NOTE


def load_state() -> dict:
    if STATE.exists():
        return json.loads(STATE.read_text())
    return {"seen": []}


def main() -> int:
    INBOX.mkdir(exist_ok=True)
    PROCESSED.mkdir(exist_ok=True)
    state = load_state()
    seen = set(state["seen"])
    now = datetime.now(timezone.utc).isoformat(timespec="seconds")
    added = skipped = rejected = 0

    for path in sorted(INBOX.glob("*.json")):
        try:
            doc = json.loads(path.read_text())
        except Exception as e:  # unreadable file: reject loudly, keep it in inbox
            print(f"REJECT {path.name}: unreadable JSON ({e})")
            rejected += 1
            continue
        receipt = doc.get("receipt", doc)
        claimed = receipt.get("hash", "")
        if not claimed or canonical_hash(receipt) != claimed:
            print(f"REJECT {path.name}: hash mismatch — receipt not trusted, not filed")
            rejected += 1
            continue
        if claimed in seen:
            print(f"SKIP {path.name}: already filed ({claimed[:12]}…)")
            skipped += 1
            path.rename(PROCESSED / path.name)
            continue
        job = receipt.get("puzzle") or receipt.get("job") or "unknown job"
        note = note_for(receipt)
        with WATCH_LOG.open("a", encoding="utf-8") as f:
            f.write(f"- [{now}] 👁️ Yaae observed **{job}** — receipt `{claimed[:16]}…` · "
                    f"charged {receipt.get('cost_geniq', receipt.get('charged_geniq', 0))} GENIQ · "
                    f"route {receipt.get('route', 'n/a')}\n  📝 {note}\n")
        entry = {
            "receipt_hash": claimed,
            "job": job,
            "trigger": "receipt-settled",
            "status": "QUEUED",
            "review_asks": REVIEW_ASKS,
            "learning_note": note,
            "queued_at": now,
        }
        with PODCAST_QUEUE.open("a", encoding="utf-8") as f:
            f.write(json.dumps(entry, ensure_ascii=False) + "\n")
        seen.add(claimed)
        added += 1
        print(f"FILED {path.name}: {job} -> learning note + podcast QUEUED ({claimed[:12]}…)")
        path.rename(PROCESSED / path.name)

    state["seen"] = sorted(seen)
    STATE.write_text(json.dumps(state, indent=2))
    print(f"DONE: {added} filed, {skipped} duplicates skipped, {rejected} rejected")
    return 0


if __name__ == "__main__":
    sys.exit(main())
