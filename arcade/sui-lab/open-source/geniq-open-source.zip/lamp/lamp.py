"""The Lamp — GENIQ v2 prototype (LOCAL). Validates accounting + contract logic only:
no Nexus, no Sui, no real credentials. (SYNTHESIS.md D11)"""
import hashlib
import hmac
import json
import math
import os
import secrets
import time
from dataclasses import dataclass, field

MARGIN = 1.2                      # D3: published operator spread
QUOTE_TTL_S = 900                 # D8
MAX_SHOTS = 10_000                # D13
MAX_QUBITS = 98                   # D13
MAX_TWOQ = 10_000                 # D13
MAX_HQC_PER_REQUEST = 50.0        # D13
MAX_PROGRAMS_PER_BATCH = 300      # Nexus cap
MAX_PER_CALLER_PER_BATCH = 30     # D13 (10% of 300)
MAX_PENDING_PER_CALLER = 5        # D13
DAILY_GENIQ_CAP_PER_CALLER = 200  # D13
EMULATOR_DAILY_LIMIT = 20         # D4
MAX_JOB_TICKS = 50                # timeout policy (Warden C4)
SETTLE_TOLERANCE = 1.2            # abort if actual > 1.2x quote (D2)
QUANTUM_CLASSES = {"optimization", "sampling", "quantum_chem"}  # D9
RECEIPT_SIGNER = "restricted-mint-only (MOCK)"  # D20: Gate-1 decision rehearsed

class LampError(Exception): pass
class CapError(LampError): pass
class QuoteError(LampError): pass
class AuthError(LampError): pass
class QuotaError(LampError): pass

def hqc_cost(n1q, n2q, nm, shots):
    """Documented formula (Microsoft Learn / Quantinuum provider page)."""
    for name, v in (("n1q", n1q), ("n2q", n2q), ("nm", nm), ("shots", shots)):
        if not isinstance(v, int) or isinstance(v, bool):
            raise LampError(f"{name} must be int")
        if v < 0:
            raise LampError(f"{name} must be >= 0")
    if shots < 1:
        raise LampError("shots must be >= 1")
    return round(5 + shots * (n1q + 10 * n2q + 5 * nm) / 5000, 2)

@dataclass
class CircuitSpec:
    n1q: int; n2q: int; nm: int; shots: int
    backend: str          # "hardware" or "emulator"
    problem_class: str
    qubits: int
    def spec_hash(self):
        canon = json.dumps([self.n1q, self.n2q, self.nm, self.shots,
                            self.backend, self.problem_class, self.qubits],
                           separators=(",", ":"))
        return hashlib.sha256(canon.encode()).hexdigest()

class Ledger:
    """Closed-loop, non-transferable GENIQ ledger. Balances mutate ONLY via
    mint (admin issuance, ledgered), reserve, release, settle(burn). (D6, T11)"""
    def __init__(self):
        self.balances = {}
        self.reserved = {}
        self.issuances = []   # [(caller, amount, reason)]
        self.burned_total = 0
        self.daily_spend = {} # (caller, yyyymmdd) -> int
    def mint(self, caller, amount, reason, day):
        assert amount > 0 and isinstance(amount, int)
        self.balances[caller] = self.balances.get(caller, 0) + amount
        self.issuances.append({"caller": caller, "amount": amount, "reason": reason})
        return amount
    def transfer(self, *a, **k):
        raise LampError("transfers are disabled: GENIQ is non-transferable (D7/D12)")
    def reserve(self, caller, amount, day):
        key = (caller, day)
        day_total = self.daily_spend.get(key, 0)
        if day_total + amount > DAILY_GENIQ_CAP_PER_CALLER:
            raise CapError("daily GENIQ cap exceeded")
        if self.balances.get(caller, 0) < amount:
            raise LampError("insufficient balance")
        self.balances[caller] -= amount
        self.reserved[caller] = self.reserved.get(caller, 0) + amount
        self.daily_spend[key] = day_total + amount
        return amount
    def release(self, caller, amount):
        r = self.reserved.get(caller, 0)
        if r < amount:
            raise LampError("release exceeds reserved")
        self.reserved[caller] = r - amount
        self.balances[caller] = self.balances.get(caller, 0) + amount
    def settle(self, caller, amount):  # burn (D2)
        r = self.reserved.get(caller, 0)
        if r < amount:
            raise LampError("settle exceeds reserved")
        self.reserved[caller] = r - amount
        self.burned_total += amount
    def reserve_report(self):
        outstanding = sum(self.balances.values()) + sum(self.reserved.values())
        return {"outstanding_geniq": outstanding, "burned_total": self.burned_total,
                "backing": "emulator-only backing"}  # D6/D23 honest report at Gate 0/1
    def to_dict(self):
        return {"balances": self.balances, "reserved": self.reserved,
                "issuances": self.issuances, "burned_total": self.burned_total,
                "daily_spend": {f"{c}|{d}": v for (c, d), v in self.daily_spend.items()}}
    @classmethod
    def from_dict(cls, d):
        l = cls()
        l.balances = d["balances"]; l.reserved = d["reserved"]
        l.issuances = d["issuances"]; l.burned_total = d["burned_total"]
        l.daily_spend = {(lambda p: (p[0], p[1]))(k.split("|")): v for k, v in d["daily_spend"].items()}
        return l

class MockBackend:
    """Adversarial-capable mock Nexus. Injectable failure modes (D16)."""
    def __init__(self, quota_hardware=0.0):
        self.quota_hardware = quota_hardware   # D14: 0 at launch
        self.jobs = {}
        self.mode = "ok"        # ok | stuck | diverge3 | fail_k:N | quota_drop
        self.submits = 0
    def set_quota(self, q):
        self.quota_hardware = q
    def preflight(self, backend, needed):
        if backend == "hardware" and self.quota_hardware < needed:
            raise QuotaError("0 hardware quota: cannot quote hardware work against HQCs not held (D14)")
    def submit(self, programs, tick):
        # programs: list of (quote_id, caller, hqc)
        self.submits += 1
        jid = f"job-{self.submits:06d}"
        self.jobs[jid] = {"programs": programs, "state": "QUEUED",
                          "ticks": 0, "submitted_at": tick, "done_at": None,
                          "results": {}}
        return jid
    def tick(self, jid, lamp):
        j = self.jobs[jid]
        if j["state"] in ("DONE", "FAILED", "ABORTED"):
            return j["state"]
        j["ticks"] += 1
        if self.mode == "stuck":
            if j["ticks"] > MAX_JOB_TICKS:
                j["state"] = "TIMEOUT"
            return j["state"]
        if j["state"] == "QUEUED":
            j["state"] = "RUNNING"; return j["state"]
        if self.mode == "quota_drop":
            self.quota_hardware = 0.0
        # produce results per program
        res = {}
        for idx, (qid, caller, hqc) in enumerate(j["programs"]):
            if self.mode.startswith("fail_k:") and idx == int(self.mode.split(":")[1]):
                res[idx] = {"status": "failed", "actual": hqc}
            else:
                actual = hqc * (3 if self.mode == "diverge3" else 1)
                res[idx] = {"status": "ok", "actual": round(actual, 2),
                            "distribution": lamp.pseudo_distribution(qid, idx)}
        j["results"] = res
        j["state"] = "DONE"; j["done_at"] = j["ticks"]
        return "DONE"

class Lamp:
    def __init__(self, state_path, clock=None):
        self.state_path = state_path
        self.clock = clock if clock is not None else int(time.time())
        # D19: credential comes from environment at runtime, never persisted/logged
        self.nexus_credential = os.environ.get("LAMP_NEXUS_CREDENTIAL")
        self.ledger = Ledger()
        self.backend = MockBackend(quota_hardware=0.0)
        self.quotes = {}
        self.jobs = {}            # job_id -> job record
        self.routing_log = []
        self.emu_usage = {}       # (caller, day) -> count
        self.log = []             # lamp-side event log (for tests; credential-free by construction)
        self.day = "2026-10-19"
        self._nq = 0
        self._load()
    # ---- persistence (D15) ----
    def _save(self):
        d = {"ledger": self.ledger.to_dict(),
             "quota_hardware": self.backend.quota_hardware,
             "backend_submits": self.backend.submits,
             "backend_jobs": self.backend.jobs,
             "quotes": self.quotes, "jobs": self.jobs,
             "routing_log": self.routing_log,
             "emu_usage": {f"{c}|{d}": v for (c, d), v in self.emu_usage.items()},
             "clock": self.clock, "log": self.log, "nq": self._nq}
        with open(self.state_path, "w") as f:
            json.dump(d, f)
    def _load(self):
        try:
            with open(self.state_path) as f:
                d = json.load(f)
        except FileNotFoundError:
            return
        self.ledger = Ledger.from_dict(d["ledger"])
        self.backend.quota_hardware = d["quota_hardware"]
        self.backend.submits = d["backend_submits"]
        self.backend.jobs = d["backend_jobs"]
        self.quotes = d["quotes"]; self.jobs = d["jobs"]
        self.routing_log = d["routing_log"]
        self.emu_usage = {tuple(k.split("|")): v for k, v in d["emu_usage"].items()}
        self.clock = d["clock"]; self.log = d["log"]; self._nq = d["nq"]
    def _event(self, msg):
        self.log.append({"t": self.clock, "msg": msg})
    # ---- tools ----
    def cost_estimate(self, caller, spec):
        """Caps enforced BEFORE estimation (Warden C1)."""
        if spec.shots > MAX_SHOTS:
            raise CapError(f"shots {spec.shots} > cap {MAX_SHOTS}")
        if spec.qubits > MAX_QUBITS:
            raise CapError(f"qubits {spec.qubits} > cap {MAX_QUBITS}")
        if spec.n2q > MAX_TWOQ:
            raise CapError(f"2q gates {spec.n2q} > cap {MAX_TWOQ}")
        hqc = hqc_cost(spec.n1q, spec.n2q, spec.nm, spec.shots)
        if hqc > MAX_HQC_PER_REQUEST:
            raise CapError(f"HQC {hqc} > per-request cap {MAX_HQC_PER_REQUEST}")
        if spec.backend not in ("hardware", "emulator"):
            raise LampError("backend must be hardware|emulator")
        return hqc
    def issue_quote(self, caller, spec, estimate_only=False):
        hqc = self.cost_estimate(caller, spec)   # raises on caps first
        if spec.backend == "emulator":
            charge = 0                            # D4: emulator is 0 GENIQ, disclosed
        else:
            charge = math.ceil(hqc * MARGIN)      # D3/D8
        self._nq += 1
        qid = f"q{self._nq:06d}"
        q = {"id": qid, "caller": caller, "spec_hash": spec.spec_hash(),
             "n1q": spec.n1q, "n2q": spec.n2q, "nm": spec.nm,
             "shots": spec.shots, "backend": spec.backend,
             "problem_class": spec.problem_class,
             "hqc": hqc, "margin": MARGIN, "charge_geniq": charge,
             "issued_at": self.clock, "expires_at": self.clock + QUOTE_TTL_S,
             "state": "QUOTED"}
        self.quotes[qid] = q
        self._save()
        return q
    def route(self, caller, problem_class):
        """D9: published rule + audit. Classical by default."""
        decision = "quantum" if problem_class in QUANTUM_CLASSES else "classical"
        self.routing_log.append({"caller": caller, "problem_class": problem_class,
                                 "decision": decision, "t": self.clock})
        self._save()
        return decision
    def submit(self, caller, quote_id, idempotency_key, spec, opt_in_emulator=False):
        """One quote -> own program entry in a single-program batch."""
        return self.submit_batch(caller, [(quote_id, idempotency_key, spec)], opt_in_emulator)
    def submit_batch(self, submitter, entries, opt_in_emulator=False):
        """entries: [(quote_id, idempotency_key, spec)]. One Nexus job for the batch. (D1)
        The caller re-presents the exact spec; the Lamp re-hashes and rejects any
        mismatch against the quote (Vera T4)."""
        if not entries:
            raise LampError("empty batch")
        if len(entries) > MAX_PROGRAMS_PER_BATCH:
            raise LampError(f"batch of {len(entries)} exceeds cap {MAX_PROGRAMS_PER_BATCH}")
        try:
            return self._submit_batch_inner(submitter, entries, opt_in_emulator)
        except LampError as e:
            self._event(f"submit rejected: {e}")   # rejections are logged (T16)
            raise
    def _submit_batch_inner(self, submitter, entries, opt_in_emulator):
        # idempotency FIRST: a legitimate retry must return the existing job even
        # though its quote is no longer in QUOTED state (D15, Vera T13).
        idem_sig = [submitter] + [k for _, k, _ in entries]
        for j in self.jobs.values():
            if list(j.get("idem", [])) == idem_sig:
                return {"job_id": j["id"], "reused": True}
        progs = []
        for qid, key, spec in entries:
            q = self.quotes.get(qid)
            if q is None:
                raise QuoteError("unknown quote")
            # batching aggregates quotes from DIFFERENT callers into one Nexus job;
            # ownership travels per program and is enforced on every read (D17).
            if q["state"] != "QUOTED":
                raise QuoteError("quote not in QUOTED state")
            if spec.spec_hash() != q["spec_hash"]:
                raise QuoteError("spec hash mismatch: quote binding invalid (Vera T4)")
            if self.clock > q["expires_at"]:
                raise QuoteError("quote expired")
            progs.append((qid, q["caller"], q["hqc"], q["charge_geniq"], q["backend"]))
        # fairness: per-caller share cap (D13)
        per_caller = {}
        for _, c, _, _, _ in progs:
            per_caller[c] = per_caller.get(c, 0) + 1
            if per_caller[c] > MAX_PER_CALLER_PER_BATCH:
                raise LampError(f"caller exceeds per-batch share cap {MAX_PER_CALLER_PER_BATCH}")
        # pending-job cap per caller
        for c in per_caller:
            pend = sum(1 for j in self.jobs.values()
                       if j["caller"] == c and j["state"] in ("QUEUED", "RUNNING"))
            if pend >= MAX_PENDING_PER_CALLER:
                raise CapError(f"caller {c} exceeds pending-job cap")
        # per-program: quota pre-flight, emulator opt-in/rate limit, reserve
        total_hqc = sum(h for _, _, h, _, b in progs if b == "hardware")
        emu_needed = any(b == "emulator" for _, _, _, _, b in progs)
        if emu_needed and not opt_in_emulator:
            raise LampError("emulator fallback requires explicit opt-in (D14)")
        self.backend.preflight("hardware", total_hqc) if total_hqc else None
        for qid, c, hqc, charge, backend in progs:
            if backend == "emulator":
                k = (c, self.day)
                if self.emu_usage.get(k, 0) >= EMULATOR_DAILY_LIMIT:
                    raise CapError("emulator daily limit exceeded (D4)")
            if charge > 0:
                self.ledger.reserve(c, charge, self.day)   # D2: reserve, not burn
        backend_job = self.backend.submit(
            [(qid, c, h) for qid, c, h, _, _ in progs], self.clock)
        self.backend.quota_hardware -= total_hqc          # hardware consumes quota
        for qid, c, hqc, charge, backend in progs:
            if backend == "emulator":
                self.emu_usage[(c, self.day)] = self.emu_usage.get((c, self.day), 0) + 1
            self.quotes[qid]["state"] = "RESERVED"
        jid = f"L{backend_job}"
        job = {"id": jid, "backend_job": backend_job, "idem": idem_sig,
               "caller": submitter, "programs": [
                   {"quote_id": qid, "caller": c, "quoted_hqc": hqc,
                    "charge": charge, "backend": b,
                    "state": "QUEUED", "actual": None, "receipt": None,
                    "salt": secrets.token_hex(16)}          # D18: 128-bit salt, off-chain
                   for qid, c, hqc, charge, b in progs],
               "state": "QUEUED", "created_at": self.clock}
        self.jobs[jid] = job
        self._event(f"job {jid} submitted with {len(progs)} programs")
        self._save()
        return {"job_id": jid, "reused": False}
    def _quote_owner(self, qid):
        return self.quotes[qid]["caller"]
    def tick(self):
        """Advance all mock jobs; apply timeouts and settlement (D2/D15)."""
        for jid, j in list(self.jobs.items()):
            if j["state"] in ("DONE", "FAILED", "ABORTED", "TIMEOUT", "CANCELLED"):
                continue
            st = self.backend.tick(j["backend_job"], self)
            if st == "QUEUED":
                j["state"] = "QUEUED"
            elif st == "RUNNING":
                j["state"] = "RUNNING"
                for p in j["programs"]:
                    if p["state"] == "QUEUED":
                        p["state"] = "RUNNING"
            elif st == "TIMEOUT":
                j["state"] = "TIMEOUT"          # never silent (Warden F7)
                for p in j["programs"]:
                    if p["state"] in ("QUEUED", "RUNNING"):
                        p["state"] = "TIMEOUT"
                        if p["charge"] > 0:
                            self.ledger.release(p["caller"], p["charge"])
                self._event(f"job {jid} declared TIMEOUT after {MAX_JOB_TICKS} ticks; escrow released")
            elif st == "DONE":
                j["state"] = "DONE"
                self._settle_job(j)
        self._save()
    def _settle_job(self, j):
        res = self.backend.jobs[j["backend_job"]]["results"]
        for idx, p in enumerate(j["programs"]):
            r = res[idx]
            if r["status"] == "failed":
                p["state"] = "FAILED"
                if p["charge"] > 0:
                    self.ledger.release(p["caller"], p["charge"])   # D2 refund table
                self._event(f"program {p['quote_id']} FAILED; escrow released")
                continue
            actual = r["actual"]
            p["actual"] = actual
            if actual > SETTLE_TOLERANCE * p["quoted_hqc"]:
                p["state"] = "ABORTED_COST"                         # D2
                self.ledger.release(p["caller"], p["charge"])
                self._event(f"program {p['quote_id']} ABORTED: actual {actual} > 1.2x quote; released")
                continue
            p["state"] = "DONE"
            if p["charge"] > 0:
                self.ledger.settle(p["caller"], p["charge"])        # D2: burn only on delivery
            dist = r["distribution"]
            p["receipt"] = self._receipt(j["id"], p, dist)
            self._event(f"program {p['quote_id']} DONE; settled {p['charge']} GENIQ")
    def cancel(self, caller, job_id):
        j = self.jobs.get(job_id)
        if j is None:
            raise LampError("unknown job")
        if j["caller"] != caller:
            raise AuthError("only the submitter may cancel")
        if j["state"] not in ("QUEUED", "RUNNING"):
            raise LampError("job already terminal")
        j["state"] = "CANCELLED"
        for p in j["programs"]:
            p["state"] = "CANCELLED"
            if p["charge"] > 0:
                self.ledger.release(p["caller"], p["charge"])   # D2 refund table
        self._event(f"job {job_id} cancelled; escrow released")
        self._save()
    def job_status(self, caller, job_id, program_index=0):
        """D10: status + timestamps only. Ownership enforced (D17)."""
        j = self.jobs.get(job_id)
        if j is None:
            raise LampError("unknown job")
        p = j["programs"][program_index]
        if p["caller"] != caller:
            raise AuthError("caller may not read another caller's program (D17)")
        return {"job_id": job_id, "program_state": p["state"],
                "created_at": j["created_at"], "backend_state":
                self.backend.jobs[j["backend_job"]]["state"]}
    def get_result(self, caller, job_id, program_index=0):
        j = self.jobs.get(job_id)
        if j is None:
            raise LampError("unknown job")
        p = j["programs"][program_index]
        if p["caller"] != caller:
            raise AuthError("caller may not read another caller's result (D17)")
        if p["state"] != "DONE":
            raise LampError("result not available: program not DONE")
        return self.backend.jobs[j["backend_job"]]["results"][program_index]["distribution"]
    def _receipt(self, job_id, p, distribution):
        canon = json.dumps(distribution, sort_keys=True, separators=(",", ":"))
        commitment = hashlib.sha256(bytes.fromhex(p["salt"]) + canon.encode()).hexdigest()
        # D18: commitment only. No question, circuit, or raw result on the receipt.
        return {"job_id": job_id, "caller": p["caller"], "backend": p["backend"],
                "hqc_quoted": p["quoted_hqc"], "hqc_actual": p["actual"],
                "margin": MARGIN, "charge_geniq": p["charge"],
                "result_commitment": commitment,
                "signed_by": RECEIPT_SIGNER}
    def verify_commitment(self, job_id, program_index, distribution, salt):
        """Recompute from stored receipt fields (T14). Salt is off-chain Lamp data."""
        p = self.jobs[job_id]["programs"][program_index]
        canon = json.dumps(distribution, sort_keys=True, separators=(",", ":"))
        return hashlib.sha256(bytes.fromhex(salt) + canon.encode()).hexdigest() == \
               p["receipt"]["result_commitment"]
    def pseudo_distribution(self, quote_id, program_index):
        """Deterministic mock result."""
        h = hashlib.sha256(f"{quote_id}:{program_index}".encode()).digest()
        w = [b / 255 for b in h[:4]]
        tot = sum(w)
        return {f"{i:02b}": round(w[i] / tot, 4) for i in range(4)}
    def get_receipt(self, caller, job_id, program_index=0):
        j = self.jobs.get(job_id)
        if j is None:
            raise LampError("unknown job")
        p = j["programs"][program_index]
        if p["caller"] != caller:
            raise AuthError("caller may not read another caller's receipt")
        if p["state"] != "DONE":
            raise LampError("receipt not available")
        return p["receipt"]
    def receipt_signer_doc(self):
        return RECEIPT_SIGNER   # D20
