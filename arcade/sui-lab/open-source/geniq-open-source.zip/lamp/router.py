"""Free-first routing ladder for the Lamp — Series 12 build.

Design rule (David's standing gates, in code): a job tries the cheapest
class that can serve it, in order FREE_LOCAL -> FREE_TIER -> CREDIT -> PAID.
PAID is reachable only when Gate 2 is open (David's exact yes on a real
purchase). Expired credits are treated as absent. Every decision is logged
with the reasons each cheaper backend was skipped, so the routing itself
leaves evidence.

GENIQ interplay: jobs served by FREE_LOCAL, FREE_TIER, or CREDIT charge
0 GENIQ (the v2 emulator rule generalized — prepaid/free capacity is not
metered in GENIQ). PAID jobs return to the quote path; the router never
prices them.
"""

from __future__ import annotations

import datetime as _dt
from dataclasses import dataclass, field
from enum import IntEnum


class CostClass(IntEnum):
    FREE_LOCAL = 0   # runs on our own machines (Selene local, Aer, :free models on our keys)
    FREE_TIER = 1    # provider free quota (IBM Open Plan minutes, Groq free, ...)
    CREDIT = 2       # expiring/startup credits (Activate, Founders Hub, BSP grants)
    PAID = 3         # real money — Gate 2 territory


class GateBlocked(Exception):
    """Raised when only PAID capacity fits and Gate 2 is closed."""


@dataclass
class Backend:
    name: str
    kind: str                       # "quantum" | "ai"
    cost_class: CostClass
    monthly_quota: float | None = None   # FREE_TIER: units per calendar month
    credit_balance: float | None = None  # CREDIT: units remaining
    credit_expires: _dt.date | None = None
    available: bool = True
    _quota_used: float = field(default=0.0, repr=False)
    _quota_month: tuple | None = field(default=None, repr=False)

    def quota_remaining(self, now: _dt.date) -> float | None:
        if self.monthly_quota is None:
            return None
        if self._quota_month != (now.year, now.month):
            return self.monthly_quota
        return self.monthly_quota - self._quota_used

    def consume(self, units: float, now: _dt.date) -> None:
        if self.cost_class is CostClass.FREE_TIER and self.monthly_quota is not None:
            if self._quota_month != (now.year, now.month):
                self._quota_month = (now.year, now.month)
                self._quota_used = 0.0
            self._quota_used += units
        elif self.cost_class is CostClass.CREDIT and self.credit_balance is not None:
            self.credit_balance -= units


@dataclass
class Decision:
    job_label: str
    backend: str
    cost_class: CostClass
    units: float
    skipped: list  # [(backend_name, reason), ...]

    def geniq_charge(self) -> float:
        # Free and credit-served work is never metered in GENIQ.
        return 0.0 if self.cost_class is not CostClass.PAID else -1.0  # -1 = "see quote path"


class Router:
    def __init__(self, backends: list[Backend], gate2_open: bool = False):
        self.backends = sorted(backends, key=lambda b: b.cost_class)
        self.gate2_open = gate2_open
        self.log: list[Decision] = []
        self.blocked_log: list[dict] = []

    def route(self, kind: str, units: float, label: str,
              now: _dt.date | None = None) -> Decision:
        now = now or _dt.date.today()
        skipped: list[tuple[str, str]] = []
        for b in self.backends:
            if b.kind != kind:
                continue
            if not b.available:
                skipped.append((b.name, "unavailable"))
                continue
            if b.cost_class is CostClass.FREE_TIER:
                rem = b.quota_remaining(now)
                if rem is not None and rem < units:
                    skipped.append((b.name, f"free quota exhausted ({rem} left, need {units})"))
                    continue
            if b.cost_class is CostClass.CREDIT:
                if b.credit_expires is not None and b.credit_expires < now:
                    skipped.append((b.name, f"credit expired {b.credit_expires.isoformat()}"))
                    continue
                if b.credit_balance is not None and b.credit_balance < units:
                    skipped.append((b.name, f"credit balance too low ({b.credit_balance} left)"))
                    continue
            if b.cost_class is CostClass.PAID and not self.gate2_open:
                skipped.append((b.name, "PAID blocked — Gate 2 closed"))
                continue
            b.consume(units, now)
            d = Decision(label, b.name, b.cost_class, units, skipped)
            self.log.append(d)
            return d
        self.blocked_log.append({"label": label, "kind": kind, "units": units,
                                 "skipped": skipped, "date": now.isoformat()})
        raise GateBlocked(
            f"job '{label}' ({kind}, {units} units) fits only paid capacity "
            f"and Gate 2 is closed; skipped: {skipped}")
