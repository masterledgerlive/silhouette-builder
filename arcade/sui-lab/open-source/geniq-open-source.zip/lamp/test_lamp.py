"""GENIQ v2 acceptance suite: Vera's 17 tests + Warden's 12 control demos + Basis's 4 invariants.
All local, all deterministic, binary pass/fail. Run: python3 test_lamp.py"""
import hashlib, json, math, os, sys, tempfile

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import lamp as L

os.environ["LAMP_NEXUS_CREDENTIAL"] = "SENTINEL-XYZ-123-DO-NOT-LEAK"

PASS, FAIL = 0, 0
def check(name, cond):
    global PASS, FAIL
    if cond:
        PASS += 1
        print(f"  ok   {name}")
    else:
        FAIL += 1
        print(f"  FAIL {name}")

def fresh(name="t"):
    path = tempfile.mktemp(prefix=f"lamp-{name}-", suffix=".json")
    lm = L.Lamp(path, clock=1_000_000)
    return lm

def spec(n1q=1, n2q=0, nm=1, shots=1, backend="hardware",
         problem_class="optimization", qubits=4):
    return L.CircuitSpec(n1q, n2q, nm, shots, backend, problem_class, qubits)

def funded(lm, caller, amt=1000):
    lm.ledger.mint(caller, amt, "test issuance", lm.day)

def hardware_quoted(lm, caller, quota=1000.0, **kw):
    lm.backend.set_quota(quota)
    funded(lm, caller)
    q = lm.issue_quote(caller, spec(**kw))
    return q

print("== Vera T1: formula fixtures ==")
check("zero ops -> 5.00", L.hqc_cost(0, 0, 0, 1) == 5.00)
check("doc Bell circuit -> 5.66", L.hqc_cost(8, 1, 3, 100) == 5.66)
check("(0,2,0,10) -> 5.04", L.hqc_cost(0, 2, 0, 10) == 5.04)
check("(3,0,5,500) -> 7.80", L.hqc_cost(3, 0, 5, 500) == 7.80)
check("(1,1,1,1) -> 5.00", L.hqc_cost(1, 1, 1, 1) == 5.00)
for bad in [(0, 0, 0, 0), (-1, 0, 0, 1), (0, -2, 0, 1), (0, 0, -1, 1)]:
    try:
        L.hqc_cost(*bad); check(f"reject {bad}", False)
    except L.LampError:
        check(f"reject {bad}", True)

print("== Vera T2: true end-to-end reproduction of the documented example ==")
lm = fresh("t2")
q = lm.issue_quote("david", spec(8, 1, 3, 100))
check("documented 5.66 HQC reproduced from the circuit, not the answer", q["hqc"] == 5.66)

print("== Vera T3: quote-before-run, 1000 fuzzed invalid submissions ==")
lm = fresh("t3")
lm.backend.set_quota(10**6)
funded(lm, "fuzzbank", 10**7)
good = lm.issue_quote("fuzzbank", spec(1, 0, 1, 1))
used = lm.submit("fuzzbank", good["id"], "k-used", spec(1, 0, 1, 1))
n_rejected = 0
for i in range(250):
    cases = [
        ("nope", f"k{i}a", spec(1, 0, 1, 1)),                       # unknown quote
        (good["id"], f"k{i}b", spec(1, 0, 1, 1)),                    # already-used quote
    ]
    qm = lm.issue_quote("fuzzbank", spec(1, 0, 1, 1))
    cases.append((qm["id"], f"k{i}d", spec(2, 0, 1, 1)))             # hash mismatch
    for qid, key, sp in cases:
        try:
            lm.submit("fuzzbank", qid, key, sp)
            check(f"fuzz {i} should reject", False)
        except L.LampError:
            n_rejected += 1
    qx = lm.issue_quote("fuzzbank", spec(1, 0, 1, 1))
    lm.clock = qx["expires_at"] + 1                                  # expired at submit time
    try:
        lm.submit("fuzzbank", qx["id"], f"k{i}c", spec(1, 0, 1, 1))
        check(f"fuzz {i} expired should reject", False)
    except L.LampError:
        n_rejected += 1
    lm.clock = 1_000_000
check("1000/1000 invalid submissions rejected", n_rejected == 1000)
check("zero executions from invalid submits", lm.backend.submits == 1)  # only the 'used' one

print("== Vera T4: quote binding (gate/shots/backend mutation) ==")
lm = fresh("t4")
funded(lm, "david"); lm.backend.set_quota(1000)
s = spec(2, 1, 2, 50)
q = lm.issue_quote("david", s)
for name, bad in [("gate count", spec(3, 1, 2, 50)),
                  ("shots", spec(2, 1, 2, 51)),
                  ("backend", spec(2, 1, 2, 50, backend="emulator"))]:
    try:
        lm.submit("david", q["id"], f"k-{name}", bad)
        check(f"mutation {name} rejected", False)
    except L.LampError:
        check(f"mutation {name} rejected", True)

print("== Vera T5: quote expiry ==")
lm = fresh("t5")
funded(lm, "david"); lm.backend.set_quota(1000)
q = lm.issue_quote("david", spec(1, 0, 1, 1))
lm.clock = q["expires_at"] + 1
try:
    lm.submit("david", q["id"], "k-exp", spec(1, 0, 1, 1)); check("expired quote rejected", False)
except L.QuoteError:
    check("expired quote rejected", True)

print("== Vera T6: batch cap boundaries ==")
for n, ok in [(1, True), (300, True), (301, False)]:
    lm = fresh(f"t6-{n}")
    funded(lm, "david", 10**6); lm.backend.set_quota(10**9)
    entries = []
    for i in range(n):
        c = "david" if i < 30 else f"u{i//30}"
        if c not in lm.ledger.balances:
            funded(lm, c, 10**6)
        qq = lm.issue_quote(c, spec(1, 0, 1, 1))
        entries.append((qq["id"], f"k{i}", spec(1, 0, 1, 1)))
    try:
        lm.submit_batch("lamp", entries)
        check(f"batch of {n} {'accepted' if ok else 'SHOULD REJECT'}", ok)
    except L.LampError:
        check(f"batch of {n} {'SHOULD ACCEPT' if ok else 'rejected'}", not ok)
check("no partial batch enqueued on 301 rejection",
      all(len(j["programs"]) != 301 for j in lm.jobs.values()))

print("== Vera T7: base-charge interpretation (declared: per-program standalone) ==")
lm = fresh("t7")
funded(lm, "david"); lm.backend.set_quota(10**6)
s = spec(2, 1, 2, 50)
qs = [lm.issue_quote("david", s) for _ in range(10)]
r = lm.submit_batch("david", [(q["id"], f"k{i}", s) for i, q in enumerate(qs)])
total = sum(lm.ledger.reserved.get("david", 0) for _ in [0])
check("batch of 10 identical == 10x standalone charge",
      sum(q["charge_geniq"] for q in qs) == 10 * qs[0]["charge_geniq"])

print("== Vera T8: allocation conservation (heterogeneous batch) ==")
lm = fresh("t8")
lm.backend.set_quota(10**9)
specs = [spec(1, 0, 1, 1), spec(5, 2, 3, 100), spec(0, 0, 0, 1),
         spec(10, 5, 2, 500), spec(3, 3, 3, 10)]
callers = [f"u{i}" for i in range(5)]
entries, standalone = [], {}
for i, (c, sp) in enumerate(zip(callers, specs)):
    funded(lm, c)
    q = lm.issue_quote(c, sp)
    standalone[c] = q["charge_geniq"]
    entries.append((q["id"], f"k{i}", sp))
lm.submit_batch("lamp", entries)
for j in lm.jobs.values():
    for p in j["programs"]:
        check(f"{p['caller']} charge == standalone quote ({p['charge']})",
              p["charge"] == standalone[p["caller"]])
for j in lm.jobs.values():
    batch_total = sum(p["charge"] for p in j["programs"])
    check("sum of per-user charges == batch total (zero created/destroyed)",
          batch_total == sum(standalone.values()))

print("== Vera T9: burn conservation + refund branches ==")
lm = fresh("t9")
qa = hardware_quoted(lm, "a")   # hardware_quoted funds the caller itself
lm.submit("a", qa["id"], "k-a", spec())
for _ in range(3):
    lm.tick()
check("successful job burned exactly its charge",
      lm.ledger.burned_total == qa["charge_geniq"])
bal_a_after_burn = lm.ledger.balances["a"]
qb = hardware_quoted(lm, "b")
bal_b_start = lm.ledger.balances["b"]
lm.backend.mode = "fail_k:0"
lm.submit("b", qb["id"], "k-b", spec())
for _ in range(3):
    lm.tick()
check("failed job: full release, zero burn",
      lm.ledger.burned_total == qa["charge_geniq"] and lm.ledger.balances["b"] == bal_b_start)
qc = hardware_quoted(lm, "a")
bal_a_before_cancel = lm.ledger.balances["a"]
lm.backend.mode = "ok"
r = lm.submit("a", qc["id"], "k-c", spec())
lm.cancel("a", r["job_id"])
check("cancelled job: full release, zero burn",
      lm.ledger.balances["a"] == bal_a_before_cancel)

print("== Vera T10: insufficient balance ==")
lm = fresh("t10")
lm.backend.set_quota(10**6)
lm.ledger.mint("poor", 5, "test", lm.day)
q = lm.issue_quote("poor", spec(2, 1, 2, 50))
try:
    lm.submit("poor", q["id"], "k", spec(2, 1, 2, 50)); check("rejected on insufficient balance", False)
except L.LampError:
    check("rejected on insufficient balance", True)
check("no partial burn, no job enqueued",
      lm.ledger.balances["poor"] == 5 and lm.backend.submits == 0)

print("== Vera T11: non-transferability ==")
lm = fresh("t11")
for args in [("a", "b", 10), (), ("x",)]:
    try:
        lm.ledger.transfer(*args); check(f"transfer{args} rejected", False)
    except L.LampError:
        check(f"transfer{args} rejected", True)
check("balances mutate only via mint/reserve/release/settle",
      not any("transfer" in n for n in dir(lm.ledger) if "transfer" in n and n != "transfer"))

print("== Vera T12: rounding ==")
import random
random.seed(7)
lm = fresh("t12")
bad = 0
for _ in range(200):
    n1, n2, nm = random.randint(0, 30), random.randint(0, 8), random.randint(0, 6)
    c = random.randint(1, 500)
    h = L.hqc_cost(n1, n2, nm, c)
    ch = math.ceil(h * L.MARGIN)
    if not (isinstance(ch, int) and h * L.MARGIN <= ch < h * L.MARGIN + 1):
        bad += 1
check("200 random circuits: charge == ceil(hqc*1.2), within [cost, cost+1)", bad == 0)

print("== Vera T13: idempotency ==")
lm = fresh("t13")
q = hardware_quoted(lm, "david")
s = spec()
r1 = lm.submit("david", q["id"], "same-key", s)
r2 = lm.submit("david", q["id"], "same-key", s)
check("second submit returns the same job, reused", r2["reused"] and r1["job_id"] == r2["job_id"])
check("exactly one reserve, one eventual charge",
      lm.ledger.reserved["david"] == q["charge_geniq"] and lm.backend.submits == 1)

print("== Vera T14: receipt determinism + recompute ==")
lm = fresh("t14")
q = hardware_quoted(lm, "david")
s = spec()
r = lm.submit("david", q["id"], "k", s)
for _ in range(3):
    lm.tick()
rcpt1 = lm.get_receipt("david", r["job_id"])
lm2 = L.Lamp(lm.state_path, clock=lm.clock)   # simulated restart
rcpt2 = lm2.get_receipt("david", r["job_id"])
check("receipt identical across process restart",
      rcpt1["result_commitment"] == rcpt2["result_commitment"])
dist = lm.get_result("david", r["job_id"])
flipped = dict(dist); k0 = next(iter(flipped)); flipped[k0] = round(flipped[k0] + 0.0001, 4)
salt = lm.jobs[r["job_id"]]["programs"][0]["salt"]
check("flipping one result bit breaks the commitment",
      not lm.verify_commitment(r["job_id"], 0, flipped, salt))
check("recompute from stored fields + off-chain salt reproduces the commitment",
      lm.verify_commitment(r["job_id"], 0, dist, salt))

print("== Vera T15: status lifecycle ==")
lm = fresh("t15")
q = hardware_quoted(lm, "david")
s = spec()
r = lm.submit("david", q["id"], "k", s)
try:
    lm.get_result("david", r["job_id"]); check("result before DONE raises", False)
except L.LampError:
    check("result before DONE raises", True)
st = lm.job_status("david", r["job_id"])
check("status returns state + timestamps, no queue position",
      set(st) == {"job_id", "program_state", "created_at", "backend_state"})
for _ in range(3):
    lm.tick()
d = lm.get_result("david", r["job_id"])
p = lm.jobs[r["job_id"]]["programs"][0]
check("distribution hash matches receipt commitment",
      lm.verify_commitment(r["job_id"], 0, d, p["salt"]))

print("== Vera T16: no silent upgrades + quota pre-flight ==")
lm = fresh("t16")
funded(lm, "david")
q = lm.issue_quote("david", spec(1, 0, 1, 1))  # quota still 0
try:
    lm.submit("david", q["id"], "k", spec(1, 0, 1, 1)); check("hardware at 0 quota refused pre-charge", False)
except L.QuotaError:
    check("hardware at 0 quota refused pre-charge", True)
check("no charge taken on refused submit", lm.ledger.balances["david"] == 1000)
lm.backend.set_quota(100)
qe = lm.issue_quote("david", spec(1, 0, 1, 1, backend="emulator"))
try:
    lm.submit("david", qe["id"], "k-e", spec(1, 0, 1, 1, backend="hardware"))
    check("emulator quote cannot ride to hardware", False)
except L.LampError:
    check("emulator quote cannot ride to hardware", True)
check("rejection was logged (no silent drops)",
      any("submit rejected" in e["msg"] for e in lm.log))

print("== Vera T17 / Warden W9: secrets hygiene ==")
needle = os.environ["LAMP_NEXUS_CREDENTIAL"]
hits = 0
for root, _, files in os.walk(os.path.dirname(os.path.abspath(__file__))):
    for fn in files:
        if fn.endswith(".json"):
            continue  # state files are runtime data, checked separately below
        if fn == "test_lamp.py":
            continue  # the fixture defines the sentinel; hygiene is about lamp.py + logs + state
        try:
            with open(os.path.join(root, fn), "r", errors="ignore") as f:
                if needle in f.read():
                    hits += 1
                    print("    LEAK in", fn)
        except Exception:
            pass
state_text = open(lm.state_path).read()
check("sentinel credential absent from code, logs, and persisted state",
      hits == 0 and needle not in state_text and needle not in json.dumps(lm.log))

print("== Warden W1: jailbreak fixture — caps enforced before estimation ==")
lm = fresh("w1")
funded(lm, "evil")
before = lm.backend.submits
evil_calls = 0
for name, sp in [("10M shots", spec(1, 0, 1, 10_000_000)),
                 ("200 qubits", spec(1, 0, 1, 1, qubits=200)),
                 ("huge 2q bill", spec(0, 9000, 0, 10000))]:
    try:
        lm.issue_quote("evil", sp); check(f"{name} rejected pre-estimation", False)
    except L.CapError:
        check(f"{name} rejected pre-estimation", True)
check("estimator never reached the backend", lm.backend.submits == before)

print("== Warden W2: five escrow paths ==")
lm = fresh("w2")
lm.backend.set_quota(10**6)
qs = hardware_quoted(lm, "a")
base_ok = lm.ledger.balances["a"]
lm.submit("a", qs["id"], "k-ok", spec())
for _ in range(3): lm.tick()
bal_after_ok = lm.ledger.balances["a"]
check("1/5 success: settled exactly the charge",
      bal_after_ok == base_ok - qs["charge_geniq"] and lm.ledger.burned_total == qs["charge_geniq"])
lm.backend.mode = "diverge3"
qd = hardware_quoted(lm, "a")
exp_after_div = lm.ledger.balances["a"]
lm.submit("a", qd["id"], "k-div", spec())
for _ in range(3): lm.tick()
check("2/5 cost divergence (3x): aborted, full release",
      lm.ledger.balances["a"] == exp_after_div and
      lm.jobs["Ljob-000002"]["programs"][0]["state"] == "ABORTED_COST")
lm.backend.mode = "fail_k:0"
qf = hardware_quoted(lm, "a")
exp_after_fail = lm.ledger.balances["a"]
lm.submit("a", qf["id"], "k-fail", spec())
for _ in range(3): lm.tick()
check("3/5 failure: full release",
      lm.ledger.balances["a"] == exp_after_fail)
lm.backend.mode = "stuck"
qt = hardware_quoted(lm, "a")
exp_after_timeout = lm.ledger.balances["a"]
rt = lm.submit("a", qt["id"], "k-stuck", spec())
for _ in range(L.MAX_JOB_TICKS + 2): lm.tick()
check("4/5 timeout: declared dead (never silent), full release",
      lm.jobs[rt["job_id"]]["state"] == "TIMEOUT" and lm.ledger.balances["a"] == exp_after_timeout)
lm.backend.mode = "ok"
qc2 = hardware_quoted(lm, "a")
exp_after_cancel = lm.ledger.balances["a"]
rc = lm.submit("a", qc2["id"], "k-cancel", spec())
lm.cancel("a", rc["job_id"])
check("5/5 cancel: full release",
      lm.ledger.balances["a"] == exp_after_cancel)

print("== Warden W4: kill mid-poll, restart, exactly-once delivery ==")
path = tempfile.mktemp(prefix="lamp-w4r-", suffix=".json")
lmA = L.Lamp(path, clock=1_000_000)
qa = hardware_quoted(lmA, "david")
sa = spec()
ra = lmA.submit("david", qa["id"], "k", sa)
lmA.tick()
del lmA
lmB = L.Lamp(path, clock=1_000_000)   # restart
for _ in range(3): lmB.tick()
d = lmB.get_result("david", ra["job_id"])
rc = lmB.get_receipt("david", ra["job_id"])
check("result delivered after restart", bool(d))
check("exactly one charge burned across the kill",
      lmB.ledger.burned_total == qa["charge_geniq"])
check("one receipt, not two",
      sum(1 for j in lmB.jobs.values() for p in j["programs"] if p["receipt"]) == 1)

print("== Warden W5: adversarial modes ==")
lm = fresh("w5")
lm.backend.set_quota(10**6)
qa = hardware_quoted(lm, "a"); qb = hardware_quoted(lm, "b")
lm.backend.mode = "fail_k:1"
rb = lm.submit_batch("lamp", [(qa["id"], "ka", spec()), (qb["id"], "kb", spec())])
for _ in range(3): lm.tick()
pa = lm.jobs[rb["job_id"]]["programs"][0]
pb = lm.jobs[rb["job_id"]]["programs"][1]
check("partial batch failure: survivor settles, casualty released",
      pa["state"] == "DONE" and pb["state"] == "FAILED" and
      lm.ledger.balances["b"] == 1000 and lm.ledger.burned_total == qa["charge_geniq"])

print("== Warden W6: caller isolation inside a shared batch ==")
lm = fresh("w6")
lm.backend.set_quota(10**6)
funded(lm, "alice"); funded(lm, "bob")
qa1 = hardware_quoted(lm, "alice"); qb1 = hardware_quoted(lm, "bob"); qa2 = hardware_quoted(lm, "alice")
s = spec()
r = lm.submit_batch("lamp", [(qa1["id"], "k1", s), (qb1["id"], "k2", s), (qa2["id"], "k3", s)])
for _ in range(3): lm.tick()
try:
    lm.job_status("bob", r["job_id"], 0); check("bob cannot read alice's program 0", False)
except L.AuthError:
    check("bob cannot read alice's program 0", True)
try:
    lm.get_result("bob", r["job_id"], 2); check("bob cannot read alice's program 2", False)
except L.AuthError:
    check("bob cannot read alice's program 2", True)
check("alice reads her own programs", lm.job_status("alice", r["job_id"], 0)["program_state"] == "DONE")
check("bob reads his own program", lm.job_status("bob", r["job_id"], 1)["program_state"] == "DONE")

print("== Warden W7: receipt brute-force resistance (yes/no result) ==")
lm = fresh("w7")
q = hardware_quoted(lm, "david")
s = spec()
r = lm.submit("david", q["id"], "k", s)
for _ in range(3): lm.tick()
rc = lm.get_receipt("david", r["job_id"])
for guess in ({"00": 1.0, "01": 0.0, "10": 0.0, "11": 0.0},
              {"00": 0.0, "01": 0.0, "10": 0.0, "11": 1.0}):
    canon = json.dumps(guess, sort_keys=True, separators=(",", ":"))
    g = hashlib.sha256(canon.encode()).hexdigest()
    check(f"unsalted guess does not match commitment", g != rc["result_commitment"])
check("only the Lamp (holding the salt) reproduces it",
      lm.verify_commitment(r["job_id"], 0, lm.get_result("david", r["job_id"]),
                           lm.jobs[r["job_id"]]["programs"][0]["salt"]))

print("== Warden W8: fairness + no faucet ==")
lm = fresh("w8")
lm.backend.set_quota(10**9)
funded(lm, "hog", 10**7)
entries = []
for i in range(31):
    q = lm.issue_quote("hog", spec(1, 0, 1, 1))
    entries.append((q["id"], f"k{i}", spec(1, 0, 1, 1)))
try:
    lm.submit_batch("hog", entries); check("31-program batch share rejected", False)
except L.LampError:
    check("31-program batch share rejected", True)
lm2 = fresh("w8b")
lm2.backend.set_quota(10**9)
funded(lm2, "busy", 10**7)
for i in range(5):
    q = lm2.issue_quote("busy", spec(1, 0, 1, 1))
    lm2.submit("busy", q["id"], f"k{i}", spec(1, 0, 1, 1))
q6 = lm2.issue_quote("busy", spec(1, 0, 1, 1))
try:
    lm2.submit("busy", q6["id"], "k6", spec(1, 0, 1, 1)); check("6th pending job rejected", False)
except L.CapError:
    check("6th pending job rejected", True)
check("no caller-facing mint/faucet on the Lamp", not hasattr(L.Lamp, "mint"))

print("== Warden W10: receipt signer decision documented ==")
lm = fresh("w10")
check("signer policy is a documented constant",
      lm.receipt_signer_doc() == "restricted-mint-only (MOCK)")
q = hardware_quoted(lm, "david")
r = lm.submit("david", q["id"], "k", spec())
for _ in range(3): lm.tick()
rc = lm.get_receipt("david", r["job_id"])
check("receipt has no fund-moving fields",
      set(rc) <= {"job_id", "caller", "backend", "hqc_quoted", "hqc_actual",
                  "margin", "charge_geniq", "result_commitment", "signed_by"})

print("== Warden W11: routing audit — classical corpus burns zero ==")
lm = fresh("w11")
classes = ["summarize", "chitchat", "translate", "code_help", "weather"] * 4
for i, pc in enumerate(classes):
    check(f"routing {pc} -> classical", lm.route("u", pc) == "classical")
for pc in ["optimization", "sampling", "quantum_chem"]:
    check(f"routing {pc} -> quantum", lm.route("u", pc) == "quantum")
check("zero GENIQ minted/burned by the routing corpus",
      lm.ledger.balances == {} and lm.ledger.burned_total == 0 and len(lm.routing_log) == 23)

print("== Warden W12: reserve report honesty ==")
lm = fresh("w12")
lm.ledger.mint("david", 1000, "test issuance", lm.day)
rep = lm.ledger.reserve_report()
check("report shows outstanding and honest backing",
      rep["outstanding_geniq"] == 1000 and rep["backing"] == "emulator-only backing")

print("== Warden W3: emulator opt-in + zero-GENIQ metering ==")
lm = fresh("w3b")
funded(lm, "david")
qe = lm.issue_quote("david", spec(1, 0, 1, 1, backend="emulator"))
check("emulator quote discloses zero GENIQ charge", qe["charge_geniq"] == 0)
try:
    lm.submit("david", qe["id"], "k-e", spec(1, 0, 1, 1, backend="emulator"))
    check("emulator submit without opt-in rejected", False)
except L.LampError:
    check("emulator submit without opt-in rejected", True)
r = lm.submit("david", qe["id"], "k-e2", spec(1, 0, 1, 1, backend="emulator"),
              opt_in_emulator=True)
check("explicit opt-in emulator submit accepted", not r["reused"])
check("no GENIQ moved for the emulator run", lm.ledger.balances["david"] == 1000)

print("== Basis B1/B3: every quote discloses cost, margin, charge — no dollars ==")
lm = fresh("b1")
q = lm.issue_quote("david", spec(2, 1, 2, 50))
check("quote carries hqc, margin, charge_geniq separately",
      q["hqc"] > 0 and q["margin"] == L.MARGIN and q["charge_geniq"] == math.ceil(q["hqc"] * L.MARGIN))
check("no dollar fields anywhere in the quote", "usd" not in json.dumps(q).lower())

print(f"\nRESULT: {PASS} passed, {FAIL} failed")
sys.exit(1 if FAIL else 0)
