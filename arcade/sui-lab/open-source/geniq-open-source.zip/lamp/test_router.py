"""Acceptance tests for the free-first routing ladder (router.py)."""
import datetime as dt
import sys

sys.path.insert(0, ".")
from router import Backend, CostClass, GateBlocked, Router

PASS = FAIL = 0
def check(name, cond):
    global PASS, FAIL
    if cond: PASS += 1; print(f"  ok  {name}")
    else:    FAIL += 1; print(f"FAIL  {name}")

OCT = dt.date(2026, 10, 20)
NOV = dt.date(2026, 11, 2)

def base_backends():
    return [
        Backend("selene-local", "quantum", CostClass.FREE_LOCAL),
        Backend("ibm-open-plan", "quantum", CostClass.FREE_TIER, monthly_quota=10),
        Backend("aws-activate", "quantum", CostClass.CREDIT,
                credit_balance=100, credit_expires=dt.date(2027, 3, 31)),
        Backend("nexus-hardware", "quantum", CostClass.PAID),
        Backend("groq-free", "ai", CostClass.FREE_TIER, monthly_quota=1000),
        Backend("openrouter-paid", "ai", CostClass.PAID),
    ]

# 1. free local beats everything
r = Router(base_backends())
d = r.route("quantum", 3, "bell-test", now=OCT)
check("free local chosen first", d.backend == "selene-local" and d.cost_class is CostClass.FREE_LOCAL)

# 2. kind isolation: ai job never lands on a quantum backend
d = r.route("ai", 10, "summarize", now=OCT)
check("kind isolation", d.backend == "groq-free")

# 3. free-tier quota exhaustion falls through to credit
r = Router([b for b in base_backends() if b.name != "selene-local"])
r.route("quantum", 10, "drain-ibm", now=OCT)
d = r.route("quantum", 5, "next-job", now=OCT)
check("quota exhaustion falls to credit", d.backend == "aws-activate")

# 4. expired credit is treated as absent -> paid -> gate blocks
r = Router([Backend("old-credit", "quantum", CostClass.CREDIT,
                    credit_balance=500, credit_expires=dt.date(2026, 1, 1)),
            Backend("nexus-hardware", "quantum", CostClass.PAID)])
try:
    r.route("quantum", 5, "needs-hardware", now=OCT); check("expired credit skipped, gate blocks", False)
except GateBlocked:
    check("expired credit skipped, gate blocks", True)

# 5. insufficient credit balance is skipped, reason logged
r = Router([Backend("small-credit", "quantum", CostClass.CREDIT,
                    credit_balance=2, credit_expires=dt.date(2027, 1, 1)),
            Backend("nexus-hardware", "quantum", CostClass.PAID)], gate2_open=True)
d = r.route("quantum", 5, "big-job", now=OCT)
check("low credit skipped to paid when gate open", d.backend == "nexus-hardware")
check("skip reason recorded", any("too low" in reason for _, reason in d.skipped))

# 6. paid blocked without gate even when it is the ONLY backend
r = Router([Backend("nexus-hardware", "quantum", CostClass.PAID)])
try:
    r.route("quantum", 1, "solo", now=OCT); check("paid-only + closed gate = GateBlocked", False)
except GateBlocked:
    check("paid-only + closed gate = GateBlocked", True)
check("blocked job is logged as evidence", len(r.blocked_log) == 1)

# 7. gate open does NOT demote free — free still wins
r = Router(base_backends(), gate2_open=True)
d = r.route("quantum", 2, "still-free", now=OCT)
check("free preferred even with gate open", d.backend == "selene-local")

# 8. credit balance decrements on use
r = Router([b for b in base_backends() if b.name in ("ibm-open-plan", "aws-activate")])
r.route("quantum", 10, "drain", now=OCT)
r.route("quantum", 30, "credit-job", now=OCT)
bal = [b.credit_balance for b in r.backends if b.name == "aws-activate"][0]
check("credit balance decremented 100->70", bal == 70)

# 9. quota resets in a new month
r = Router([Backend("ibm-open-plan", "quantum", CostClass.FREE_TIER, monthly_quota=10)])
r.route("quantum", 10, "oct-job", now=OCT)
d = r.route("quantum", 4, "nov-job", now=NOV)
check("monthly quota resets", d.backend == "ibm-open-plan")

# 10. GENIQ charge: free and credit work charges 0; paid defers to quote path
r = Router(base_backends(), gate2_open=True)
check("free local charges 0 GENIQ", r.route("quantum", 1, "a", now=OCT).geniq_charge() == 0.0)
r2 = Router([Backend("c", "quantum", CostClass.CREDIT, credit_balance=50,
                     credit_expires=dt.date(2027, 1, 1))])
check("credit charges 0 GENIQ", r2.route("quantum", 1, "b", now=OCT).geniq_charge() == 0.0)

# 11. unavailable backend is skipped with reason
r = Router([Backend("down", "quantum", CostClass.FREE_LOCAL, available=False),
            Backend("ibm-open-plan", "quantum", CostClass.FREE_TIER, monthly_quota=10)])
d = r.route("quantum", 1, "failover", now=OCT)
check("unavailable skipped to next class", d.backend == "ibm-open-plan" and d.skipped[0][1] == "unavailable")

# 12. decision log accumulates evidence
check("decision log records routes", len(r.log) == 1 and r.log[0].job_label == "failover")

print(f"\n{PASS} passed, {FAIL} failed")
sys.exit(1 if FAIL else 0)
