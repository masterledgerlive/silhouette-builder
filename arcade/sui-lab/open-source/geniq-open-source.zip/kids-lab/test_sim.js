/* Node tests for the Kids Lab simulator — the same sim.js the page loads. */
const Q = require("./sim.js");
const crypto = require("crypto");
let pass = 0, fail = 0;
function check(name, ok, detail) {
  if (ok) { pass++; console.log("  ok   " + name + (detail ? " — " + detail : "")); }
  else { fail++; console.log("  FAIL " + name + (detail ? " — " + detail : "")); }
}

// sha256 vs node crypto (incl. empty, classic vector, long input)
for (const s of ["", "abc", "The quick brown fox jumps over the lazy dog", "x".repeat(500),
                 "Receipt — 53 heads, 47 tails… 🪙 quantum!", "Ünïcodé — π ≈ 3.14159 — ✓"]) {
  const want = crypto.createHash("sha256").update(s, "utf8").digest("hex");
  check("sha256 len=" + s.length, Q.sha256(s) === want);
}

// Coin flip: ~50/50 over 2000 shots (loose 6-sigma-ish band)
const cf = Q.coinFlip(2000);
check("coin flip near 50/50", Math.abs(cf.heads - 1000) < 120, `heads=${cf.heads}`);

// Bell pair: only 00 and 11, roughly equal, 01/10 exactly zero
const bp = Q.bellPair(2000);
check("bell: 01 and 10 are zero", bp.counts["01"] === 0 && bp.counts["10"] === 0,
  JSON.stringify(bp.counts));
check("bell: 00 and 11 both common", bp.counts["00"] > 800 && bp.counts["11"] > 800,
  `00=${bp.counts["00"]} 11=${bp.counts["11"]}`);

// Grover: after 1 round the marked door has probability ~1 for every choice
for (let m = 0; m < 4; m++) {
  const p = Q.groverAmps(m);
  check(`grover marked=${m} prob~1`, p[m] > 0.999, `p=${p[m].toFixed(4)}`);
}
const gv = Q.grover(2, 500);
check("grover sampled: marked dominates", gv.counts[2] > 490, JSON.stringify(gv.counts));

// CHSH: classical team = 75% exactly-ish; quantum team beats it clearly
const cc = Q.chsh(4000, false);
check("chsh classical ~75%", Math.abs(cc.rate - 0.75) < 0.02, `rate=${cc.rate.toFixed(3)}`);
const cq = Q.chsh(4000, true);
check("chsh quantum ~85.4%", cq.rate > 0.81 && cq.rate < 0.90, `rate=${cq.rate.toFixed(3)}`);
check("chsh quantum beats classical", cq.rate > cc.rate + 0.05,
  `q=${cq.rate.toFixed(3)} c=${cc.rate.toFixed(3)}`);

console.log(`\nRESULT: ${pass} passed, ${fail} failed`);
process.exit(fail ? 1 : 0);
