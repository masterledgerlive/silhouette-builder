# GENIQ — The Rethink (2026-10-19)

**The brief:** relook and rethink everything for an agentic AI connected to Quantinuum — the Genie as the front-end (image, voice, the bottle), asking it anything, with a token that meters quantum answers. First of its kind.

## 1. The name: GENIQ

**GENIQ** — the Genie's token. Genie + IQ, ending in Q. "One GENIQ, one quantum answer."

Rejected after name-collision checks (Oct 19, 2026):
- **DJINN** — live Bittensor protocol (SN103, on Base) + a BSC "Djinn Gold" token + a malware family named Djinn Stealer. Crowded and hostile.
- **JINNI** — dead Ethereum token (Jinni AI, $0.00). Ghost town, but it exists.
- **IFRIT** — Ifrit Network ($IFRIT), an AI/NFT chain project. Taken.
- **MARID / MARI** — $MARI (Mariana Islands DeFi). Taken.
- **GENIE** — GenieCoin (GNC) exists. Taken.
- **HELIOS / HELIO** — Quantinuum's machine name / Solana payments company. No.

GENIQ returned zero existing projects. Distinctive, pronounceable, owns the whole concept: the Genie thinks, GENIQ pays for the quantum.

## 2. The legitimate use case

The token is a **metered unit for real, scarce, priced quantum compute** — the same honest pattern as API credits. The loop:

1. Ask the Genie anything.
2. The Genie decides: classical (free) or quantum (costs real HQCs).
3. If quantum: the Genie translates the question into a circuit, **cost-estimates it BEFORE running** (the qnexus estimator returns HQCs up front), and shows the quote in GENIQ.
4. The job is **batched** with other users' jobs (Nexus allows up to 300 programs per job — quantum is expensive and queues; many users, one job).
5. Emulator first (eHQCs, cheap/free). Hardware only when the answer needs Helios's accuracy.
6. The answer returns with a **receipt on Sui** — the cost, the HQC spend, the result hash.

It can't be gamed because the price is quoted from the actual cost formula, not invented. That's what makes it legit: the token measures something real.

## 3. The pricing literature (what exists)

**The official formula** (Microsoft Learn, Quantinuum provider page):
`HQC = 5 + C(N1q + 10·N2q + 5·Nm) / 5000` — every job pays a 5-HQC base, plus per-operation cost (two-qubit gates weighted ×10, SPAM ×5), scaled by shot count, divided by 5000. Emulator jobs use the same formula in eHQCs.

**A worked example from Quantinuum's own docs:** a small circuit at 100 shots cost **5.66 HQC** — the base 5 dominates tiny jobs.

**Microsoft's own pages disagree with each other:** one Azure pricing page (older crawl) lists Standard $125,000/mo + infra for 10k HQCs and Premium $175,000/mo for 17k HQCs; another (newer-looking crawl) lists **$135,000 / $185,000**. Both pages also mention a **Pay-as-You-Go** offering whose per-HQC price is unpublished. So: quote the range $125–135k / $175–185k and verify on the Azure portal before any commitment — the literature contradicts itself.

**Nexus direct:** free signup; syntax checkers free; emulators + syntax checkers "Unlimited" under QCUP quotas; hardware backends 0 HQCs by default (allocation by application). Nexus per-HQC price: unpublished (contact sales).

**Derived (not official):** $125k/10k HQC ≈ **$12.50 per HQC**. That 5.66-HQC toy job ≈ **$70**. Treat as working arithmetic, not a quote.

**GENIQ pricing proposal:** 1 GENIQ = 1 HQC of compute. Every job quoted in HQC first (estimator), charged in GENIQ rounded up, **burned on spend**. The dollar anchor = whatever David actually pays per HQC on his purchase, published on the page. No invented prices.

## 4. The Lamp — our quantum container

The container is a small service (call it **the Lamp**) that holds the Nexus credentials and exposes four tools:

- `cost_estimate(circuit, shots)` → HQCs + GENIQ quote, shown before anything runs
- `submit_job(batch)` → qnexus `start_execute_job` on emulator or hardware
- `job_status(job_id)` → queue position (hardware jobs can queue days/weeks — the async "job pending" UX is structural, not cosmetic)
- `get_result(job_id)` → distribution back, hashed into a Sui receipt object

Auth = David's Nexus account (`qnx login`). Credentials never in the repo, never in chat.

## 5. The Genie seat (Muse today, OpenRouter tomorrow)

Muse acts as the Genie now: front-end image, conversation, the four tools. But the seat is a **socket** — the tool contract (cost → quote → batch → submit → poll → receipt) is identical for any LLM with tool-calling. When OpenRouter models arrive, they slot in beside Muse: **side-by-side theory runs** — same question, N models propose circuits/answers, everything runs on the emulator first (cheap), the best goes to hardware, and the quantum result verifies the decidable claims. Faster, better answers by tournament.

No official Quantinuum MCP server exists (checked Oct 19, 2026). The "plugin" is our Lamp wrapper — a build task of days, not months.

## 6. When the plugins arrive

- **Today:** `qnexus` (pip) — compile jobs, execute jobs, cost estimator, result download. Guppy/HUGR for Helios, pytket for H2, QIR accepted. This is the raw plugin; the Lamp wraps it.
- **The MCP/tool wrapper:** we build it (function-calling schema or MCP server around qnexus). Days.
- **OpenRouter models:** whenever we flip the seat — they use the identical tool contract. No rewrite.
- **Azure PAYG:** exists on paper, price unpublished — the first paid quantum dollar (Gate 2).

## 7. First-mover claim (honest scope)

Quantinuum's only blockchain-adjacent work is security (Quantum Origin, LACChain) — **no DeFi/token product, no compute-metering token found** in public research. A Genie-fronted, token-metered quantum query service settling on Sui would be first-of-kind **as far as the public record shows**. We can't prove a global negative — phrase it exactly like that, always.

## 8. The gated road

- **Gate 0 — $0, today:** Nexus signup (David's account); Startup Partner Program + QCUP applications filed; build the Lamp + the four qnexus tools; Muse as Genie on **emulators only**. Nothing spent.
- **Gate 1:** GENIQ on Sui testnet — closed-loop, non-transferable v1 (see §9); batching live; receipts as Sui objects.
- **Gate 2 — the first paid quantum dollar (David's exact yes on the exact amount):** Azure PAYG or Nexus HQC purchase; hardware jobs unlocked per-question, with the pre-run cost cap shown before any spend.
- **Gate 3:** OpenRouter seat — side-by-side theory tournaments; many models, one quantum referee.

## 9. The standing rule, stated plainly

David's Oct-14 verdict holds: **no tradable token unless he explicitly amends it.** GENIQ as designed here is closed-loop: acquired at the published HQC peg, burned on spend, non-transferable, non-redeemable. If David wants GENIQ tradable, that's a rule change he must state in so many words — then this design changes (supply, markets, the whole economics).

---
*Built from: Quantinuum cloud deep-research (Oct 19), the HQC/pricing literature above, PLAN.md, Series 3 & 5. Names collision-checked Oct 19, 2026.*
