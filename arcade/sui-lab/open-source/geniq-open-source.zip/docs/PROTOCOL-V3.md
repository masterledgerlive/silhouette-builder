# GENIQ PROTOCOL v3 — the hierarchy of code (Series 11 design, 2026-10-20)

The v2 design (Series 10) proved the accounting in a local Python prototype (Lamp, 106/106). V3 assigns every rule to the layer that can actually enforce it — Strata's rule: *if the protocol can enforce it, it does not belong in a policy document.*

## The hierarchy

**L0 — Chain (Sui Move, `geniq_protocol` package — BUILT + TESTED)**
- `ledger.move`: GENIQ exists ONLY as numbers in one shared `Ledger` object (balances + reserved tables). No `Coin<GENIQ>` is ever created → transfer between users is impossible at the type level; there is no transfer function to abuse, patch, or social-engineer around.
- Authorities are capabilities: `MintCap` (issuance only, against payment), `SettleCap` (burn reserved on verified delivery / release on any non-delivery / issue receipts). Neither can move a balance between users — no such operation exists.
- `SpendingCap`: user-owned ceiling object; `reserve` REQUIRES it and enforces per-tx + per-epoch caps in Move. An agent — or a jailbroken agent front end — cannot overspend: the protocol refuses. Owner can revoke (destroy) the cap and end the agent's spending power instantly. Cap reset semantics DECIDED (panel homework): per Sui epoch (≈ a day), enforced by the cap object itself.
- Escrow per job: each reserve creates an `Escrow` object (shared) — an on-chain state machine LOCKED → SETTLED | RELEASED, terminal states final (double-settle and release-after-settle abort, tested). The lock binds the quote (milli-HQC), and **settlement verifies the price rule in Move**: settle is legal only if actual ≤ 1.2× quoted (integer-checked actual×5 ≤ quoted×6); on success the full locked charge burns — the quote IS the price (v2 rule). The Lamp cannot overburn: the protocol does the arithmetic. The lock carries NO expiry — its lifetime is the job's lifetime, closing the panel's newly-found hole (v2 quotes expired during multi-day Nexus queues, leaving running jobs unescrowed); the Lamp's timeout discipline drives release on dead jobs.
- `PauseCap`: owner-held (David) emergency stop, separate from the Lamp's caps. Pause blocks mint/reserve/settle; **release is never blocked** — user funds can always escape.
- Conservation invariant is test-asserted: minted == Σbalances + Σreserved + burned.
- `receipts.move`: `Receipt` objects, `key`-only (soulbound — no `store`, cannot be publicly transferred or wrapped). Fields minimized per D18: salted result commitment, HQC quoted/actual (milli), GENIQ charge, backend tag, epoch. No question, no circuit, no raw result.

**L1 — Metering (off-chain, anchored on-chain)**
- Quotes stay in the Lamp (hash-bound, 900s TTL, per-program standalone — v2 decisions unchanged).
- Scale path (design, not yet code): the Tunnels pattern — CertiK-verified Oct 7, 2026 on Sui mainnet (15.2B off-chain tx anchored by 1,920 on-chain tx). GENIQ receipts batch off-chain; a periodic anchor (Merkle root / settlement tx) lands on Sui. One on-chain settle per job is fine at prototype scale; the anchor pattern is the documented road when volume demands it.

**L2 — Service (the Lamp — built in Series 10, interface unchanged)**
- Holds the Nexus credential (env only), the SettleCap/MintCap signer keys (restricted: mint/settle/issue only — a stolen Lamp key cannot drain user balances to an attacker; worst case it can mint unbacked GENIQ or burn reserved funds, both visible on-chain and both gated by David-held admin in production via multisig — open decision, see below).
- qnexus client behind the same 4-tool contract: `cost_estimate`, `submit_job`, `job_status`, `get_result`. Idempotency keys, durable job ledger, caller authorization — all carried over from v2, all already tested (106/106).

**L3 — Agents (untrusted by construction)**
- The Genie (Muse) today; OpenRouter models beside it, same four tools, same caps. Every LLM is treated as compromised: it can ask, it cannot exceed. Routing decisions logged (classical vs quantum) for the upsell audit (D9).
- Fresh rails to grow into (Oct 2026 research, status-checked): protocol allowances (live, protocol 137) as a complement to SpendingCap; Sui Agent Payments × Alibaba (x402 per-call USDC) for the classical side's micro-costs — status conflicted (testnet/invite-only per cautious sources), design toward it, depend on nothing; Agent Pass (Q4 target, no specs) — same stance.

**L4 — Evidence (auditability)**
- Walrus: job artifacts, result payloads (encrypted, Seal), agent memory.
- VAA alignment: Mysten × Google Cloud's Verifiable Agent Arbiter (announced Oct 6, 2026) is the same evidence pattern productized — telemetry off-chain, proofs on Walrus, coordination on Sui. Our receipts aim to be VAA-compatible evidence, not a competing silo.

## What v3 finalized
1. Token form: ledger numbers, never coins. (Type-level non-transferability.)
2. Enforcement home: caps + escrow + price-tolerance + conservation on-chain; quoting + routing + credentials off-chain.
3. Signer: restricted capabilities; the agent never signs (house rule intact — caps, not keys, are what the Lamp holds; the caps cannot move user funds).
4. Receipts: soulbound, field-minimized, salted commitments only.
5. Emergency stop: owner-held PauseCap; releases always escape.
6. Cap resets: per-epoch, in the cap object. Escrow lifetime = job lifetime (no lock expiry).

## The multi-LLM panel (OpenRouter fanout, 5 substantive models, 2026-10-20) — what we took, what we rejected
- TOOK: per-job escrow state machine on-chain (Ultra) → built as `Escrow`. Quote-expiry-during-queue hole (Ultra) → closed by no-expiry locks. Pause (Ultra/Laguna) → `PauseCap`. Freeze mechanisms, tune values (Laguna) → caps are mechanisms in Move; values stay configuration. KMS custody as the mint guard (Ultra/Cohere/Dots consensus) → recorded as the production requirement below.
- REJECTED: on-chain salt in receipts (Lightning) — privacy regression vs D18. Off-chain cap enforcement (Dots' Redis counters) — a trust regression; caps belong in Move, where they now are. Full on-chain job registry (Cohere) — job state stays with Nexus + the Lamp; the chain holds accounting only.
- DEFERRED, named honestly: pay-for-actual settlement (burn = min(actual, ceil(1.2×quote))) — a different price policy than v2's published "the quote is the price"; not adopted silently. And the **result-verifiability trust gap** (Dots): a commitment-only receipt cannot prove the RESULT is correct, only that it was delivered and metered — closing it needs verifiable compute/ZK evidence, out of scope for v3, on the record as the known gap.
- Threat register additions: cost_estimate as a pricing side channel (rate-limit the estimator per caller — Lamp duty), escrow-lock griefing (fast release path for pre-flight failures — exists: release is one call, unpausable), parallel-request cap races (closed by construction: caps are enforced inside reserve, atomically, on-chain).

## Open decisions (deliberately not finalized)
- Production key custody for MintCap/SettleCap: the panel's consensus (KMS/HSM with a signing policy that refuses anything but mint/settle under a daily cap) is the requirement; the vendor/mechanism pick is David's, before any mainnet step. PauseCap stays in David's own custody, never the Lamp's.
- Tunnels-style anchoring: when volume justifies it; the trigger metric is unsettled-receipt count, threshold TBD with real usage.
- GENIQ purchase rail (which stablecoin, which on-ramp) — tied to Gate 2, David's exact yes on the first paid quantum dollar. Unchanged.
- Post-quantum: ML-DSA-65 is Devnet-only with a Q1-2027 mainnet-auth roadmap — we name it as direction, claim nothing.

## Test evidence
- Move (as built): `sui move build` clean, zero warnings (sui 1.82.2); `sui move test` **15 passed / 0 failed** — mint/balance, reserve→settle conservation, reserve→release, per-tx cap abort, per-epoch cap abort, insufficient-balance abort, over-tolerance settle abort, settle at the exact 1.2× boundary, double-settle abort, release-after-settle abort, pause blocks reserve while release escapes, reserve-while-paused abort, receipt issuance with the documented 5.66 HQC example as its meter readings, two-user isolation + conservation across two escrows, cap revocation.
- Honest error log: first compile failed on Move borrow rules (3 call sites — fixed by computing values before mutable borrows). First test run of the ledger-only design: 4/10 — all six failures were test-bench defects (expected-failure abort-location metadata ×4, shared-object transaction tracking ×2); zero protocol-logic assertions failed. The escrow redesign's suite passed 15/15 on its first run after a clean build.
- Service layer: Lamp suite remains 106/106 (Series 10).
