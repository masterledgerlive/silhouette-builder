# HIVE THROUGHPUT + KIDS QUANTUM LAB — design (David's commission, 2026-10-23 PM)

David's word: **keep the model we have** (GENIQ v3 ledger + FIN closed-loop, per AUDIT-2026-10-23). Build on it: (1) a reason for agentic AI to push throughput through the system — the hive-mind commons on Walrus; (2) a kids' learning avenue with a duck scientist; (3) results that trigger automatic peer-review podcasts for whoever paid; (4) all routes published with token costs, so the quantum token can kick off once tests prove both avenues.

Gates unchanged throughout: no spending, no publishing, no chain transactions, no token launch without David's exact word. Kids' avenue is emulator-only. Podcasts are private to the payer until David greenlights any public share.

---

## 1. Why an agent routes throughput here (the hive incentive)

The agreed amount is the **quote**: before any job runs, the caller accepts a price in GENIQ, the amount locks in the on-chain escrow (v3), and settlement burns it only on verified delivery. That part already exists. What the hive adds is where the work *goes*:

- **Every job leaves two artifacts:** a soulbound receipt on Sui (commitment + meter readings — already in v3) and a result blob on Walrus. Blobs are classed at submission: **COMMONS** (open problems — the payload is public, anyone can learn from it, plug it in, build on it) or **PRIVATE** (paid/proprietary — payload Seal-encrypted, only the receipt is public; payload joins the commons only if the payer opts in).
- **The corpus is the discount.** The router checks the commons first: a question whose answer already exists as a verified receipt is served from the corpus at emulator cost or 0 GENIQ instead of a new hardware run. Agents who contribute good problems make everyone's future runs cheaper — including their own. (Series 12 rule preserved: free-served work charges 0 GENIQ.)
- **Reputation is the second currency, and it doesn't trade either.** Receipts accumulate into a non-transferable proof-of-work record per agent. A proven record is what justifies a higher SpendingCap tier — more throughput per epoch, granted by the cap owner, never bought. This is the honest incentive stack: **lower future cost + higher trusted throughput + a public record of real work.** No yield, no appreciation, no speculation — the law holds.
- **Plug-in is the 4-tool contract** (`cost_estimate`, `submit_job`, `job_status`, `get_result`) plus the receipt index: any agent that can call the Lamp can query the commons by commitment and topic tag. The hive mind is literal: shared memory (Walrus), shared rules (Sui caps/escrow), shared evidence (receipts).

## 2. The two avenues

**Avenue A — Pro / agentic.** Lamp + GENIQ v3 + the route table (§4). Callers: our agents today, outside agents when David opens the door. Hardware routes stay behind Gate 2.

**Avenue B — Kids Quantum Lab** (in the kids section; §3). Same machine underneath, emulator-only, cost shown as learning tickets at 0 GENIQ on free routes so kids learn the metering idea without money. A kid's verified puzzle result can enter the commons like any open job — that's the "one kid solves something cool and we share it with everyone" path, with the sharing gate in §3.

## 3. Kids Quantum Lab — the duck scientist's machine

**The guide:** a duck scientist — white coat, big goggles, clipboard. In the lab she's a **visual** teacher: animated, speech-bubble explanations, quack sound cues. She does **not** get a podcast voice today — the house voice catalogue (970) is fully cast as of this morning's audit, and one voice = one character forever. The peer-review podcast (§5) is voiced by Yaae + the existing specialists. If David wants the duck herself talking in audio, that's his ruling to make (exception or a future catalogue), not an assumption.

**Attention design (middle-school span):** one idea per screen, five big color buttons = the five steps of the machine, every step a short cartoon animation of what's happening and *why*:

1. **ASK** (blue) — type or pick a question. Duck bubble: "Every job starts as a question!"
2. **RECIPE** (purple) — the question becomes a circuit; gates are LEGO-like blocks you drag. "A circuit is a recipe the quantum computer follows."
3. **SPLIT** (orange) — the machine shows what a normal computer does vs what the quantum part does. "Most of the work is normal. Only the tricky part goes quantum."
4. **RUN** (green) — the emulator runs it; animation of qubits as spinning coins that land heads/tails and get counted. "Quantum coins can land in-between *while they spin* — that's the superpower, and the tricky part."
5. **PROVE** (gold) — the receipt appears: what it cost (0 tickets on the emulator), what the answer was, and the "check-it" button that re-runs the check. "Scientists don't just get answers. They get receipts."

**Starter puzzles (all emulator-provable today):** Quantum Coin Flip (true randomness vs a phone's fake randomness), the CHSH Game (the same game our T0 hardware runs play, simplified — beat the classical score limit), Guess-My-Number (Grover search in 4 boxes, shown as trying fewer doors), Build-a-Bell (make two coins that always match — entanglement, honestly labeled as correlation, not magic messaging).

**Safety/compliance shape (amended COPPA Rule is live law — designed against it):** no accounts for kids, no kid payments ever (a parent's cap funds any non-free step, and there are none in the kids' lane by design), no kid data used for training, results shared publicly **only** with a parent's explicit approval, session data parent-owned with retention controls. The lab teaches; it does not collect.

## 4. Routes & token costs (GENIQ/HQC only — no dollar figures until a real purchase exists)

| Route | What it is | Cost to caller | Status |
|---|---|---|---|
| Local emulator (Selene/Guppy, Qiskit Aer) | Runs on our own machines | **0 GENIQ** | Working today |
| IQM Resonance Starter | Real IQM hardware, free tier (~30 credits/mo) | 0 GENIQ while free credits last | Working (other desk's T0/G1 runs) |
| IBM Open Plan | 10 QPU-min/month free | 0 GENIQ | Catalogue-verified Oct 20 |
| Quantum Inspire (Tuna-17) | Free, reportedly uncapped | 0 GENIQ | Catalogue-verified Oct 20 |
| Nexus emulator | eHQC metering, free tier | 0 GENIQ | Route exists; account pending (their side) |
| Nexus hardware (Helios) | The real machine, billed in HQC by Quantinuum's formula | **GENIQ = ceil(HQC × 1.2)**, quoted before the run, escrowed | Gate 2 — David's exact yes on first paid amount |
| OCI Quantum AI Compute Beta | Helios inside Oracle Cloud (launched Oct 22) | Per program terms (unpublished) | Application-gated; watch item |
| Azure Quantum PAYG | Per-HQC price unpublished | Quoted in HQC first if it ever opens | Gate 2 |

Kids' lane uses rows 1–4 only. The price rule never changes: the quote is the price (v3), over-tolerance aborts with a full release, free routes never charge.

## 5. Results → peer-review podcast (the automatic part)

Pipeline: **result lands → receipt issued → review triggers → episode produced → delivered to the payer.**

1. A job settles; its result blob + receipt enter the results queue (Walrus in the design; a local queue in the prototype — same interface).
2. The queue watcher assembles the review packet: the question (or its commitment, for private jobs), the circuit, the route, the meter readings, the verification checks run.
3. Script desk drafts the episode: **Yaae + the relevant specialist** walk the result, challenge it (what would prove this wrong? did the classical cross-check agree?), and grade it on air — the house peer-review pattern, not a victory lap.
4. The episode renders **private** and is delivered to whoever paid (the parent, for a kid's run). Public sharing is a separate, explicit approval — David's for pro results, a parent's for kids'.
5. If the review finds the result wrong, that ships too — a correction episode is part of the design, not an embarrassment path. (House rule: self-caught errors get retracted the same day.)

## 6. Proof status — tests run today (2026-10-23, this desk, fresh)

- Lamp suite: **106/106**. Router suite: **15/15**. GENIQ Move suite: **15/15** (incl. settle-at-tolerance-boundary, over-tolerance abort, two-user conservation). Emulator lane proven in production by the IQM T0/G1 hardware runs (other desks).
- **Proven:** the accounting machine, the routing rules, the price rule, the free lanes.
- **Not yet proven / gated:** Gate 1 testnet publish of the Move package (David's word — a chain transaction); Gate 2 first paid quantum dollar (exact yes); Nexus account (blocked on Quantinuum's expired Azure secret); the kids lab itself (design only — build/deploy on David's word); the results→podcast trigger (design only — the queue watcher is new code); the duck's audio voice (catalogue exhausted — visual-only until David rules).

**Kickoff definition, so "soon" has a shape:** both avenues are provable at $0 — Avenue A by publishing the already-tested package to testnet and running one escrowed emulator job end-to-end; Avenue B by the lab prototype running the four puzzles on the local emulator with receipts and one private review episode. Every step after that sentence is a named gate with David's name on it, in the order above.
