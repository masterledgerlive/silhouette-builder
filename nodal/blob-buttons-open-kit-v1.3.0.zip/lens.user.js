// ==UserScript==
// @name         Blob Buttons — The Lens (Pack #5, TEACHES + SIMULATES ONLY)
// @namespace    blob-buttons/koda-kai
// @version      0.3.0
// @description  The Lens: a translucent overlay that sits over the price chart on the Polymarket US BTC 5-minute page and makes the desk's mathematical engine visible — a step-through tutorial of what PLAIN, EARLY, and FINAL watch, a fast simulation, a scored test-sim game, and a LIVE STAGE fed by Pack #2's watcher stream: the REAL price series drawn as a moving line, an engine strip (PLAIN / EARLY / FINAL with a one-line WHY each), blob-connect link lines that light the press sequence, capped block-burst effects with a momentum aura, proof-of-decision cards that show WHY a call was chosen, and CALL POINTS pinned on the live line itself — every call marked where it landed with its time and %, plus entry / holding / exit annotations read from the Board's Scorekeeper store. It teaches and simulates only; it never presses anything. Pack #5 of the Blob Button Field (blob-button-pack/0, id: lens).
// @author       Koda Kai Network (David's house build)
// @match        *://polymarket.us/event/btc-updown-5m-*
// @run-at       document-idle
// @grant        none
// ==/UserScript==

(function () {
  'use strict';

  /* ------------------------------------------------------------------
   * Blob Buttons Pack #5 — THE LENS
   *
   * David's commission: lay a transparent lens over the price chart
   * and show how a real life would look — teach the top strategies
   * the desk's engines use, run a fast simulation and a scored test
   * simulation, and in LIVE mode paint what the engines are looking
   * for right now, on top of the real chart, at any transparency.
   *
   * HARD GUARANTEE: TEACHES AND SIMULATES ONLY. Like the Board, this
   * script never presses, taps, or activates any control the page
   * owns. It contains no programmatic press call, no synthetic event
   * delivery, no form interaction, and no network call of any kind.
   * It does exactly three things:
   *   1. READS Pack #2's watcher stream (the watcher's own on-device
   *      log, localStorage key "blobbtn.poly5m.v1") for LIVE mode —
   *      the same stream every layer reads, so the whole layover is
   *      in sync. The Lens produces no readings of its own.
   *   2. RENDERS its own overlay: a panel with a canvas drawing layer
   *      that sits over the chart, at an opacity David sets.
   *   3. REMEMBERS its own layout, opacity, tutorial preference, and
   *      the test-sim high scores in its own localStorage keys.
   * The only elements it ever listens to are its own overlay
   * elements — plus, since v0.2.0, two receive-only channels from its
   * sibling packs: the Board buttons' state attributes (read on the
   * poll, never written) and the Trigger's "blobbtn:sequence" window
   * event (listened for, never sent). The simulations run on
   * synthetic series generated inside this script — no page data,
   * no network, no money words: free learning play.
   *
   * v0.2.0 — THE LIVE STAGE (David's hands-on direction, 2026-11-16):
   *   - LIVE draws the watcher's REAL price series as a moving line
   *     (the newest sample's series field when the watcher provides
   *     one; otherwise the series the stream's own sample log spells
   *     out). The y-axis auto-scales to the data so real moves are
   *     visible. If no real series exists yet, LIVE draws the beat +
   *     the latest price dot and prints "series warming up" — never
   *     a fake flat line presented as live.
   *   - ENGINE STRIP: PLAIN / EARLY / FINAL slots along the stage
   *     top, each with a lean, a strength, and a one-line WHY built
   *     from stream fields, under the standing label "DEMO LAW —
   *     desk bridge is slice 2".
   *   - BLOB-CONNECT LINKS: a full-viewport SVG layer draws faint
   *     dotted links from each Trigger FIRE button to its Board
   *     twin (and Board SELL to REVERSAL). A practice sequence event
   *     from the Trigger — or a Board flash — lights the chain in
   *     order with numbered badges and a callout naming the press.
   *   - EFFECTS: strong moves burst capped fountains of small
   *     blocks (green/gold rising, red falling) and a soft aura
   *     behind the chart follows the momentum. Toggle in the header.
   *   - PROOF-OF-DECISION: when a Board light fires, a card pins to
   *     the stage — "WHY THIS CALL" with the stream's own numbers —
   *     and the last five are kept as the session learning record.
   *     If the % is unreadable, the card says so instead of
   *     inventing numbers.
   *
   * v0.3.0 — CALL POINTS (David's live-test direction, 2026-11-16):
   *   - CALL POINTS ON THE LINE: when a call lands — a Board flash,
   *     a Trigger practice sequence, or an engine-strip edge (PLAIN
   *     entering the call zone, FINAL reaching agreement, EARLY's
   *     flip across the beat) — a marker pins ON the real price line
   *     at the sample time + price where it happened, so it rides
   *     the line as the chart scrolls. The label carries the local
   *     time and the call's % ("BUY UP · 92% · 01:47:13"); the badge
   *     carries the engine's initial when the source is an engine,
   *     and older markers fade (last 10 kept, per window).
   *   - POSITION ANNOTATIONS: the Lens also reads the Board's
   *     Scorekeeper store ("blobbtn.board.score.v1", read-only):
   *     a POINT pins an ENTRY marker, an open point draws a
   *     "HOLDING · m:ss · %" tag at the line's head, the SELL
   *     take-profit light pins an EXIT LIGHT marker, and its
   *     resolution pins EXIT ✓ (taken) or MISSED EXIT ⚑ (the light
   *     went out untapped). A datum the store does not carry simply
   *     produces no annotation — nothing is invented.
   *   - EFFECTS ON THE MARKERS: a landing call point bursts blocks
   *     FROM its spot on the line (count by the % loudness tiers)
   *     and the line's fresh segment pulses once in the side colour.
   *   - The warming-up label now keys off ONE flag computed from
   *     the same series the chart draws, and the log fallback no
   *     longer starves the line when a sample's window label is
   *     formatted differently: same-beat points inside the window's
   *     own lifetime count as real points.
   *   - The resize grip is larger and higher-contrast (resize and
   *     layout persistence themselves are unchanged from v0.1.x).
   *
   * RULES STATUS: the tutorial teaches the desk's real rules from
   * ARMED-BUTTON-SPEC.md (the beat, the gate, the resting sell, the
   * lose-zero rule, the flip law), simplified for learners. Every
   * simplification is labelled DEMO in the UI. The practice
   * thresholds (ARM 55% / CALL 62%) are the Board's DEMO RULES v0
   * numbers, and are labelled as such wherever they appear.
   *
   * David is deaf: the visual signal IS the interface. Every state
   * is carried by words plus colour — never colour alone.
   * ------------------------------------------------------------------ */

  var LENS_KEY = 'blobbtn.lens.v1';        // layout + opacity + tutorial pref
  var SCORES_KEY = 'blobbtn.lens.scores.v1'; // test-sim high scores (top 5)
  var WATCH_KEY = 'blobbtn.poly5m.v1';     // Pack #2's sample stream (shared)
  var TAPS_KEY = 'blobbtn.board.taps.v1';  // Pack #3's passive tap journal
  var SCORE_KEY = 'blobbtn.board.score.v1'; // Pack #3's Scorekeeper store (v0.3.0, read-only)
  var MARKER_CAP = 10;                     // call points kept per window (v0.3.0)
  var ROOT_ID = 'blobbtn-lens';
  var LINKS_ID = 'blobbtn-lens-links';     // blob-connect SVG layer (v0.2.0)
  var FX_ID = 'blobbtn-lens-fx';           // particle layer (v0.2.0)
  var CALLOUT_ID = 'blobbtn-lens-callout'; // press-sequence callout (v0.2.0)
  var LIVE_POLL_MS = 250;                  // sync discipline: every layer reads
                                           // the same stream; the Lens polls
                                           // snappy so LIVE lags it < 1 s
  var WATCH_FRESH_MS = 20000;

  /* DEMO RULES v0 thresholds (the Board's practice numbers) */
  var ARM_PCT = 55;
  var CALL_PCT = 62;

  var BEAT = 65000; // synthetic windows are priced around this beat

  /* ---------------- small utilities ---------------- */

  function mulberry32(seed) {
    return function () {
      seed |= 0; seed = seed + 0x6D2B79F5 | 0;
      var t = Math.imul(seed ^ seed >>> 15, 1 | seed);
      t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t;
      return ((t ^ t >>> 14) >>> 0) / 4294967296;
    };
  }

  function clamp(v, lo, hi) { return Math.max(lo, Math.min(hi, v)); }

  function fmtClock(sec) {
    if (sec === null || sec === undefined || isNaN(sec)) return '—';
    sec = Math.max(0, Math.round(sec));
    var m = Math.floor(sec / 60), s = sec % 60;
    return m + ':' + (s < 10 ? '0' : '') + s;
  }

  function fmtMoney(v) {
    if (v === null || v === undefined || isNaN(v)) return '—';
    return '$' + Number(v).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  }

  /* ---------------- synthetic series ----------------
   * A 5-minute window = 300 one-second points. upPct is scripted by
   * keyframes (the story the engines would see); price is derived
   * from it around the beat, plus a whisper of seeded noise. Fully
   * deterministic per seed: the same window replays identically. */

  function genSeries(seed, keyframes) {
    var rnd = mulberry32(seed);
    var pts = [];
    for (var t = 0; t <= 300; t++) {
      var up = interpKeys(keyframes, t) + (rnd() - 0.5) * 0.8;
      up = clamp(up, 3, 97);
      var price = BEAT * (1 + (up - 50) * 0.00035) + (rnd() - 0.5) * 6;
      pts.push({ t: t, upPct: Math.round(up * 10) / 10, downPct: Math.round((100 - up) * 10) / 10, price: price });
    }
    return pts;
  }

  function interpKeys(keys, t) {
    if (t <= keys[0][0]) return keys[0][1];
    for (var i = 1; i < keys.length; i++) {
      if (t <= keys[i][0]) {
        var t0 = keys[i - 1][0], v0 = keys[i - 1][1], t1 = keys[i][0], v1 = keys[i][1];
        return v0 + (v1 - v0) * ((t - t0) / (t1 - t0));
      }
    }
    return keys[keys.length - 1][1];
  }

  /* The teaching window: DOWN leans and flashes early, momentum
   * crosses the beat (the flip), UP arms, UP calls, the resting sell
   * fills, and the window settles UP. */
  var FAST_KEYS = [[0, 44], [60, 36], [110, 52], [200, 74], [240, 70], [300, 68]];
  /* The test window: a strong UP call, a weak lean (pass), a slide
   * to the exit light, then a completed flip to a strong DOWN call. */
  var TEST_KEYS = [[0, 47], [40, 55], [70, 63], [100, 58], [130, 52], [160, 54], [200, 49], [225, 41], [250, 34], [300, 31]];

  /* ---------------- persisted state (ours only) ---------------- */

  function defaultLayout() {
    var vw = 0;
    try { vw = window.innerWidth || 0; } catch (e) {}
    return {
      x: Math.max(8, Math.round(vw * 0.05)),
      y: 170,
      w: Math.min(640, Math.max(320, vw - 16)),
      h: 470
    };
  }

  var state = {
    locked: false,
    layout: defaultLayout(),
    opacity: 88,          // percent, 10..100
    tutorialOff: false,
    effects: true,        // v0.2.0: block bursts + momentum aura (header toggle)
    mode: 'idle',         // idle | tutorial | sim | test | live
    liveOn: false
  };

  function loadState() {
    try {
      var raw = window.localStorage.getItem(LENS_KEY);
      if (!raw) return;
      var s = JSON.parse(raw);
      if (!s || typeof s !== 'object') return;
      if (typeof s.locked === 'boolean') state.locked = s.locked;
      if (typeof s.tutorialOff === 'boolean') state.tutorialOff = s.tutorialOff;
      if (typeof s.effects === 'boolean') state.effects = s.effects;
      if (typeof s.opacity === 'number') state.opacity = clamp(Math.round(s.opacity), 10, 100);
      var g = s.layout;
      if (g && isFinite(g.x) && isFinite(g.y) && isFinite(g.w) && isFinite(g.h)) {
        state.layout = { x: g.x, y: g.y, w: Math.max(320, g.w), h: Math.max(300, g.h) };
      }
    } catch (e) {}
  }

  function saveState() {
    try {
      window.localStorage.setItem(LENS_KEY, JSON.stringify({
        locked: state.locked, layout: state.layout,
        opacity: state.opacity, tutorialOff: state.tutorialOff,
        effects: state.effects
      }));
    } catch (e) {}
  }

  function loadScores() {
    try {
      var raw = window.localStorage.getItem(SCORES_KEY);
      if (!raw) return [];
      var arr = JSON.parse(raw);
      if (!arr || Object.prototype.toString.call(arr) !== '[object Array]') return [];
      return arr.filter(function (e) { return e && typeof e.score === 'number'; }).slice(0, 5);
    } catch (e) { return []; }
  }

  function saveScore(score, grade) {
    var arr = loadScores();
    arr.push({ score: score, grade: grade, when: new Date().toISOString().slice(0, 10) });
    arr.sort(function (a, b) { return b.score - a.score; });
    arr = arr.slice(0, 5);
    try { window.localStorage.setItem(SCORES_KEY, JSON.stringify(arr)); } catch (e) {}
    return arr;
  }

  /* ---------------- feeds (read-only, shared stream) ---------------- */

  function readLog() {
    try {
      var raw = window.localStorage.getItem(WATCH_KEY);
      if (!raw) return null;
      var arr = JSON.parse(raw);
      if (!arr || Object.prototype.toString.call(arr) !== '[object Array]' || !arr.length) return null;
      return arr;
    } catch (e) { return null; }
  }

  function sampleFromRaw(s) {
    if (!s) return null;
    var age = Date.now() - Date.parse(s.ts || '');
    if (isNaN(age)) age = null;
    return {
      ts: s.ts || null,
      ageMs: age,
      fresh: (age !== null && age <= WATCH_FRESH_MS),
      window: s.window || null,
      priceToBeat: (typeof s.priceToBeat === 'number') ? s.priceToBeat : null,
      currentPrice: (typeof s.currentPrice === 'number') ? s.currentPrice : null,
      upPct: (typeof s.upPct === 'number') ? s.upPct : null,
      downPct: (typeof s.downPct === 'number') ? s.downPct : null,
      pctSource: (typeof s.pctSource === 'string' && s.pctSource) ? s.pctSource : null,
      countdownSec: (typeof s.countdownSec === 'number') ? s.countdownSec :
        (typeof s.countdown === 'string' ? parseClock(s.countdown) : null)
    };
  }

  function watcherSample() {
    var arr = readLog();
    if (!arr) return null;
    return sampleFromRaw(arr[arr.length - 1]);
  }

  /* The REAL price series for the Live Stage. Watcher v0.2.0 exposes
   * a series (last 120 points {t, price}) on the newest sample; until
   * it lands — and whenever it is absent — the same series is spelled
   * out by the stream's own sample log (each sample carries a
   * timestamp and a current price). Both sources are the watcher's
   * own readings; nothing is interpolated or invented. Points are
   * kept only from the newest sample's own window, so a rolled
   * window never bleeds into the chart. Returns
   * { points: [{t (ms), price}], source: 'watcher' | 'log' | 'none' }. */
  function normT(t) {
    if (typeof t === 'number' && isFinite(t)) return t < 1e12 ? t * 1000 : t;
    if (typeof t === 'string') { var ms = Date.parse(t); return isNaN(ms) ? null : ms; }
    return null;
  }

  function seriesFromField(raw) {
    var cand = null;
    if (raw) {
      if (Object.prototype.toString.call(raw.series) === '[object Array]') cand = raw.series;
      else if (Object.prototype.toString.call(raw.priceSeries) === '[object Array]') cand = raw.priceSeries;
    }
    if (!cand) return null;
    var pts = [];
    for (var i = 0; i < cand.length; i++) {
      var p = cand[i];
      if (!p || typeof p !== 'object') continue;
      var price = (typeof p.price === 'number') ? p.price :
                  (typeof p.p === 'number') ? p.p :
                  (typeof p.currentPrice === 'number') ? p.currentPrice : null;
      var t = normT(p.t !== undefined ? p.t : (p.ts !== undefined ? p.ts : p.time));
      if (price === null || !isFinite(price) || t === null) continue;
      pts.push({ t: t, price: price });
    }
    pts.sort(function (a, b) { return a.t - b.t; });
    if (pts.length > 120) pts = pts.slice(pts.length - 120);
    return pts.length >= 2 ? pts : null;
  }

  function collectLogPoints(arr, newestRaw, useWindow, winStart) {
    var pts = [];
    for (var i = 0; i < arr.length; i++) {
      var s = arr[i];
      if (!s || typeof s.currentPrice !== 'number' || !isFinite(s.currentPrice)) continue;
      if (newestRaw) {
        if (useWindow && newestRaw.window && s.window && s.window !== newestRaw.window) continue;
        if (typeof newestRaw.priceToBeat === 'number' && typeof s.priceToBeat === 'number' &&
            s.priceToBeat !== newestRaw.priceToBeat) continue;
      }
      var t = normT(s.ts);
      if (t === null) continue;
      if (winStart !== null && t < winStart) continue;
      if (pts.length && pts[pts.length - 1].t === t) pts[pts.length - 1].price = s.currentPrice;
      else pts.push({ t: t, price: s.currentPrice });
    }
    if (pts.length > 120) pts = pts.slice(pts.length - 120);
    return pts;
  }

  /* The series the log spells out. Strictest first: the newest
   * sample's own window label + beat. v0.3.0: if that starves the
   * line (a window label formatted differently between samples of
   * the SAME window did exactly that on David's machine — the %
   * read fine while the chart sat at "warming up"), fall back to
   * same-beat points inside the window's own lifetime (derived from
   * the newest sample's countdown). Points are never taken from
   * outside the window's lifetime, so a rolled window still cannot
   * bleed into the chart. */
  function seriesFromLog(arr, newestRaw) {
    var strict = collectLogPoints(arr, newestRaw, true, null);
    if (strict.length >= 2 || !newestRaw) return strict;
    var winStart = null;
    var nt = normT(newestRaw.ts);
    var cd = (typeof newestRaw.countdownSec === 'number') ? newestRaw.countdownSec :
             (typeof newestRaw.countdown === 'string' ? parseClock(newestRaw.countdown) : null);
    if (nt !== null && cd !== null && cd >= 0 && cd <= 300) {
      winStart = nt - (300 - cd) * 1000 - 2000;
    }
    if (winStart === null) return strict;
    var byBeat = collectLogPoints(arr, newestRaw, false, winStart);
    return byBeat.length >= 2 ? byBeat : strict;
  }

  function watcherStream() {
    var arr = readLog();
    if (!arr) return { sample: null, series: [], seriesSource: 'none' };
    var newestRaw = arr[arr.length - 1];
    var sample = sampleFromRaw(newestRaw);
    var fromField = seriesFromField(newestRaw);
    if (fromField) return { sample: sample, series: fromField, seriesSource: 'watcher' };
    var fromLog = seriesFromLog(arr, newestRaw);
    return { sample: sample, series: fromLog, seriesSource: fromLog.length ? 'log' : 'none' };
  }

  function parseClock(str) {
    var m = String(str).match(/(\d+):(\d{2})/);
    if (!m) return null;
    return parseInt(m[1], 10) * 60 + parseInt(m[2], 10);
  }

  /* The Board's passive tap journal: flash -> tap reaction stats.
   * Read defensively — if the journal is absent or its records do
   * not carry a readable reaction + verdict, the Lens shows nothing
   * rather than inventing a stat. */
  function lastTapStat() {
    try {
      var raw = window.localStorage.getItem(TAPS_KEY);
      if (!raw) return null;
      var arr = JSON.parse(raw);
      if (!arr || Object.prototype.toString.call(arr) !== '[object Array]' || !arr.length) return null;
      var r = arr[arr.length - 1];
      if (!r || typeof r !== 'object') return null;
      var ms = null;
      var keys = ['ms', 'reactionMs', 'reaction_ms', 'tapMs', 'elapsedMs'];
      for (var i = 0; i < keys.length; i++) {
        if (typeof r[keys[i]] === 'number') { ms = r[keys[i]]; break; }
      }
      if (ms === null) return null;
      var verdict = String(r.verdict || r.result || r.outcome || '');
      var mark = '';
      if (/CORRECT/i.test(verdict)) mark = ' ✓';
      else if (/WRONG/i.test(verdict)) mark = ' ✗ WRONG CONTROL';
      return '⚡ last ' + (ms / 1000).toFixed(2) + 's' + mark;
    } catch (e) { return null; }
  }

  /* ---------------- styles ---------------- */

  var CSS = [
    '#' + ROOT_ID + '{position:fixed;z-index:2147483645;font-family:Arial,Helvetica,sans-serif;',
    '-webkit-user-select:none;user-select:none;color:#e8ecf1;box-sizing:border-box;',
    'background:rgba(10,13,20,0.96);border:2px solid #2b6cb0;border-radius:14px;overflow:hidden;',
    'display:flex;flex-direction:column;}',
    '#' + ROOT_ID + ' .bl-head{padding:7px 10px 6px 10px;background:rgba(16,24,38,0.9);cursor:move;flex:0 0 auto;}',
    '#' + ROOT_ID + ' .bl-title{font-size:13px;font-weight:bold;color:#7ee787;letter-spacing:0.4px;}',
    '#' + ROOT_ID + ' .bl-row{margin-top:5px;display:flex;flex-wrap:wrap;gap:5px;align-items:center;}',
    '#' + ROOT_ID + ' .bl-row button{pointer-events:auto;padding:4px 10px;border-radius:6px;border:1px solid #22303f;',
    'background:#10151d;color:#e8ecf1;font-size:12px;font-weight:bold;cursor:pointer;}',
    '#' + ROOT_ID + ' .bl-row button.bl-on{background:#1d4ed8;border-color:#60a5fa;color:#fff;}',
    '#' + ROOT_ID + ' .bl-row .bl-mode{font-size:11px;font-weight:bold;color:#ffd94d;margin-left:auto;letter-spacing:0.5px;}',
    '#' + ROOT_ID + ' .bl-opwrap{display:flex;align-items:center;gap:6px;font-size:10px;font-weight:bold;color:#9fb4c8;}',
    '#' + ROOT_ID + ' input.bl-op{pointer-events:auto;width:130px;accent-color:#2b6cb0;}',
    '#' + ROOT_ID + ' .bl-opval{font-size:11px;color:#e8ecf1;min-width:34px;}',
    '#' + ROOT_ID + ' .bl-stage{position:relative;flex:1 1 auto;min-height:110px;background:rgba(6,9,15,0.65);}',
    '#' + ROOT_ID + ' canvas.bl-canvas{position:absolute;left:0;top:0;width:100%;height:100%;display:block;}',
    '#' + ROOT_ID + ' .bl-tag{position:absolute;right:8px;top:6px;font-size:12px;font-weight:900;letter-spacing:1px;',
    'color:#ffd94d;background:rgba(20,16,4,0.75);border:1px solid #ffd94d;border-radius:6px;padding:2px 8px;pointer-events:none;}',
    '#' + ROOT_ID + ' .bl-card{flex:0 0 auto;padding:8px 11px 9px 11px;background:rgba(13,18,28,0.95);',
    'border-top:1px solid #22303f;font-size:13px;line-height:1.45;min-height:86px;}',
    '#' + ROOT_ID + ' .bl-card .bl-ct{font-size:14px;font-weight:900;color:#fff;letter-spacing:0.3px;}',
    '#' + ROOT_ID + ' .bl-card .bl-rtag{font-size:10px;font-weight:bold;color:#0b0e14;background:#ffd94d;',
    'border-radius:4px;padding:1px 6px;margin-left:7px;vertical-align:2px;}',
    '#' + ROOT_ID + ' .bl-card .bl-cb{color:#c8d4e2;margin-top:3px;white-space:pre-line;}',
    '#' + ROOT_ID + ' .bl-card .bl-crow{margin-top:7px;display:flex;flex-wrap:wrap;gap:6px;align-items:center;}',
    '#' + ROOT_ID + ' .bl-card button{pointer-events:auto;padding:5px 12px;border-radius:6px;border:1px solid #2b6cb0;',
    'background:#12233d;color:#e8ecf1;font-size:12px;font-weight:bold;cursor:pointer;}',
    '#' + ROOT_ID + ' .bl-card button.bl-big{font-size:15px;padding:8px 18px;}',
    '#' + ROOT_ID + ' .bl-card button.bl-up{background:#14532d;border-color:#39d353;}',
    '#' + ROOT_ID + ' .bl-card button.bl-down{background:#5c0d12;border-color:#f85149;}',
    '#' + ROOT_ID + ' .bl-card button.bl-gold{background:#4a3503;border-color:#ffd94d;color:#ffd94d;}',
    '#' + ROOT_ID + ' .bl-card .bl-step{font-size:11px;color:#9fb4c8;font-weight:bold;}',
    '#' + ROOT_ID + ' .bl-card .bl-score{font-size:15px;font-weight:900;color:#ffd94d;}',
    '#' + ROOT_ID + ' .bl-card .bl-feed{color:#7ee787;font-weight:bold;}',
    '#' + ROOT_ID + ' .bl-card .bl-honest{color:#ffa94d;font-weight:bold;}',
    '#' + ROOT_ID + ' .bl-handle{position:absolute;right:0;bottom:0;width:32px;height:32px;cursor:nwse-resize;z-index:3;',
    'background:repeating-linear-gradient(135deg,rgba(255,217,77,0) 0 5px,rgba(255,217,77,0.35) 5px 7px);border-radius:0 0 12px 0;}',
    '#' + ROOT_ID + ' .bl-handle:before{content:"";position:absolute;right:3px;bottom:3px;width:16px;height:16px;',
    'border-right:4px solid #ffd94d;border-bottom:4px solid #ffd94d;}',
    '#' + ROOT_ID + '.bl-locked .bl-stage,#' + ROOT_ID + '.bl-locked .bl-card{pointer-events:none;}',
    '#' + ROOT_ID + '.bl-locked .bl-head{cursor:default;}',
    /* v0.2.0 — Live Stage pieces */
    '#' + ROOT_ID + ' .bl-aura{position:absolute;left:0;top:0;right:0;bottom:0;pointer-events:none;',
    'transition:background 0.6s ease;}',
    '#' + ROOT_ID + ' .bl-engines{position:absolute;left:0;top:0;right:0;z-index:2;pointer-events:none;',
    'display:none;flex-direction:column;background:rgba(8,11,18,0.82);border-bottom:1px solid #22303f;}',
    '#' + ROOT_ID + ' .bl-engrow{display:flex;gap:6px;padding:4px 8px 2px 8px;}',
    '#' + ROOT_ID + ' .bl-eng{flex:1 1 0;min-width:0;}',
    '#' + ROOT_ID + ' .bl-eng .bl-eng-top{font-size:11px;font-weight:900;letter-spacing:0.4px;color:#e8ecf1;white-space:nowrap;}',
    '#' + ROOT_ID + ' .bl-eng .bl-eng-why{font-size:10px;line-height:1.3;color:#9fb4c8;white-space:nowrap;',
    'overflow:hidden;text-overflow:ellipsis;}',
    '#' + ROOT_ID + ' .bl-eng-law{font-size:9.5px;font-weight:bold;color:#ffa94d;padding:0 8px 4px 8px;letter-spacing:0.3px;}',
    '#' + ROOT_ID + ' .bl-proof{position:absolute;left:8px;bottom:8px;z-index:2;max-width:94%;pointer-events:none;',
    'background:rgba(14,18,8,0.92);border:1.5px solid #ffd94d;border-radius:8px;padding:5px 9px;display:none;}',
    '#' + ROOT_ID + ' .bl-proof .bl-proof-main{font-size:12px;font-weight:900;color:#ffe98a;line-height:1.35;}',
    '#' + ROOT_ID + ' .bl-proof .bl-proof-old{font-size:10px;color:#9fb4c8;line-height:1.35;}',
    '#' + LINKS_ID + '{position:fixed;left:0;top:0;width:100%;height:100%;z-index:2147483640;pointer-events:none;}',
    '#' + LINKS_ID + ' svg{position:absolute;left:0;top:0;width:100%;height:100%;}',
    '#' + LINKS_ID + ' .bl-link{fill:none;stroke:#7ee787;stroke-width:2;stroke-dasharray:3 7;opacity:0.32;}',
    '#' + LINKS_ID + ' .bl-link.bl-lit{stroke:#ffd94d;stroke-width:3.5;stroke-dasharray:10 6;opacity:1;}',
    '#' + LINKS_ID + ' .bl-badge circle{fill:#ffd94d;stroke:#0b0e14;stroke-width:2;}',
    '#' + LINKS_ID + ' .bl-badge text{fill:#0b0e14;font-size:13px;font-weight:900;text-anchor:middle;}',
    '#' + FX_ID + '{position:fixed;left:0;top:0;width:100%;height:100%;z-index:2147483642;pointer-events:none;overflow:hidden;}',
    '#' + FX_ID + ' .bl-particle{position:absolute;border-radius:2px;will-change:transform,opacity;}',
    '#' + CALLOUT_ID + '{position:fixed;left:50%;bottom:26px;transform:translateX(-50%);z-index:2147483643;',
    'pointer-events:none;display:none;background:rgba(20,16,4,0.94);border:2px solid #ffd94d;border-radius:10px;',
    'color:#ffe98a;font-family:Arial,Helvetica,sans-serif;font-size:19px;font-weight:900;letter-spacing:0.6px;',
    'padding:8px 18px;}'
  ].join('\n');

  /* ---------------- build the overlay ---------------- */

  var root = null, headEl = null, stageEl = null, canvas = null, ctx = null,
      tagEl = null, cardEl = null, modeEl = null, opSlider = null, opVal = null,
      lockBtn = null, liveBtn = null, fxBtn = null,
      auraEl = null, enginesEl = null, engSlots = [], proofEl = null,
      linksRoot = null, linksSvg = null, fxLayer = null, calloutEl = null;

  function el(tag, cls, text) {
    var e = document.createElement(tag);
    if (cls) e.className = cls;
    if (text !== undefined) e.textContent = text;
    return e;
  }

  function buildLens() {
    var style = document.createElement('style');
    style.textContent = CSS;
    (document.head || document.documentElement).appendChild(style);

    root = el('div');
    root.id = ROOT_ID;

    headEl = el('div', 'bl-head');
    var title = el('div', 'bl-title', '🔭 THE LENS — the desk, made visible · teaches + simulates only, never presses');
    headEl.appendChild(title);

    var row1 = el('div', 'bl-row');
    var tutBtn = el('button', null, '📖 TUTORIAL');
    tutBtn.setAttribute('data-bl-btn', 'tutorial');
    tutBtn.addEventListener('click', function () { startTutorial(0); });
    var simBtn = el('button', null, '▶ FAST SIM');
    simBtn.setAttribute('data-bl-btn', 'sim');
    simBtn.addEventListener('click', function () { startSim(); });
    var testBtn = el('button', null, '🎯 TEST SIM');
    testBtn.setAttribute('data-bl-btn', 'test');
    testBtn.addEventListener('click', function () { startTest(); });
    liveBtn = el('button', null, 'LIVE: OFF');
    liveBtn.setAttribute('data-bl-btn', 'live');
    liveBtn.addEventListener('click', function () { toggleLive(); });
    fxBtn = el('button', null, '✨ EFFECTS: ON');
    fxBtn.setAttribute('data-bl-btn', 'fx');
    fxBtn.addEventListener('click', function () {
      state.effects = !state.effects;
      if (!state.effects) clearParticles();
      saveState();
      applyModeChrome();
    });
    lockBtn = el('button', null, '');
    lockBtn.setAttribute('data-bl-btn', 'lock');
    lockBtn.addEventListener('click', function () {
      state.locked = !state.locked;
      saveState();
      applyModeChrome();
    });
    modeEl = el('span', 'bl-mode', 'MODE: —');
    row1.appendChild(tutBtn);
    row1.appendChild(simBtn);
    row1.appendChild(testBtn);
    row1.appendChild(liveBtn);
    row1.appendChild(fxBtn);
    row1.appendChild(lockBtn);
    row1.appendChild(modeEl);
    headEl.appendChild(row1);

    var row2 = el('div', 'bl-row');
    var opWrap = el('div', 'bl-opwrap');
    opWrap.appendChild(el('span', null, 'TRANSPARENT'));
    opSlider = document.createElement('input');
    opSlider.type = 'range';
    opSlider.className = 'bl-op';
    opSlider.min = '10';
    opSlider.max = '100';
    opSlider.step = '1';
    opSlider.value = String(state.opacity);
    opSlider.setAttribute('data-bl-op', '1');
    opSlider.addEventListener('input', function () {
      state.opacity = clamp(parseInt(opSlider.value, 10) || 88, 10, 100);
      applyOpacity();
      saveState();
    });
    opWrap.appendChild(opSlider);
    opVal = el('span', 'bl-opval', state.opacity + '%');
    opWrap.appendChild(opVal);
    opWrap.appendChild(el('span', null, 'SOLID'));
    row2.appendChild(opWrap);
    headEl.appendChild(row2);
    root.appendChild(headEl);

    stageEl = el('div', 'bl-stage');
    auraEl = el('div', 'bl-aura');
    stageEl.appendChild(auraEl);
    canvas = document.createElement('canvas');
    canvas.className = 'bl-canvas';
    ctx = canvas.getContext('2d');
    stageEl.appendChild(canvas);
    enginesEl = buildEngines();
    stageEl.appendChild(enginesEl);
    tagEl = el('div', 'bl-tag', '');
    tagEl.style.display = 'none';
    stageEl.appendChild(tagEl);
    proofEl = el('div', 'bl-proof');
    stageEl.appendChild(proofEl);
    root.appendChild(stageEl);

    cardEl = el('div', 'bl-card');
    root.appendChild(cardEl);

    var handle = el('div', 'bl-handle');
    root.appendChild(handle);

    (document.body || document.documentElement).appendChild(root);
    buildLayers();
    attachPanelPointer(handle);
    applyLayout();
    applyOpacity();
    applyModeChrome();
  }

  /* The engine strip: three slots along the stage top (LIVE only).
   * Built once; liveRefresh fills the words. */
  function buildEngines() {
    var wrap = el('div', 'bl-engines');
    var row = el('div', 'bl-engrow');
    engSlots = [];
    var names = ['PLAIN', 'EARLY', 'FINAL'];
    for (var i = 0; i < names.length; i++) {
      var slot = el('div', 'bl-eng');
      var top = el('div', 'bl-eng-top', names[i] + ' —');
      var why = el('div', 'bl-eng-why', '');
      slot.appendChild(top);
      slot.appendChild(why);
      row.appendChild(slot);
      engSlots.push({ top: top, why: why });
    }
    wrap.appendChild(row);
    wrap.appendChild(el('div', 'bl-eng-law', 'DEMO LAW — desk bridge is slice 2'));
    return wrap;
  }

  /* The viewport layers (v0.2.0): the blob-connect SVG, the particle
   * layer, and the press callout. All pointer-events:none, all below
   * every pack panel's z-order, all display-only. */
  function buildLayers() {
    var body = document.body || document.documentElement;
    linksRoot = el('div');
    linksRoot.id = LINKS_ID;
    linksSvg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
    linksRoot.appendChild(linksSvg);
    body.appendChild(linksRoot);
    fxLayer = el('div');
    fxLayer.id = FX_ID;
    body.appendChild(fxLayer);
    calloutEl = el('div', null, '');
    calloutEl.id = CALLOUT_ID;
    body.appendChild(calloutEl);
  }

  function applyLayout() {
    if (!root) return;
    root.style.left = state.layout.x + 'px';
    root.style.top = state.layout.y + 'px';
    root.style.width = state.layout.w + 'px';
    root.style.height = state.layout.h + 'px';
    fitCanvas();
  }

  function applyOpacity() {
    if (!root) return;
    root.style.opacity = String(state.opacity / 100);
    // The v0.2.0 layers ride the same slider: what David sets for the
    // panel is what the links, bursts, and callout render at.
    var op = String(state.opacity / 100);
    if (linksRoot) linksRoot.style.opacity = op;
    if (fxLayer) fxLayer.style.opacity = op;
    if (calloutEl) calloutEl.style.opacity = op;
    if (opVal) opVal.textContent = state.opacity + '%';
    if (opSlider && parseInt(opSlider.value, 10) !== state.opacity) opSlider.value = String(state.opacity);
  }

  function applyModeChrome() {
    if (!root) return;
    root.className = state.locked ? 'bl-locked' : 'bl-editing';
    if (lockBtn) lockBtn.textContent = state.locked ? '🔒 LOCKED — TAP PASSES THROUGH' : '✏️ EDIT — DRAG ME';
    if (liveBtn) {
      liveBtn.textContent = state.liveOn ? 'LIVE: ON' : 'LIVE: OFF';
      liveBtn.className = state.liveOn ? 'bl-on' : '';
    }
    if (fxBtn) {
      fxBtn.textContent = state.effects ? '✨ EFFECTS: ON' : '✨ EFFECTS: OFF';
      fxBtn.className = state.effects ? 'bl-on' : '';
    }
    if (enginesEl) enginesEl.style.display = (state.mode === 'live') ? 'flex' : 'none';
    if (tagEl) {
      // in LIVE the engine strip owns the stage top; the tag moves low
      if (state.mode === 'live') { tagEl.style.top = 'auto'; tagEl.style.bottom = '6px'; }
      else { tagEl.style.top = '6px'; tagEl.style.bottom = 'auto'; }
    }
    if (modeEl) modeEl.textContent = 'MODE: ' + state.mode.toUpperCase() + (state.liveOn && state.mode !== 'live' ? ' + LIVE' : '');
  }

  function setTag(text) {
    if (!tagEl) return;
    if (text) { tagEl.textContent = text; tagEl.style.display = 'block'; }
    else { tagEl.style.display = 'none'; }
  }

  /* ---------------- panel drag / resize (our own element only) ---------------- */

  function attachPanelPointer(handle) {
    var drag = null;

    headEl.addEventListener('pointerdown', function (ev) {
      if (state.locked) return;
      if (ev.target && (ev.target.tagName === 'BUTTON' || ev.target.tagName === 'INPUT')) return;
      drag = { mode: 'move', startX: ev.clientX, startY: ev.clientY,
               orig: { x: state.layout.x, y: state.layout.y, w: state.layout.w, h: state.layout.h } };
      try { headEl.setPointerCapture(ev.pointerId); } catch (e) {}
      ev.preventDefault();
    });
    headEl.addEventListener('pointermove', function (ev) {
      if (!drag || drag.mode !== 'move') return;
      state.layout.x = Math.max(0, drag.orig.x + (ev.clientX - drag.startX));
      state.layout.y = Math.max(0, drag.orig.y + (ev.clientY - drag.startY));
      applyLayout();
    });
    headEl.addEventListener('pointerup', function () {
      if (drag) { drag = null; saveState(); redraw(); }
    });

    handle.addEventListener('pointerdown', function (ev) {
      if (state.locked) return;
      drag = { mode: 'resize', startX: ev.clientX, startY: ev.clientY,
               orig: { x: state.layout.x, y: state.layout.y, w: state.layout.w, h: state.layout.h } };
      try { handle.setPointerCapture(ev.pointerId); } catch (e) {}
      ev.preventDefault();
      ev.stopPropagation();
    });
    handle.addEventListener('pointermove', function (ev) {
      if (!drag || drag.mode !== 'resize') return;
      state.layout.w = Math.max(320, drag.orig.w + (ev.clientX - drag.startX));
      state.layout.h = Math.max(300, drag.orig.h + (ev.clientY - drag.startY));
      applyLayout();
    });
    handle.addEventListener('pointerup', function () {
      if (drag) { drag = null; saveState(); redraw(); }
    });
  }

  /* ---------------- canvas primitives ---------------- */

  function fitCanvas() {
    if (!canvas || !stageEl) return;
    var w = stageEl.clientWidth, h = stageEl.clientHeight;
    if (w > 0 && h > 0 && (canvas.width !== w || canvas.height !== h)) {
      canvas.width = w;
      canvas.height = h;
    }
  }

  var PLOT = { l: 10, r: 10, t: 16, b: 18 };
  function plotW() { return Math.max(50, canvas.width - PLOT.l - PLOT.r); }
  function plotH() { return Math.max(40, canvas.height - PLOT.t - PLOT.b); }
  function xFor(t) { return PLOT.l + (t / 300) * plotW(); }
  function yFor(price, beat) {
    var span = beat * 0.012; // ±1.2% of the beat fills the plot
    var frac = (price - (beat - span)) / (2 * span);
    return PLOT.t + (1 - clamp(frac, 0, 1)) * plotH();
  }

  function clearPlot() {
    fitCanvas();
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    ctx.strokeStyle = 'rgba(120,140,165,0.18)';
    ctx.lineWidth = 1;
    for (var i = 1; i <= 3; i++) {
      var y = PLOT.t + (plotH() / 4) * i;
      ctx.beginPath(); ctx.moveTo(PLOT.l, y); ctx.lineTo(canvas.width - PLOT.r, y); ctx.stroke();
    }
  }

  function drawBeatLine(beat, color, label) {
    var y = yFor(beat, beat);
    ctx.strokeStyle = color || '#ffd94d';
    ctx.lineWidth = 2;
    ctx.setLineDash([7, 5]);
    ctx.beginPath(); ctx.moveTo(PLOT.l, y); ctx.lineTo(canvas.width - PLOT.r, y); ctx.stroke();
    ctx.setLineDash([]);
    if (label) {
      ctx.fillStyle = color || '#ffd94d';
      ctx.font = 'bold 11px Arial';
      ctx.fillText(label, PLOT.l + 4, y - 5);
    }
    return y;
  }

  function drawSeries(series, upto, beat, color) {
    ctx.strokeStyle = color || '#e8ecf1';
    ctx.lineWidth = 2;
    ctx.beginPath();
    var n = Math.min(upto, series.length - 1);
    for (var i = 0; i <= n; i++) {
      var x = xFor(series[i].t), y = yFor(series[i].price, beat);
      if (i === 0) ctx.moveTo(x, y); else ctx.lineTo(x, y);
    }
    ctx.stroke();
    if (n >= 0 && series[n]) {
      ctx.fillStyle = color || '#e8ecf1';
      ctx.beginPath();
      ctx.arc(xFor(series[n].t), yFor(series[n].price, beat), 3.5, 0, Math.PI * 2);
      ctx.fill();
    }
  }

  function drawMarker(t, beat, price, label, color) {
    var x = xFor(t);
    ctx.strokeStyle = color;
    ctx.lineWidth = 1.5;
    ctx.beginPath(); ctx.moveTo(x, PLOT.t); ctx.lineTo(x, canvas.height - PLOT.b); ctx.stroke();
    ctx.fillStyle = color;
    ctx.beginPath(); ctx.arc(x, yFor(price, beat), 4, 0, Math.PI * 2); ctx.fill();
    ctx.font = 'bold 10px Arial';
    ctx.fillText(label, clamp(x + 4, PLOT.l, canvas.width - 52), PLOT.t + 10);
  }

  function drawBand(yTop, yBot, fill, label, labelColor) {
    ctx.fillStyle = fill;
    ctx.fillRect(PLOT.l, yTop, plotW(), Math.max(2, yBot - yTop));
    if (label) {
      ctx.fillStyle = labelColor || '#a7f3c0';
      ctx.font = 'bold 11px Arial';
      ctx.fillText(label, canvas.width - PLOT.r - 218, yTop + 14);
    }
  }

  function drawHLine(price, beat, color, label) {
    var y = yFor(price, beat);
    ctx.strokeStyle = color;
    ctx.lineWidth = 1.5;
    ctx.setLineDash([4, 4]);
    ctx.beginPath(); ctx.moveTo(PLOT.l, y); ctx.lineTo(canvas.width - PLOT.r, y); ctx.stroke();
    ctx.setLineDash([]);
    if (label) {
      ctx.fillStyle = color;
      ctx.font = 'bold 10px Arial';
      ctx.fillText(label, canvas.width - PLOT.r - 190, y - 4);
    }
    return y;
  }

  function drawArrow(x0, y0, x1, y1, color, label) {
    ctx.strokeStyle = color;
    ctx.fillStyle = color;
    ctx.lineWidth = 2.5;
    ctx.beginPath(); ctx.moveTo(x0, y0); ctx.lineTo(x1, y1); ctx.stroke();
    var ang = Math.atan2(y1 - y0, x1 - x0);
    ctx.beginPath();
    ctx.moveTo(x1, y1);
    ctx.lineTo(x1 - 9 * Math.cos(ang - 0.45), y1 - 9 * Math.sin(ang - 0.45));
    ctx.lineTo(x1 - 9 * Math.cos(ang + 0.45), y1 - 9 * Math.sin(ang + 0.45));
    ctx.closePath(); ctx.fill();
    if (label) {
      ctx.font = 'bold 11px Arial';
      ctx.fillText(label, x0, Math.min(y0, y1) - 8);
    }
  }

  /* ---------------- card rendering ---------------- */

  function setCard(htmlNodes) {
    if (!cardEl) return;
    cardEl.innerHTML = '';
    for (var i = 0; i < htmlNodes.length; i++) cardEl.appendChild(htmlNodes[i]);
  }

  function cardTitle(text, tag) {
    var d = el('div', 'bl-ct');
    d.appendChild(document.createTextNode(text));
    if (tag) d.appendChild(el('span', 'bl-rtag', tag));
    return d;
  }

  function cardBody(text) { return el('div', 'bl-cb', text); }
  function cardRow() { return el('div', 'bl-crow'); }

  function cardBtn(label, cls, fn, dataVal) {
    var b = el('button', cls || null, label);
    if (dataVal !== undefined) b.setAttribute('data-bl-answer', dataVal);
    b.addEventListener('click', fn);
    return b;
  }

  /* ---------------- modes: shared stop ---------------- */

  var timers = { sim: null, test: null };

  function stopEngines() {
    if (timers.sim) { clearInterval(timers.sim); timers.sim = null; }
    if (timers.test) { clearInterval(timers.test); timers.test = null; }
    if (sim.phase === 'playing') sim.phase = 'idle';
    if (test.phase === 'playing' || test.phase === 'paused' || test.phase === 'feedback') test.phase = 'idle';
  }

  function setMode(m) {
    state.mode = m;
    applyModeChrome();
  }

  function showIdle() {
    stopEngines();
    setMode('idle');
    setTag('');
    clearPlot();
    drawBeatLine(BEAT, '#5b6b80', '');
    ctx.fillStyle = '#9fb4c8';
    ctx.font = 'bold 13px Arial';
    ctx.fillText('Pick a mode above: TUTORIAL teaches, FAST SIM shows the hunt,', PLOT.l + 6, canvas.height / 2 - 8);
    ctx.fillText('TEST SIM scores your eye, LIVE paints the real window.', PLOT.l + 6, canvas.height / 2 + 14);
    var nodes = [
      cardTitle('THE LENS — a teaching overlay', 'FREE PLAY'),
      cardBody('Everything here is learning: synthetic windows, plain words, no stakes. ' +
               'The tutorial walks the desk\'s real rules; the sims let you feel them; LIVE mode ' +
               'annotates the real chart from the same watcher stream every layer reads.')
    ];
    setCard(nodes);
  }

  /* ---------------- TUTORIAL ----------------
   * The desk's real rules (ARMED-BUTTON-SPEC.md), simplified for
   * learners. Each card names its own honesty tag: REAL, or DEMO
   * where practice numbers / simplifications stand in. */

  var TUT = [
    {
      tag: 'REAL', hl: 'beat',
      title: '1 · THE PRICE TO BEAT',
      body: 'Every 5-minute window is judged against ONE line: the price to beat, set when the window opens. ' +
            'Finish above it and UP takes the window; below it, DOWN does. Everything the desk does starts here — ' +
            'watch the price against the beat, never the price alone.'
    },
    {
      tag: 'DEMO NUMBERS', hl: 'momentum',
      title: '2 · PLAIN — MOMENTUM VS THE BEAT',
      body: 'PLAIN is the momentum engine. It asks: which side of the beat is the price leaning to, and how hard, ' +
            'with this much clock left? A lean late in the window is strong; the same lean early is weak. ' +
            'On the practice numbers (DEMO), a side at 55% is ARMED — and at 62% it is the CALL.'
    },
    {
      tag: 'REAL', hl: 'flip',
      title: '3 · EARLY — THE FLIP',
      body: 'EARLY is the flip engine. When momentum crosses the beat — the lean changes sides — EARLY is watching ' +
            'that exact moment. The first call is the anchor; the value is in riding the flip, not in marrying the ' +
            'first lean. A cross with strength behind it is a new play, gated like any other.'
    },
    {
      tag: 'REAL · SIMPLIFIED', hl: 'zone',
      title: '4 · FINAL — THE BAR',
      body: 'FINAL is the strict one. It calls only when PLAIN and EARLY agree, the side is strong, AND the entry ' +
            'math pays: the expected move must cover the entry, the fees, and the data charge, with edge to spare ' +
            '(the gate). If any piece is missing, FINAL\'s answer is NO CALL — and a NO CALL is a real answer, ' +
            'not a failure.'
    },
    {
      tag: 'REAL · SIMPLIFIED', hl: 'exit',
      title: '5 · EXITS — THE RESTING SELL',
      body: 'The exit is placed BEFORE the trade needs it: the moment an entry fills, a resting sell sits behind ' +
            'it at the gate-priced exit, holding its place in line. The lose-zero rule: a sell only prints if it ' +
            'comes out PLUS after every cost — otherwise the position holds. And the 98¢ law: never hang at the ' +
            'top waiting for the grand finale; out while well in profit, every time.'
    },
    {
      tag: 'REAL', hl: 'reversal',
      title: '6 · THE REVERSAL',
      body: 'If the flip runs against a position, pressing the opposite side on the page brings up a prompt: ' +
            '"Do you agree to reverse?" That confirm is part of the flow — the desk names it in advance so it is ' +
            'never a surprise. A reversal is a fresh gated play with its own math, never a panic button.'
    }
  ];

  var tut = { step: 0, series: null };

  function startTutorial(step) {
    stopEngines();
    setMode('tutorial');
    tut.step = clamp(step || 0, 0, TUT.length - 1);
    if (!tut.series) tut.series = genSeries(20261115, FAST_KEYS);
    setTag('TEACHING CHART — SYNTHETIC');
    renderTutorial();
  }

  function renderTutorial() {
    var c = TUT[tut.step];
    drawTutorialChart(c.hl);
    var nodes = [cardTitle(c.title, c.tag), cardBody(c.body)];
    var row = cardRow();
    var stepEl = el('span', 'bl-step', 'STEP ' + (tut.step + 1) + ' OF ' + TUT.length);
    row.appendChild(stepEl);
    if (tut.step > 0) {
      row.appendChild(cardBtn('◀ BACK', null, function () { tut.step--; renderTutorial(); }));
    }
    if (tut.step < TUT.length - 1) {
      row.appendChild(cardBtn('NEXT ▶', 'bl-gold', function () { tut.step++; renderTutorial(); }));
    } else {
      row.appendChild(cardBtn('FINISH — TRY THE SIMS', 'bl-gold', function () { showIdle(); }));
    }
    row.appendChild(cardBtn('DON\'T SHOW AGAIN', null, function () {
      state.tutorialOff = true;
      saveState();
      showIdle();
    }));
    nodes.push(row);
    setCard(nodes);
  }

  function drawTutorialChart(hl) {
    clearPlot();
    var s = tut.series;
    drawBeatLine(BEAT, '#ffd94d', 'PRICE TO BEAT');
    drawSeries(s, s.length - 1, BEAT, '#8fa3bd');
    // key story points on the teaching window
    var crossT = firstCross(s);
    var callPt = firstWhere(s, function (p) { return p.upPct >= CALL_PCT; });
    var entryPrice = callPt ? callPt.price : null;
    var exitPrice = entryPrice ? entryPrice * 1.0025 : null;

    if (hl === 'beat') {
      drawBeatLine(BEAT, '#ffd94d', 'PRICE TO BEAT — THE LINE THE WINDOW IS JUDGED AGAINST');
    } else if (hl === 'momentum') {
      var late = s[270];
      drawArrow(xFor(215), yFor(s[215].price, BEAT), xFor(272), yFor(late.price, BEAT),
                '#39d353', 'LATE LEAN = STRONG');
      var early = s[30];
      drawArrow(xFor(6), yFor(s[6].price, BEAT), xFor(52), yFor(early.price, BEAT),
                '#f85149', 'EARLY LEAN = WEAK');
    } else if (hl === 'flip') {
      if (crossT !== null) {
        var cp = s[crossT];
        drawMarker(crossT, BEAT, cp.price, '✕ THE FLIP — EARLY WAKES HERE', '#b197fc');
      }
    } else if (hl === 'zone') {
      var yTop = yFor(BEAT * 1.0042, BEAT), yBot = yFor(BEAT, BEAT);
      drawBand(PLOT.t + 2, yTop, 'rgba(57,211,83,0.20)', 'CALL ZONE — AGREE + STRONG + GATE PAYS', '#a7f3c0');
      if (callPt) drawMarker(callPt.t, BEAT, callPt.price, 'CALL', '#39d353');
      ctx.fillStyle = '#ffa94d';
      ctx.font = 'bold 11px Arial';
      ctx.fillText('BELOW THE BAR = NO CALL — A REAL ANSWER', PLOT.l + 6, yBot + 22);
    } else if (hl === 'exit') {
      if (callPt) drawMarker(callPt.t, BEAT, callPt.price, 'ENTRY', '#39d353');
      if (exitPrice) drawHLine(exitPrice, BEAT, '#ffa94d', 'RESTING SELL — PLACED BEHIND THE ENTRY');
    } else if (hl === 'reversal') {
      if (crossT !== null) {
        var rp = s[crossT];
        drawMarker(crossT, BEAT, rp.price, 'THE FLIP TURNS', '#b197fc');
        ctx.fillStyle = 'rgba(20,12,38,0.92)';
        var bx = clamp(xFor(crossT) + 14, PLOT.l, canvas.width - 250), by = PLOT.t + 26;
        ctx.fillRect(bx, by, 238, 40);
        ctx.strokeStyle = '#b197fc';
        ctx.strokeRect(bx, by, 238, 40);
        ctx.fillStyle = '#e5dbff';
        ctx.font = 'bold 11px Arial';
        ctx.fillText('Page asks: "Do you agree to reverse?"', bx + 9, by + 17);
        ctx.font = '11px Arial';
        ctx.fillText('A confirm step — named, never a surprise.', bx + 9, by + 33);
      }
    }
  }

  function firstCross(s) {
    for (var i = 1; i < s.length; i++) {
      if ((s[i - 1].price - BEAT) * (s[i].price - BEAT) < 0) return i;
    }
    return null;
  }

  function firstWhere(s, fn) {
    for (var i = 0; i < s.length; i++) { if (fn(s[i])) return s[i]; }
    return null;
  }

  /* ---------------- FAST SIM ----------------
   * A 5-minute window compressed to ~30 s (300 points, 100 ms
   * apart). The overlay calls out what the engines look for as it
   * happens: ARM zone, CALL flash, the flip, the resting sell. */

  var sim = { phase: 'idle', idx: 0, series: null, events: [], fired: {}, entered: false, entryPrice: null, exitLine: null, feed: '' };

  function startSim() {
    stopEngines();
    setMode('sim');
    sim.series = genSeries(20261115, FAST_KEYS);
    sim.idx = 0;
    sim.events = [];
    sim.fired = {};
    sim.entered = false;
    sim.entryPrice = null;
    sim.exitLine = null;
    sim.feed = 'Window opens — the price hunts the beat…';
    sim.phase = 'playing';
    setTag('SIMULATION — SYNTHETIC DATA · FREE LEARNING PLAY');
    renderSimCard();
    timers.sim = setInterval(simTick, 100);
  }

  function simEvent(kind, text, t) {
    sim.events.push({ kind: kind, text: text, t: t });
    sim.feed = text;
  }

  function simTick() {
    var s = sim.series;
    if (sim.idx >= s.length - 1) { finishSim(); return; }
    var prev = s[sim.idx];
    sim.idx++;
    var cur = s[sim.idx];

    if (!sim.fired.armDown && cur.downPct >= ARM_PCT) {
      sim.fired.armDown = true;
      simEvent('arm', '🎯 ARM — DOWN reaches ' + Math.round(cur.downPct) + '% (≥55%): PLAIN is leaning, watching', cur.t);
    }
    if (!sim.fired.callDown && cur.downPct >= CALL_PCT) {
      sim.fired.callDown = true;
      simEvent('call', '⚡ CALL — DOWN flashes ' + Math.round(cur.downPct) + '% (≥62%): the call zone', cur.t);
    }
    if (!sim.fired.flip && (prev.price - BEAT) * (cur.price - BEAT) < 0) {
      sim.fired.flip = true;
      simEvent('flip', '🔀 FLIP — momentum crosses the beat: EARLY wakes up', cur.t);
    }
    if (!sim.fired.armUp && cur.upPct >= ARM_PCT) {
      sim.fired.armUp = true;
      simEvent('arm', '🎯 ARM — UP reaches ' + Math.round(cur.upPct) + '% (≥55%)', cur.t);
    }
    if (!sim.fired.callUp && cur.upPct >= CALL_PCT) {
      sim.fired.callUp = true;
      sim.entered = true;
      sim.entryPrice = cur.price;
      sim.exitLine = cur.price * 1.0025;
      simEvent('call', '⚡ CALL — UP flashes ' + Math.round(cur.upPct) + '% (≥62%): FINAL\'s bar is met in the sim — entry marked, resting sell placed behind it', cur.t);
    }
    if (sim.entered && !sim.fired.exit && sim.exitLine && cur.price >= sim.exitLine) {
      sim.fired.exit = true;
      simEvent('exit', '💰 EXIT — price touches the resting sell: the pass is banked, out while in profit', cur.t);
    }
    drawSim();
    renderSimFeed();
  }

  function finishSim() {
    if (timers.sim) { clearInterval(timers.sim); timers.sim = null; }
    sim.phase = 'done';
    var s = sim.series, last = s[s.length - 1];
    var upWin = last.price >= BEAT;
    simEvent('settle', '🏁 SETTLED — price finished ' + (upWin ? 'ABOVE' : 'BELOW') + ' the beat: ' + (upWin ? 'UP' : 'DOWN') + ' takes the window', 300);
    drawSim();
    var nodes = [
      cardTitle('FAST SIM — WINDOW COMPLETE', 'SIMULATION'),
      cardBody('That was one full 5-minute window in ~30 seconds. The overlay flagged exactly what the engines ' +
               'watch: the early DOWN lean, the flip at the beat, the UP call, and the resting sell doing its job.\n' +
               'Events fired: ' + sim.events.map(function (e) { return e.kind.toUpperCase(); }).join(' · ')),
    ];
    var row = cardRow();
    row.appendChild(cardBtn('↻ RUN IT AGAIN', 'bl-gold', function () { startSim(); }));
    row.appendChild(cardBtn('🎯 TRY THE TEST SIM', null, function () { startTest(); }));
    nodes.push(row);
    setCard(nodes);
  }

  function drawSim() {
    clearPlot();
    var s = sim.series;
    drawBeatLine(BEAT, '#ffd94d', 'PRICE TO BEAT');
    if (sim.exitLine) drawHLine(sim.exitLine, BEAT, '#ffa94d', 'RESTING SELL');
    drawSeries(s, sim.idx, BEAT, '#e8ecf1');
    for (var i = 0; i < sim.events.length; i++) {
      var e = sim.events[i];
      if (e.kind === 'settle') continue;
      var p = s[Math.min(e.t, s.length - 1)];
      var col = e.kind === 'call' ? '#39d353' : e.kind === 'flip' ? '#b197fc' : e.kind === 'exit' ? '#ffa94d' : '#ffd94d';
      drawMarker(e.t, BEAT, p.price, e.kind.toUpperCase(), col);
    }
    ctx.fillStyle = '#9fb4c8';
    ctx.font = 'bold 11px Arial';
    var cur = s[sim.idx];
    ctx.fillText('⏳ ' + fmtClock(300 - cur.t) + ' left · UP ' + Math.round(cur.upPct) + '% · DOWN ' + Math.round(cur.downPct) + '%',
                 PLOT.l + 4, canvas.height - 5);
  }

  function renderSimCard() {
    var nodes = [
      cardTitle('FAST SIM — ONE WINDOW, ~30 SECONDS', 'SIMULATION'),
      cardBody('Watch the line hunt the beat. The Lens flags what the engines look for, the moment it happens.')
    ];
    var feed = el('div', 'bl-feed', sim.feed);
    feed.setAttribute('data-bl-feed', '1');
    nodes.push(feed);
    setCard(nodes);
  }

  function renderSimFeed() {
    var f = cardEl ? cardEl.querySelector('[data-bl-feed]') : null;
    if (f) f.textContent = sim.feed;
  }

  /* ---------------- TEST SIM — the scored game ----------------
   * Free learning play. The line plays and PAUSES at decision
   * points; the viewer answers; the desk-correct choice (DEMO
   * rules) scores +100 with a one-line why. No stakes, no orders —
   * points and pride only. */

  var DECISIONS = [
    {
      at: 70, kind: 'entry',
      q: 'UP is FLASHING at 63% with 3:50 left on the clock. Your call?',
      opts: ['UP', 'DOWN', 'PASS'], correct: 'UP',
      whyOk: 'Right — 63% is the call zone (≥62%): the desk takes the strong side.',
      whyNo: 'The strong side was UP at 63% — the flashing side is the play (DEMO rule).'
    },
    {
      at: 130, kind: 'entry',
      q: 'The lean is only 52% — no side is strong, the gate is not met. Your call?',
      opts: ['UP', 'DOWN', 'PASS'], correct: 'PASS',
      whyOk: 'Right — 52% is under the gate. The wait rule: no edge, no entry. Patience is the profit mechanism.',
      whyNo: 'At 52% there is no call — entering here is impulse, not math (the wait rule).'
    },
    {
      at: 200, kind: 'exit',
      q: 'You are in UP from 63%. Your side has slid to 49% with 1:40 left. What now?',
      opts: ['EXIT', 'HOLD'], correct: 'EXIT',
      whyOk: 'Right — a side at 49% is the exit light (≤50%): out, per the exit law.',
      whyNo: 'Holding a side at 49% into the close is how a good pass turns into a loss (DEMO exit rule).'
    },
    {
      at: 250, kind: 'entry',
      q: 'The flip completed and DOWN is now FLASHING at 66% with 0:50 left. Your call?',
      opts: ['UP', 'DOWN', 'PASS'], correct: 'DOWN',
      whyOk: 'Right — after a real flip, the new strong side is a fresh gated play. That is EARLY\'s whole job.',
      whyNo: 'The flip was real and DOWN flashes at 66% — the new strong side is the play (EARLY\'s job).'
    }
  ];

  var test = { phase: 'idle', idx: 0, series: null, di: 0, score: 0, answered: 0, lastGain: 0 };

  function startTest() {
    stopEngines();
    setMode('test');
    test.series = genSeries(777001, TEST_KEYS);
    test.idx = 0;
    test.di = 0;
    test.score = 0;
    test.answered = 0;
    test.lastGain = 0;
    test.phase = 'playing';
    setTag('TEST SIM — A GAME · FREE PLAY · POINTS ONLY');
    renderTestCard();
    timers.test = setInterval(testTick, 60);
  }

  function testTick() {
    var s = test.series;
    if (test.idx >= s.length - 1) { finishTest(); return; }
    test.idx++;
    var d = DECISIONS[test.di];
    if (d && test.idx >= d.at) {
      if (timers.test) { clearInterval(timers.test); timers.test = null; }
      test.phase = 'paused';
      drawTest();
      renderTestCard();
      return;
    }
    drawTest();
  }

  function answerTest(opt) {
    var d = DECISIONS[test.di];
    if (!d || test.phase !== 'paused') return;
    var ok = (opt === d.correct);
    test.lastGain = ok ? 100 : 0;
    test.score += test.lastGain;
    test.answered++;
    test.phase = 'feedback';
    test.lastWhy = ok ? d.whyOk : d.whyNo;
    test.lastOk = ok;
    renderTestCard();
  }

  function continueTest() {
    if (test.phase !== 'feedback') return;
    test.di++;
    if (test.di >= DECISIONS.length) {
      test.idx = test.series.length - 1;
      drawTest();
      finishTest();
      return;
    }
    test.phase = 'playing';
    renderTestCard();
    timers.test = setInterval(testTick, 60);
  }

  function gradeFor(score) {
    if (score >= 400) return 'DESK READY';
    if (score >= 300) return 'SHARP EYE';
    if (score >= 200) return 'LEARNING THE SHAPE';
    if (score >= 100) return 'KEEP PRACTICING';
    return 'FRESH EYES — RUN IT AGAIN';
  }

  function finishTest() {
    if (timers.test) { clearInterval(timers.test); timers.test = null; }
    test.phase = 'done';
    var grade = gradeFor(test.score);
    var scores = saveScore(test.score, grade);
    drawTest();
    var lines = scores.map(function (e, i) {
      return (i + 1) + '. ' + e.score + ' pts — ' + e.grade + ' · ' + e.when;
    }).join('\n');
    var nodes = [
      cardTitle('TEST SIM — RUN COMPLETE', 'GAME OVER'),
      cardBody('Your score: ' + test.score + ' / 400 · Grade: ' + grade +
               '\n🏆 HIGH SCORES (this device)\n' + lines)
    ];
    var row = cardRow();
    row.appendChild(cardBtn('↻ PLAY AGAIN', 'bl-gold', function () { startTest(); }));
    nodes.push(row);
    setCard(nodes);
  }

  function drawTest() {
    clearPlot();
    var s = test.series;
    drawBeatLine(BEAT, '#ffd94d', 'PRICE TO BEAT');
    drawSeries(s, test.idx, BEAT, '#e8ecf1');
    for (var i = 0; i < test.di && i < DECISIONS.length; i++) {
      var d = DECISIONS[i], p = s[d.at];
      drawMarker(d.at, BEAT, p.price, d.kind === 'exit' ? 'EXIT?' : 'CALL?', '#ffd94d');
    }
    var cur = s[test.idx];
    ctx.fillStyle = '#9fb4c8';
    ctx.font = 'bold 11px Arial';
    ctx.fillText('⏳ ' + fmtClock(300 - cur.t) + ' left · UP ' + Math.round(cur.upPct) + '% · DOWN ' + Math.round(cur.downPct) + '%',
                 PLOT.l + 4, canvas.height - 5);
  }

  function renderTestCard() {
    var nodes = [];
    if (test.phase === 'paused') {
      var d = DECISIONS[test.di];
      nodes.push(cardTitle('DECISION ' + (test.di + 1) + ' OF ' + DECISIONS.length + ' — THE LINE PAUSES FOR YOU', 'YOUR CALL'));
      nodes.push(cardBody(d.q));
      var row = cardRow();
      for (var i = 0; i < d.opts.length; i++) {
        (function (opt) {
          var cls = opt === 'UP' ? 'bl-up bl-big' : opt === 'DOWN' ? 'bl-down bl-big' : 'bl-big';
          row.appendChild(cardBtn(opt, cls, function () { answerTest(opt); }, opt));
        })(d.opts[i]);
      }
      var sc = el('span', 'bl-score', 'SCORE ' + test.score);
      row.appendChild(sc);
      nodes.push(row);
    } else if (test.phase === 'feedback') {
      nodes.push(cardTitle(test.lastOk ? '✓ CORRECT — +' + test.lastGain + ' POINTS' : '✗ NOT THE DESK\'S PLAY — +0', 'WHY'));
      nodes.push(cardBody(test.lastWhy));
      var row2 = cardRow();
      row2.appendChild(cardBtn('CONTINUE ▶', 'bl-gold', function () { continueTest(); }));
      row2.appendChild(el('span', 'bl-score', 'SCORE ' + test.score));
      nodes.push(row2);
    } else {
      nodes.push(cardTitle('TEST SIM — READ THE LINE, MAKE THE CALL', 'A GAME'));
      nodes.push(cardBody('The window plays and pauses at the moments that matter. Answer like the desk would. ' +
                          'Points for the right read, a one-line why either way.'));
      var row3 = cardRow();
      row3.appendChild(el('span', 'bl-score', 'SCORE ' + test.score));
      nodes.push(row3);
    }
    setCard(nodes);
  }

  /* ---------------- LIVE mode — the Live Stage (v0.2.0) ----------------
   * Annotates from the shared watcher stream. LIVE now draws the
   * watcher's REAL price series as a moving line (auto-scaled so
   * real moves are visible), fills the engine strip, feeds the
   * effects layer, and keeps the slice-2 honesty: the engines'
   * sealed CALLS are NOT bridged yet — the strip runs on DEMO LAW
   * and says so. */

  var live = { label: '', info: '', watch: '', series: [], seriesSource: 'none',
               seriesLabel: '', hasLine: false, engines: [], aura: 'flat', auraLevel: 0 };
  var prevLive = null;   // last sample seen, for momentum/effects
  var fxState = { bursts: 0, lastBurst: 0 };

  function toggleLive() {
    state.liveOn = !state.liveOn;
    prevEng = null;  // strip edges re-arm on the next live read
    if (state.liveOn) {
      stopEngines();
      setMode('live');
      setTag('LIVE — REAL STREAM');
      prevLive = null;
      liveRefresh();
    } else {
      showIdle();
    }
    applyModeChrome();
  }

  function liveWatchLabel(s) {
    if (!s) return 'PLAIN: watching momentum vs the beat · EARLY: watching for the flip';
    if (s.upPct === null || s.downPct === null) {
      return 'PLAIN: watching momentum vs the beat · EARLY: watching for the flip · FINAL: quiet until both agree + the gate pays';
    }
    var side = s.upPct >= s.downPct ? 'UP' : 'DOWN';
    var pct = Math.max(s.upPct, s.downPct);
    if (pct >= CALL_PCT) return '🔥 ' + side + ' in the CALL zone (' + Math.round(pct) + '% ≥ 62%) — PLAIN\'s call, if FINAL\'s gate pays';
    if (pct >= ARM_PCT) return '🎯 ' + side + ' ARMED (' + Math.round(pct) + '% ≥ 55%) — PLAIN is watching momentum vs the beat';
    return 'PLAIN: watching momentum vs the beat · EARLY: watching for the flip · FINAL: quiet until both agree + the gate pays';
  }

  /* ---- the engine strip: PLAIN / EARLY / FINAL, DEMO LAW ----
   * Each slot's WHY is built only from stream fields (the side %,
   * the signed distance to the beat, the clock, the last cross in
   * the real series). Nothing is invented: an unreadable % reads
   * as exactly that in every slot. */

  function deltaPhrase(s) {
    if (!s || typeof s.currentPrice !== 'number' || typeof s.priceToBeat !== 'number') return 'beat distance unknown';
    var d = s.currentPrice - s.priceToBeat;
    if (Math.abs(d) < 0.005) return 'right on the beat';
    return fmtMoney(Math.abs(d)) + (d > 0 ? ' over beat' : ' under beat');
  }

  function engineStates(s, series) {
    if (!s) {
      return [
        { name: 'PLAIN', lean: '—', pct: null, why: 'no watcher stream yet' },
        { name: 'EARLY', lean: '—', pct: null, why: 'no watcher stream yet' },
        { name: 'FINAL', lean: '—', pct: null, why: 'NO CALL — nothing to judge' }
      ];
    }
    if (s.upPct === null || s.downPct === null) {
      return [
        { name: 'PLAIN', lean: '—', pct: null, why: '% not readable on this page yet' },
        { name: 'EARLY', lean: '—', pct: null, why: 'watching for a cross of the beat' },
        { name: 'FINAL', lean: '—', pct: null, why: 'NO CALL — the % is not readable' }
      ];
    }
    var upSide = s.upPct >= s.downPct;
    var pct = Math.max(s.upPct, s.downPct);
    var plain = {
      name: 'PLAIN', lean: upSide ? '▲' : '▼', pct: pct,
      why: (upSide ? 'Up ' : 'Down ') + Math.round(pct) + '% · ' + deltaPhrase(s) + ' · ' + fmtClock(s.countdownSec) + ' left'
    };
    var earlyLean = null, earlyWhy = '';
    if (series && series.length >= 2 && typeof s.priceToBeat === 'number') {
      var crossT = null;
      for (var i = 1; i < series.length; i++) {
        if ((series[i - 1].price - s.priceToBeat) * (series[i].price - s.priceToBeat) < 0) crossT = series[i].t;
      }
      if (crossT !== null) {
        var above = series[series.length - 1].price >= s.priceToBeat;
        earlyLean = above ? '▲' : '▼';
        var ago = Math.max(0, Math.round((series[series.length - 1].t - crossT) / 1000));
        earlyWhy = 'flip ' + fmtClock(ago) + ' ago — crossed the beat';
      }
    }
    if (earlyLean === null) {
      if (typeof s.currentPrice === 'number' && typeof s.priceToBeat === 'number') {
        earlyLean = s.currentPrice >= s.priceToBeat ? '▲' : '▼';
        earlyWhy = 'no flip yet — price sits ' + deltaPhrase(s);
      } else {
        earlyLean = '—';
        earlyWhy = 'watching for a cross of the beat';
      }
    }
    var early = { name: 'EARLY', lean: earlyLean, pct: pct, why: earlyWhy };
    var fin;
    if (plain.lean === earlyLean && pct >= CALL_PCT) {
      fin = { name: 'FINAL', lean: plain.lean, pct: pct,
              why: 'AGREE + ' + Math.round(pct) + '% ≥ ' + CALL_PCT + '% — the bar is met (DEMO)' };
    } else if (pct < CALL_PCT) {
      fin = { name: 'FINAL', lean: '—', pct: pct,
              why: 'NO CALL — strength ' + Math.round(pct) + '% under the ' + CALL_PCT + '% bar' };
    } else {
      fin = { name: 'FINAL', lean: '—', pct: pct,
              why: 'NO CALL — PLAIN and EARLY do not agree yet' };
    }
    return [plain, early, fin];
  }

  function renderEngines() {
    if (!enginesEl) return;
    for (var i = 0; i < engSlots.length && i < live.engines.length; i++) {
      var e = live.engines[i];
      engSlots[i].top.textContent = e.name + ' ' + e.lean +
        (e.pct !== null && e.pct !== undefined ? ' ' + Math.round(e.pct) + '%' : '');
      engSlots[i].top.style.color = e.lean === '▲' ? '#7ee787' : e.lean === '▼' ? '#ff9d97' : '#e8ecf1';
      engSlots[i].why.textContent = e.why;
    }
  }

  /* ---- effects: momentum aura + capped block bursts ----
   * Pure display. A burst is at most ~44 fresh blocks and the layer
   * never holds more than 60; every block removes itself when its
   * animation ends (plus a timed sweep as a backstop). */

  function updateAura(dir, level) {
    live.aura = dir > 0 ? 'up' : dir < 0 ? 'down' : 'flat';
    live.auraLevel = clamp(level || 0, 0, 1);
    if (!auraEl) return;
    if (!state.effects || dir === 0) {
      auraEl.style.background = 'transparent';
      return;
    }
    var col = dir > 0 ? '57,211,83' : '248,81,73';
    var a = (0.10 + 0.30 * live.auraLevel).toFixed(2);
    auraEl.style.background = 'radial-gradient(ellipse at 50% 62%, rgba(' + col + ',' + a + ') 0%, rgba(' + col + ',0) 68%)';
  }

  function clearParticles() {
    if (fxLayer) fxLayer.innerHTML = '';
  }

  /* Shared particle spawner: n blocks born around (cx, cy) in
   * viewport coordinates, spread spreadX/spreadY px, flying with
   * the move's direction. Used by the momentum bursts (stage-wide)
   * and, since v0.3.0, by call-point bursts born on the line. */
  function spawnParticles(cx, cy, spreadX, spreadY, dir, n) {
    if (!fxLayer) return;
    var room = 60 - fxLayer.childElementCount;
    if (room <= 0) return;
    n = Math.min(room, n);
    var cols = dir > 0 ? ['#39d353', '#ffd94d', '#7ee787', '#ffe98a']
                       : ['#f85149', '#ff7b72', '#e5534b', '#ffa94d'];
    for (var i = 0; i < n; i++) {
      var d = document.createElement('div');
      d.className = 'bl-particle';
      var size = 5 + Math.floor(Math.random() * 7);
      d.style.width = size + 'px';
      d.style.height = size + 'px';
      var col = cols[i % cols.length];
      d.style.background = col;
      if (i % 4 === 0) d.style.boxShadow = '0 0 9px ' + col;
      d.style.left = (cx + (Math.random() - 0.5) * spreadX) + 'px';
      d.style.top = (cy + (Math.random() - 0.5) * spreadY) + 'px';
      fxLayer.appendChild(d);
      var dy = (dir > 0 ? -1 : 1) * (50 + Math.random() * 110);
      var dx = (Math.random() - 0.5) * 60;
      var rot = Math.round((Math.random() - 0.5) * 160);
      var dur = 850 + Math.random() * 650;
      try {
        var anim = d.animate([
          { transform: 'translate(0px,0px) rotate(0deg)', opacity: 1 },
          { transform: 'translate(' + dx + 'px,' + dy + 'px) rotate(' + rot + 'deg)', opacity: 0 }
        ], { duration: dur, easing: 'cubic-bezier(.2,.7,.3,1)' });
        anim.onfinish = (function (node) {
          return function () { if (node.parentNode) node.parentNode.removeChild(node); };
        })(d);
      } catch (e) {}
      setTimeout((function (node) {
        return function () { if (node.parentNode) node.parentNode.removeChild(node); };
      })(d), 2400);
    }
    fxState.bursts++;
    fxState.lastBurst = n;
  }

  function fireBurst(dir, strength) {
    if (!fxLayer || !stageEl) return;
    var r = stageEl.getBoundingClientRect();
    spawnParticles(r.left + r.width / 2, r.top + r.height * 0.5,
                   Math.max(10, r.width), Math.max(10, r.height * 0.3), dir,
                   clamp(Math.round(16 + (strength || 0)), 16, 44));
  }

  /* v0.3.0: a burst born at a call point on the line. The block
   * count follows the call's % — the loudness tiers: under 70 a
   * murmur, 70–85 a statement, 85–95 loud, 95+ the full fountain. */
  function fireBurstAt(cx, cy, dir, pct) {
    var n = (typeof pct === 'number' && pct >= 95) ? 44 :
            (typeof pct === 'number' && pct >= 85) ? 36 :
            (typeof pct === 'number' && pct >= 70) ? 26 : 16;
    spawnParticles(cx, cy, 30, 18, dir, n);
  }

  /* Momentum between consecutive stream samples drives the aura
   * every refresh and fires a burst on a strong move: a % swing of
   * 6+ points, or a price jump of ~0.08% of the beat. */
  function maybeEffects(s) {
    if (!s) { prevLive = null; return; }
    if (prevLive && s.ts && s.ts !== prevLive.ts && s.fresh) {
      var dMom = (s.upPct !== null && prevLive.upPct !== null) ? s.upPct - prevLive.upPct : 0;
      var dPrice = (typeof s.currentPrice === 'number' && typeof prevLive.price === 'number')
        ? s.currentPrice - prevLive.price : 0;
      var beatRef = (typeof s.priceToBeat === 'number' && s.priceToBeat > 0) ? s.priceToBeat : 65000;
      var dir = Math.abs(dMom) >= 2 ? (dMom > 0 ? 1 : -1) : (dPrice > 0 ? 1 : dPrice < 0 ? -1 : 0);
      var level = Math.max(Math.abs(dMom) / 20, Math.abs(dPrice) / (beatRef * 0.004));
      updateAura(state.effects ? dir : 0, level);
      var spike = Math.abs(dMom) >= 6 || Math.abs(dPrice) >= beatRef * 0.0008;
      if (spike && dir !== 0 && state.effects) {
        fireBurst(dir, Math.max(Math.abs(dMom), Math.abs(dPrice) / (beatRef * 0.001)));
      }
    }
    prevLive = { ts: s.ts, price: s.currentPrice, upPct: s.upPct };
  }

  /* ---------------- CALL POINTS + position annotations (v0.3.0) ----
   * Markers pin ON the live line, anchored to the sample time and
   * price where the event landed — never to screen pixels — so they
   * ride the line as it scrolls. Sources, all already in the house:
   * Board flashes (via boardWatch), Trigger practice sequences (via
   * onSequenceEvent), the engine strip's own edges (PLAIN entering
   * the call zone, FINAL reaching agreement, EARLY's flip across
   * the beat — the strip is DEMO LAW and the markers inherit that),
   * and the Board's Scorekeeper store for position annotations.
   * The Scorekeeper store is read exactly like the tap journal:
   * defensively, and a field it does not carry produces no
   * annotation. The Trigger's sequence detail carries no engine
   * field today, so only strip-derived markers wear an engine
   * initial; flash and sequence markers honestly wear none. */

  var markers = [];         // oldest -> newest, cap MARKER_CAP, per window
  var markerWindow = null;  // the stream window the markers belong to
  var pendingBursts = [];   // call points waiting for their on-line burst
  var linePulse = null;     // {color, until} — the fresh segment's pulse
  var prevEng = null;       // engine-strip edge state

  var posState = { open: false, side: null, entryPct: null, entryT: null, entryPrice: null };
  var feedSeen = {};        // Scorekeeper feed signatures already annotated
  var scorePrimed = false;  // the first store sighting adopts silently

  function fmtTOD(ms) {
    try {
      var d = new Date(ms);
      function p2(n) { return (n < 10 ? '0' : '') + n; }
      return p2(d.getHours()) + ':' + p2(d.getMinutes()) + ':' + p2(d.getSeconds());
    } catch (e) { return ''; }
  }

  /* Where "now" sits on the line: the newest real series point when
   * one exists, else the newest sample's own timestamp + price. */
  function anchorNow() {
    var stream = watcherStream();
    if (stream.series.length) {
      var last = stream.series[stream.series.length - 1];
      return { t: last.t, price: last.price, sample: stream.sample };
    }
    var s = stream.sample;
    if (s) {
      var t = s.ts ? Date.parse(s.ts) : NaN;
      return { t: isNaN(t) ? Date.now() : t,
               price: (typeof s.currentPrice === 'number') ? s.currentPrice : null,
               sample: s };
    }
    return { t: Date.now(), price: null, sample: null };
  }

  /* The real price nearest a moment: the series point closest to
   * it, else the current sample's price, else nothing (and then the
   * annotation that needed it simply does not draw). */
  function priceNear(t) {
    var stream = watcherStream();
    var best = null, bd = Infinity;
    for (var i = 0; i < stream.series.length; i++) {
      var d = Math.abs(stream.series[i].t - t);
      if (d < bd) { bd = d; best = stream.series[i].price; }
    }
    if (best !== null) return best;
    var s = stream.sample;
    return (s && typeof s.currentPrice === 'number') ? s.currentPrice : null;
  }

  function addMarker(m) {
    if (!m || typeof m.t !== 'number' || isNaN(m.t)) return null;
    for (var i = 0; i < markers.length; i++) {
      var o = markers[i];
      if (o.kind === m.kind && o.side === m.side && o.engine === m.engine &&
          Math.abs(o.t - m.t) <= 1500) return null;
    }
    markers.push(m);
    markers.sort(function (a, b) { return a.t - b.t; });
    while (markers.length > MARKER_CAP) markers.shift();
    if (state.effects && state.liveOn && (m.kind === 'call' || m.kind === 'entry')) {
      pendingBursts.push({ t: m.t, price: m.price, born: Date.now(),
                           dir: m.side === 'down' ? -1 : 1, pct: m.pct });
      linePulse = { color: m.side === 'down' ? '#f85149' : '#39d353', until: Date.now() + 900 };
    }
    return m;
  }

  function callLabel(verb, pct, t) {
    return verb + (typeof pct === 'number' ? ' · ' + Math.round(pct) + '%' : '') + ' · ' + fmtTOD(t);
  }

  /* Engine-strip edges: a marker is born when a strip state ENTERS
   * its call moment, not on every refresh it persists. */
  function engineEdges(s, series, engines) {
    if (!s || !s.fresh || s.upPct === null || s.downPct === null) { prevEng = null; return; }
    var upSide = s.upPct >= s.downPct;
    var side = upSide ? 'up' : 'down';
    var pct = Math.max(s.upPct, s.downPct);
    var lastPt = (series && series.length) ? series[series.length - 1] : null;
    var t = lastPt ? lastPt.t : (s.ts ? Date.parse(s.ts) : Date.now());
    if (typeof t !== 'number' || isNaN(t)) t = Date.now();
    var price = lastPt ? lastPt.price : (typeof s.currentPrice === 'number' ? s.currentPrice : null);
    var crossT = null, crossPrice = null;
    if (series && series.length >= 2 && typeof s.priceToBeat === 'number') {
      for (var i = 1; i < series.length; i++) {
        if ((series[i - 1].price - s.priceToBeat) * (series[i].price - s.priceToBeat) < 0) {
          crossT = series[i].t; crossPrice = series[i].price;
        }
      }
    }
    var cur = {
      plainCall: pct >= CALL_PCT,
      finalAgree: !!(engines && engines[2] && /^AGREE/.test(engines[2].why || '')),
      crossT: crossT
    };
    if (prevEng) {
      var verb = side === 'up' ? 'BUY UP' : 'BUY DOWN';
      if (cur.plainCall && !prevEng.plainCall) {
        addMarker({ t: t, price: price, side: side, pct: pct, engine: 'PLAIN',
                    kind: 'call', label: callLabel(verb, pct, t) });
      }
      if (cur.finalAgree && !prevEng.finalAgree) {
        addMarker({ t: t, price: price, side: side, pct: pct, engine: 'FINAL',
                    kind: 'call', label: callLabel(verb, pct, t) });
      }
      if (cur.crossT !== null && prevEng.crossT !== null && cur.crossT !== prevEng.crossT) {
        var fside = (typeof crossPrice === 'number' && typeof s.priceToBeat === 'number' &&
                     crossPrice >= s.priceToBeat) ? 'up' : 'down';
        addMarker({ t: cur.crossT, price: crossPrice, side: fside, pct: pct, engine: 'EARLY',
                    kind: 'call', label: callLabel('FLIP ' + fside.toUpperCase(), pct, cur.crossT) });
      }
    }
    prevEng = cur;
  }

  /* ---- the Scorekeeper store: position annotations ---- */

  function readScore() {
    try {
      var raw = window.localStorage.getItem(SCORE_KEY);
      if (!raw) return null;
      var sc = JSON.parse(raw);
      return (sc && typeof sc === 'object') ? sc : null;
    } catch (e) { return null; }
  }

  function feedSig(e) {
    return String(e.t || '') + '|' + String(e.kind || '') + '|' + String(e.label || '');
  }

  /* The entry moment of the open point: the newest POINT entry in
   * the flags feed, while it is still this window's news. */
  function pointEntryT(feed) {
    for (var i = 0; i < feed.length; i++) {
      if (feed[i] && feed[i].kind === 'point') {
        var t = Date.parse(feed[i].t || '');
        if (!isNaN(t) && Date.now() - t <= 10 * 60 * 1000) return t;
      }
    }
    return null;
  }

  function adoptOpen(sc, feed, silent) {
    var oe = sc.openEntry;
    var et = pointEntryT(feed);
    posState.open = true;
    posState.side = oe.side;
    posState.entryPct = (typeof oe.entryPct === 'number') ? oe.entryPct : null;
    posState.entryT = (et !== null) ? et : Date.now();
    posState.entryPrice = priceNear(posState.entryT);
    if (!silent) {
      addMarker({ t: posState.entryT, price: posState.entryPrice, side: oe.side,
                  pct: posState.entryPct, engine: null, kind: 'entry',
                  label: callLabel('ENTRY · ' + (oe.side === 'up' ? 'BUY UP' : 'BUY DOWN'),
                                   posState.entryPct, posState.entryT) });
    }
  }

  function onFeedEntry(e) {
    var t = Date.parse(e.t || '');
    if (isNaN(t)) return;
    var side = posState.open ? posState.side : null;
    if (e.kind === 'takeprofit') {
      addMarker({ t: t, price: priceNear(t), side: side, pct: null, engine: null,
                  kind: 'exitlight', label: 'EXIT LIGHT · ' + fmtTOD(t) });
    } else if (e.kind === 'exit') {
      addMarker({ t: t, price: priceNear(t), side: side, pct: null, engine: null,
                  kind: 'exit', label: 'EXIT ✓ · ' + fmtTOD(t) });
    } else if (e.kind === 'missed-exit') {
      var pm = /your side (\d+(?:\.\d+)?)%/.exec(String(e.label || ''));
      addMarker({ t: t, price: priceNear(t), side: side,
                  pct: pm ? parseFloat(pm[1]) : null, engine: null,
                  kind: 'missed-exit', label: 'MISSED EXIT ⚑ · ' + fmtTOD(t) });
    }
  }

  /* One read of the Scorekeeper store per poll tick. The first
   * sighting primes silently (history is not re-annotated; a point
   * already open is adopted so the HOLDING tag is truthful). After
   * that, new feed entries and open-point transitions annotate as
   * they happen. */
  function scoreWatch() {
    var sc = readScore();
    if (!sc) return;
    var feed = (Object.prototype.toString.call(sc.feed) === '[object Array]') ? sc.feed : [];
    var oe = (sc.openEntry && (sc.openEntry.side === 'up' || sc.openEntry.side === 'down'))
             ? sc.openEntry : null;
    var i, e;
    if (!scorePrimed) {
      for (i = 0; i < feed.length; i++) { if (feed[i]) feedSeen[feedSig(feed[i])] = 1; }
      if (oe) adoptOpen(sc, feed, true);
      scorePrimed = true;
      return;
    }
    var fresh = [];
    for (i = 0; i < feed.length; i++) {
      e = feed[i];
      if (e && !feedSeen[feedSig(e)]) { feedSeen[feedSig(e)] = 1; fresh.push(e); }
    }
    if (Object.keys(feedSeen).length > 400) {  // bound the seen-set
      feedSeen = {};
      for (i = 0; i < feed.length; i++) { if (feed[i]) feedSeen[feedSig(feed[i])] = 1; }
    }
    fresh.reverse();  // the feed is newest-first; annotate oldest first
    for (i = 0; i < fresh.length; i++) onFeedEntry(fresh[i]);
    if (oe && (!posState.open || posState.side !== oe.side)) {
      adoptOpen(sc, feed, false);
    } else if (!oe && posState.open) {
      posState.open = false;
      posState.side = null;
      posState.entryPct = null;
    }
    if (oe && posState.open && typeof oe.entryPct === 'number') posState.entryPct = oe.entryPct;
  }

  /* The holding tag's words: side, elapsed, and the position's
   * current % read from the stream — each part only when its datum
   * exists. */
  function holdLabel() {
    if (!posState.open) return '';
    var parts = ['HOLDING' + (posState.side ? ' ' + posState.side.toUpperCase() : '')];
    if (posState.entryT) {
      parts.push(fmtClock(Math.max(0, (Date.now() - posState.entryT) / 1000)));
    }
    var s = watcherSample();
    if (s) {
      var p = posState.side === 'up' ? s.upPct : s.downPct;
      if (typeof p === 'number') parts.push(Math.round(p) + '%');
    }
    return parts.join(' · ');
  }

  function markerColor(m) {
    if (m.kind === 'exit') return '#ffd94d';
    if (m.kind === 'missed-exit' || m.kind === 'exitlight') return '#ffa94d';
    if (m.side === 'down') return '#f85149';
    if (m.side === 'up') return '#39d353';
    return '#e8ecf1';
  }

  function markerGlyph(m) {
    if (m.engine) return m.engine.charAt(0);
    if (m.kind === 'entry') return 'E';
    if (m.kind === 'exit') return '✓';
    if (m.kind === 'missed-exit') return '⚑';
    if (m.kind === 'exitlight') return '!';
    return '•';
  }

  /* Draw the window's markers on the live line, using the chart's
   * own X/Y so a marker sits exactly on its sample point. Older
   * markers fade; labels stagger so neighbours do not collide. */
  function drawMarkers(X, Y) {
    var n = markers.length, i, m;
    for (i = 0; i < n; i++) {
      m = markers[i];
      if (typeof m.price !== 'number' || !isFinite(m.price)) continue;
      var x = X(m.t), y = Y(m.price);
      if (x < PLOT.l - 6 || x > canvas.width - PLOT.r + 6) continue;
      var fade = n > 1 ? 1 - 0.6 * ((n - 1 - i) / (n - 1)) : 1;
      var col = markerColor(m);
      ctx.save();
      ctx.globalAlpha = Math.max(0.35, fade);
      ctx.strokeStyle = col;
      ctx.lineWidth = 1.5;
      ctx.beginPath(); ctx.moveTo(x, y); ctx.lineTo(x, y - 13); ctx.stroke();
      ctx.fillStyle = col;
      ctx.beginPath(); ctx.arc(x, y, 8, 0, Math.PI * 2); ctx.fill();
      ctx.strokeStyle = '#0b0e14';
      ctx.lineWidth = 2;
      ctx.beginPath(); ctx.arc(x, y, 8, 0, Math.PI * 2); ctx.stroke();
      ctx.fillStyle = '#0b0e14';
      ctx.font = '900 10px Arial';
      ctx.textAlign = 'center';
      ctx.fillText(markerGlyph(m), x, y + 3.5);
      ctx.textAlign = 'left';
      ctx.font = 'bold 10px Arial';
      var tw = ctx.measureText(m.label).width;
      var lx = clamp(x + 10, PLOT.l, Math.max(PLOT.l, canvas.width - PLOT.r - tw - 2));
      var ly = y - 20 - (i % 2) * 13;
      if (ly < PLOT.t + 10) ly = y + 26 + (i % 2) * 13;
      ctx.fillStyle = 'rgba(6,9,15,0.78)';
      ctx.fillRect(lx - 2, ly - 9, tw + 4, 12);
      ctx.fillStyle = col;
      ctx.fillText(m.label, lx, ly);
      ctx.restore();
    }
    // Pending bursts are born at their marker's spot on the line.
    if (pendingBursts.length) {
      var pb = pendingBursts;
      pendingBursts = [];
      if (state.effects && stageEl) {
        var r = stageEl.getBoundingClientRect();
        for (i = 0; i < pb.length; i++) {
          if (typeof pb[i].price !== 'number') continue;
          if (Date.now() - (pb[i].born || 0) > 2000) continue;
          fireBurstAt(r.left + X(pb[i].t), r.top + Y(pb[i].price), pb[i].dir, pb[i].pct);
        }
      }
    }
  }

  /* The HOLDING tag rides the line's head while a point is open. */
  function drawHoldTag(X, Y, last) {
    var txt = holdLabel();
    if (!txt || !last) return;
    var x = X(last.t), y = Y(last.price);
    ctx.font = 'bold 10px Arial';
    var tw = ctx.measureText(txt).width;
    var lx = clamp(x - tw - 16, PLOT.l, Math.max(PLOT.l, canvas.width - PLOT.r - tw - 4));
    var ly = clamp(y - 24, PLOT.t + 12, canvas.height - PLOT.b - 4);
    ctx.fillStyle = 'rgba(20,16,4,0.85)';
    ctx.fillRect(lx - 3, ly - 10, tw + 6, 14);
    ctx.strokeStyle = '#ffd94d';
    ctx.lineWidth = 1;
    ctx.strokeRect(lx - 3, ly - 10, tw + 6, 14);
    ctx.fillStyle = '#ffe98a';
    ctx.fillText(txt, lx, ly);
  }

  function liveRefresh() {
    var stream = watcherStream();
    var s = stream.sample;
    var tap = lastTapStat();
    live.series = stream.series;
    live.seriesSource = stream.seriesSource;
    live.hasLine = stream.series.length >= 2;
    live.seriesLabel = live.hasLine ? 'live' : 'warming-up';
    live.engines = engineStates(s, stream.series);

    if (!s) {
      live.label = 'no-stream';
      live.info = 'LIVE: no watcher stream on this device yet — Pack #2\'s watcher writes it when a 5-minute page is open.';
      live.watch = liveWatchLabel(null);
      drawLive(stream, tap);
      renderEngines();
      renderLiveCard(tap);
      return;
    }

    var ageTxt = (s.ageMs === null) ? 'age —' : 'stream age ' + (s.ageMs / 1000).toFixed(1) + 's';

    if (!s.fresh) {
      live.label = 'stale';
      live.info = 'LIVE: watcher stream is STALE (' + ageTxt + ') — showing the last read, not a live one.';
    } else if (s.upPct === null || s.downPct === null) {
      live.label = 'no-pct';
      live.info = '⏳ ' + fmtClock(s.countdownSec) + ' · Beat ' + fmtMoney(s.priceToBeat) + ' · Now ' + fmtMoney(s.currentPrice) +
                  ' · ' + ageTxt + '\nbeat + clock live; % not readable on this page yet';
    } else {
      live.label = 'watching';
      live.info = '⏳ ' + fmtClock(s.countdownSec) + ' · Up ' + Math.round(s.upPct) + '% · Down ' + Math.round(s.downPct) + '%' +
                  ' · Beat ' + fmtMoney(s.priceToBeat) + ' · Now ' + fmtMoney(s.currentPrice) + ' · ' + ageTxt;
    }
    if (!live.hasLine && s.fresh) {
      live.info += '\nseries warming up — the line draws itself when real points land';
    }
    if (s.pctSource) {
      live.info += '\n% source: ' + s.pctSource + ' (watcher-tagged)';
    }
    live.watch = liveWatchLabel(s.fresh ? s : null);
    // Call points belong to their window: a rolled window starts
    // the line's story over, and the strip edges re-arm.
    if (s.window) {
      if (markerWindow && markerWindow !== s.window) {
        markers = [];
        pendingBursts = [];
        prevEng = null;
      }
      markerWindow = s.window;
    }
    engineEdges(s, stream.series, live.engines);
    maybeEffects(s);
    drawLive(stream, tap);
    renderEngines();
    renderLiveCard(tap);
  }

  function drawLive(stream, tap) {
    var s = stream ? stream.sample : null;
    var series = stream ? (stream.series || []) : [];
    PLOT.t = 58; // the engine strip owns the stage top in LIVE
    clearPlot();
    if (!s || !s.priceToBeat) {
      ctx.fillStyle = '#9fb4c8';
      ctx.font = 'bold 13px Arial';
      ctx.fillText(s ? 'WAITING FOR A BEAT IN THE STREAM…' : 'NO WATCHER STREAM YET', PLOT.l + 6, canvas.height / 2);
      PLOT.t = 16;
      return;
    }
    var beat = s.priceToBeat;
    if (live.hasLine) {
      drawLiveSeries(series, beat, s);
    } else {
      // Warming up: the beat + the latest price dot, honestly
      // labelled. NEVER a flat line dressed up as live data.
      drawBeatLine(beat, s.fresh ? '#ffd94d' : '#8a6d1f',
                   'PRICE TO BEAT ' + fmtMoney(beat) + (s.fresh ? '' : ' · STALE'));
      if (typeof s.currentPrice === 'number') {
        var cx = PLOT.l + plotW() / 2, cy = yFor(s.currentPrice, beat);
        ctx.fillStyle = '#39d353';
        ctx.beginPath(); ctx.arc(cx, cy, 4.5, 0, Math.PI * 2); ctx.fill();
        ctx.font = 'bold 11px Arial';
        ctx.fillText('NOW ' + fmtMoney(s.currentPrice), cx + 9, cy + 4);
      }
      ctx.fillStyle = '#ffa94d';
      ctx.font = 'bold 12px Arial';
      ctx.fillText('SERIES WARMING UP — no line until real points land', PLOT.l + 4, PLOT.t + 14);
    }
    if (tap) {
      ctx.fillStyle = '#7ee787';
      ctx.font = 'bold 11px Arial';
      ctx.fillText(tap + '  (Board tap journal)', PLOT.l + 4, canvas.height - 5);
    }
    PLOT.t = 16;
  }

  /* The REAL series, drawn as a moving line. The y-axis auto-scales
   * to the data (beat included, padded, with a floor span) so real
   * 5-minute moves are actually visible — a fixed ±1.2% axis is
   * what made the old now-line read as a flat line. The drawn range
   * is printed on the chart, so the scale is never a secret. */
  function drawLiveSeries(series, beat, s) {
    var lo = beat, hi = beat, i;
    for (i = 0; i < series.length; i++) {
      lo = Math.min(lo, series[i].price);
      hi = Math.max(hi, series[i].price);
    }
    var span = Math.max(hi - lo, beat * 0.0006);
    lo -= span * 0.18;
    hi += span * 0.18;
    var t0 = series[0].t, t1 = series[series.length - 1].t;
    if (t1 <= t0) t1 = t0 + 1000;
    var ext = (t1 - t0) * 0.03 + 500;
    function X(t) { return PLOT.l + ((t - t0) / (t1 - t0 + ext)) * plotW(); }
    function Y(price) { return PLOT.t + (1 - clamp((price - lo) / (hi - lo), 0, 1)) * plotH(); }

    ctx.strokeStyle = (s && !s.fresh) ? '#8a6d1f' : '#ffd94d';
    ctx.lineWidth = 2;
    ctx.setLineDash([7, 5]);
    ctx.beginPath(); ctx.moveTo(PLOT.l, Y(beat)); ctx.lineTo(canvas.width - PLOT.r, Y(beat)); ctx.stroke();
    ctx.setLineDash([]);
    ctx.fillStyle = '#ffd94d';
    ctx.font = 'bold 11px Arial';
    ctx.fillText('PRICE TO BEAT ' + fmtMoney(beat) + ((s && !s.fresh) ? ' · STALE' : ''), PLOT.l + 4, Y(beat) - 5);

    ctx.strokeStyle = '#e8ecf1';
    ctx.lineWidth = 2;
    ctx.beginPath();
    for (i = 0; i < series.length; i++) {
      var x = X(series[i].t), y = Y(series[i].price);
      if (i === 0) ctx.moveTo(x, y); else ctx.lineTo(x, y);
    }
    ctx.stroke();
    var last = series[series.length - 1];
    ctx.fillStyle = '#39d353';
    ctx.beginPath(); ctx.arc(X(last.t), Y(last.price), 4, 0, Math.PI * 2); ctx.fill();
    ctx.font = 'bold 11px Arial';
    ctx.fillText('NOW ' + fmtMoney(last.price), clamp(X(last.t) - 100, PLOT.l, canvas.width - 116), Y(last.price) - 8);

    // v0.3.0: when a call point just landed, the fresh segment
    // pulses once in the side's colour.
    if (linePulse && Date.now() < linePulse.until && series.length >= 2) {
      var p0 = series[series.length - 2];
      ctx.save();
      ctx.globalAlpha = 0.75;
      ctx.strokeStyle = linePulse.color;
      ctx.lineWidth = 4;
      ctx.beginPath(); ctx.moveTo(X(p0.t), Y(p0.price)); ctx.lineTo(X(last.t), Y(last.price)); ctx.stroke();
      ctx.restore();
    }

    // v0.3.0: call points + position annotations ride the line.
    drawMarkers(X, Y);
    drawHoldTag(X, Y, last);

    ctx.fillStyle = '#9fb4c8';
    ctx.font = 'bold 10px Arial';
    ctx.fillText(series.length + ' real points · range ' + fmtMoney(lo) + '–' + fmtMoney(hi) +
                 ' · source: ' + (live.seriesSource === 'watcher' ? 'watcher series' : 'stream log'),
                 PLOT.l + 4, canvas.height - 18);
  }

  function renderLiveCard(tap) {
    var nodes = [
      cardTitle('LIVE — WHAT THE ENGINES ARE WATCHING', 'WATCHER STREAM'),
      cardBody(live.info)
    ];
    var watch = el('div', 'bl-feed', live.watch || liveWatchLabel(null));
    watch.setAttribute('data-bl-watch', '1');
    nodes.push(watch);
    var honest = el('div', 'bl-honest',
      'The engines\' sealed CALLS are not bridged yet (slice 2) — this shows what they watch, not their calls.');
    nodes.push(honest);
    if (tap) nodes.push(el('div', 'bl-cb', tap + ' — your last flash→tap reaction (Board journal)'));
    setCard(nodes);
  }

  /* ---------------- blob-connect links + press sequences (v0.2.0) ----------------
   * A full-viewport SVG layer (pointer-events:none, below every
   * pack panel) draws the wiring between the packs: faint dotted
   * links from each Trigger FIRE button to its Board twin, and from
   * Board SELL to REVERSAL. When the Trigger announces a practice
   * sequence (the receive-only "blobbtn:sequence" window event) —
   * or a Board light fires — the chain lights in order with
   * numbered badges and a callout naming the press. Elements are
   * located defensively by the other packs' known ids/classes; a
   * missing element simply drops its link, silently. The Lens only
   * ever READS these elements' positions and the Board's state
   * attributes — it writes nothing to them. */

  var SVGNS = 'http://www.w3.org/2000/svg';

  var LINK_TARGETS = {
    fireUp:   ['#blobbtn-trigger [data-bt-id="fireUp"]', '#blobbtn-trigger .bt-fire.up'],
    fireDown: ['#blobbtn-trigger [data-bt-id="fireDown"]', '#blobbtn-trigger .bt-fire.down'],
    buyUp:    ['#blobbtn-board .bb-btn[data-bb-id="buyUp"]'],
    buyDown:  ['#blobbtn-board .bb-btn[data-bb-id="buyDown"]'],
    sell:     ['#blobbtn-board .bb-btn[data-bb-id="sell"]'],
    reversal: ['#blobbtn-board .bb-btn[data-bb-id="reversal"]']
  };
  var PRESS_NAMES = { fireUp: 'FIRE UP', fireDown: 'FIRE DOWN', buyUp: 'BUY UP',
                      buyDown: 'BUY DOWN', sell: 'SELL', reversal: 'REVERSAL' };
  var IDLE_LINKS = [['fireUp', 'buyUp'], ['fireDown', 'buyDown'], ['sell', 'reversal']];

  function findTarget(key) {
    var sels = LINK_TARGETS[key] || [];
    for (var i = 0; i < sels.length; i++) {
      var found = null;
      try { found = document.querySelector(sels[i]); } catch (e) {}
      if (found) return found;
    }
    return null;
  }

  function centerOf(elm) {
    if (!elm) return null;
    var r = elm.getBoundingClientRect();
    if (!r || (r.width === 0 && r.height === 0)) return null;
    return { x: r.left + r.width / 2, y: r.top + r.height / 2 };
  }

  function linkPath(a, b) {
    var mx = (a.x + b.x) / 2, my = (a.y + b.y) / 2 - 26;
    return 'M ' + a.x.toFixed(1) + ' ' + a.y.toFixed(1) +
           ' Q ' + mx.toFixed(1) + ' ' + my.toFixed(1) + ' ' +
           b.x.toFixed(1) + ' ' + b.y.toFixed(1);
  }

  var linkEls = {};   // 'a->b' -> idle path element
  var chain = { steps: [], litPairs: [], badges: [], callout: '', timers: [] };

  function drawLinks() {
    if (!linksSvg) return;
    var i, key, p, pa, pb;
    for (i = 0; i < IDLE_LINKS.length; i++) {
      key = IDLE_LINKS[i][0] + '->' + IDLE_LINKS[i][1];
      pa = centerOf(findTarget(IDLE_LINKS[i][0]));
      pb = centerOf(findTarget(IDLE_LINKS[i][1]));
      p = linkEls[key] || null;
      if (pa && pb) {
        if (!p) {
          p = document.createElementNS(SVGNS, 'path');
          p.setAttribute('class', 'bl-link');
          p.setAttribute('data-bl-link', key);
          linksSvg.appendChild(p);
          linkEls[key] = p;
        }
        p.setAttribute('d', linkPath(pa, pb));
        p.style.display = '';
      } else if (p) {
        p.style.display = 'none';
      }
    }
    for (i = 0; i < chain.litPairs.length; i++) {
      var lp = chain.litPairs[i];
      var ca = centerOf(findTarget(lp.a)), cb = centerOf(findTarget(lp.b));
      if (ca && cb) lp.el.setAttribute('d', linkPath(ca, cb));
    }
    for (i = 0; i < chain.badges.length; i++) {
      var bg = chain.badges[i];
      var c = centerOf(findTarget(bg.key));
      if (c) bg.g.setAttribute('transform', 'translate(' + c.x + ',' + (c.y - 34) + ')');
    }
  }

  function clearChain() {
    var i;
    for (i = 0; i < chain.timers.length; i++) clearTimeout(chain.timers[i]);
    chain.timers = [];
    for (i = 0; i < chain.litPairs.length; i++) {
      if (chain.litPairs[i].el.parentNode) chain.litPairs[i].el.parentNode.removeChild(chain.litPairs[i].el);
    }
    for (i = 0; i < chain.badges.length; i++) {
      if (chain.badges[i].g.parentNode) chain.badges[i].g.parentNode.removeChild(chain.badges[i].g);
    }
    chain.litPairs = [];
    chain.badges = [];
    chain.steps = [];
    chain.callout = '';
    if (calloutEl) calloutEl.style.display = 'none';
  }

  function lightChain(steps) {
    clearChain();
    if (!linksSvg || !steps || !steps.length) return;
    var keys = [];
    for (var i = 0; i < steps.length; i++) {
      if (findTarget(steps[i])) keys.push(steps[i]);
    }
    if (!keys.length) return;
    chain.steps = keys.slice();
    keys.forEach(function (key, idx) {
      var t = setTimeout(function () {
        var c = centerOf(findTarget(key));
        if (c) {
          var g = document.createElementNS(SVGNS, 'g');
          g.setAttribute('class', 'bl-badge');
          g.setAttribute('data-bl-badge', String(idx + 1));
          g.setAttribute('transform', 'translate(' + c.x + ',' + (c.y - 34) + ')');
          var circ = document.createElementNS(SVGNS, 'circle');
          circ.setAttribute('r', '12');
          var tx = document.createElementNS(SVGNS, 'text');
          tx.setAttribute('y', '5');
          tx.textContent = String(idx + 1);
          g.appendChild(circ);
          g.appendChild(tx);
          linksSvg.appendChild(g);
          chain.badges.push({ key: key, g: g });
        }
        if (idx > 0) {
          var prev = keys[idx - 1];
          var p = document.createElementNS(SVGNS, 'path');
          p.setAttribute('class', 'bl-link bl-lit');
          p.setAttribute('data-bl-lit', prev + '->' + key);
          var ca = centerOf(findTarget(prev)), cb = centerOf(findTarget(key));
          if (ca && cb) p.setAttribute('d', linkPath(ca, cb));
          linksSvg.appendChild(p);
          chain.litPairs.push({ a: prev, b: key, el: p });
        }
        chain.callout = 'PRESS: ' + (PRESS_NAMES[key] || key.toUpperCase());
        if (calloutEl) {
          calloutEl.textContent = '👉 ' + chain.callout;
          calloutEl.style.display = 'block';
        }
      }, idx * 450);
      chain.timers.push(t);
    });
    chain.timers.push(setTimeout(clearChain, keys.length * 450 + 6000));
  }

  function normStep(raw) {
    if (raw === null || raw === undefined) return null;
    var v = raw;
    if (typeof v === 'object') v = v.id || v.target || v.button || v.name || '';
    var k = String(v).toLowerCase().replace(/[^a-z]/g, '');
    var map = { fireup: 'fireUp', firedown: 'fireDown', buyup: 'buyUp', buydown: 'buyDown',
                sell: 'sell', exit: 'sell', reversal: 'reversal', reverse: 'reversal', flip: 'reversal' };
    return map[k] || null;
  }

  function chainForEvent(detail) {
    var d = detail || {};
    var steps = [], i, n;
    if (Object.prototype.toString.call(d.steps) === '[object Array]') {
      for (i = 0; i < d.steps.length; i++) {
        n = normStep(d.steps[i]);
        if (n && steps.indexOf(n) < 0) steps.push(n);
      }
    }
    if (!steps.length) {
      var kind = String(d.kind || '').toLowerCase();
      var side = String(d.side || '').toLowerCase();
      if (/revers|flip/.test(kind)) steps = ['sell', 'reversal'];
      else if (/sell|exit/.test(kind)) steps = ['sell'];
      else if (side === 'up') steps = ['fireUp', 'buyUp'];
      else if (side === 'down') steps = ['fireDown', 'buyDown'];
    }
    return steps;
  }

  function onSequenceEvent(ev) {
    var steps = chainForEvent(ev ? ev.detail : null);
    if (steps.length) lightChain(steps);
    // v0.3.0: a coached sequence is a call moment — pin it on the
    // line too. The detail's side (and price, when it carries one)
    // are the Trigger's own fields; its % read is the stream's.
    var d = (ev && ev.detail) || {};
    var sd = String(d.side || '').toLowerCase();
    if (sd === 'up' || sd === 'down') {
      var a = anchorNow();
      var s = a.sample;
      var pct = s ? (sd === 'up' ? s.upPct : s.downPct) : null;
      addMarker({ t: a.t,
                  price: (typeof d.price === 'number') ? d.price : a.price,
                  side: sd,
                  pct: (typeof pct === 'number') ? pct : null,
                  engine: (d.engine === 'PLAIN' || d.engine === 'EARLY' || d.engine === 'FINAL') ? d.engine : null,
                  kind: 'call',
                  label: callLabel(sd === 'up' ? 'BUY UP' : 'BUY DOWN',
                                   (typeof pct === 'number') ? pct : null, a.t) });
    }
  }

  /* ---------------- proof-of-decision + Board flash watch (v0.2.0) ----------------
   * The poll watches the Board buttons' state attributes. A
   * transition INTO flash is a call being made: the Lens pins a
   * card to the stage saying WHY — the side %, the signed distance
   * to the beat, the clock — from the same stream sample, and keeps
   * the last five as the session's learning record. If the % is
   * unreadable the card says so; numbers are never invented. */

  var proofs = [];            // newest first, cap 5
  var prevBoardState = {};    // board id -> last state attribute seen
  var BOARD_IDS = ['buyUp', 'buyDown', 'sell', 'reversal'];

  function proofText(btnId, s) {
    var name = PRESS_NAMES[btnId] || String(btnId).toUpperCase();
    if (!s) {
      return 'WHY THIS CALL — ' + name + ' lit · no watcher stream — no desk numbers readable here · DEMO LAW';
    }
    var parts = [];
    if (btnId === 'buyUp' || btnId === 'buyDown') {
      var pct = btnId === 'buyUp' ? s.upPct : s.downPct;
      if (pct !== null && pct !== undefined) {
        parts.push((btnId === 'buyUp' ? 'Up ' : 'Down ') + Math.round(pct) + '%');
      } else {
        parts.push('% not readable on this page yet');
      }
    } else if (s.upPct !== null && s.downPct !== null) {
      parts.push('Up ' + Math.round(s.upPct) + '% · Down ' + Math.round(s.downPct) + '%');
    } else {
      parts.push('% not readable on this page yet');
    }
    if (typeof s.currentPrice === 'number' && typeof s.priceToBeat === 'number') {
      var d = s.currentPrice - s.priceToBeat;
      parts.push(fmtMoney(Math.abs(d)) + (d >= 0 ? ' above beat' : ' below beat'));
    }
    if (s.countdownSec !== null && s.countdownSec !== undefined) {
      parts.push(fmtClock(s.countdownSec) + ' left');
    }
    if (s.pctSource) parts.push('% via ' + s.pctSource);
    return 'WHY THIS CALL — ' + name + ' — ' + parts.join(' · ') + ' · DEMO LAW';
  }

  function recordProof(btnId) {
    proofs.unshift({ btn: btnId, text: proofText(btnId, watcherSample()), at: new Date().toISOString() });
    if (proofs.length > 5) proofs = proofs.slice(0, 5);
    renderProofs();
  }

  function renderProofs() {
    if (!proofEl) return;
    if (!proofs.length) {
      proofEl.style.display = 'none';
      proofEl.innerHTML = '';
      return;
    }
    proofEl.innerHTML = '';
    proofEl.appendChild(el('div', 'bl-proof-main', '🧾 ' + proofs[0].text));
    for (var i = 1; i < proofs.length; i++) {
      proofEl.appendChild(el('div', 'bl-proof-old', proofs[i].text));
    }
    proofEl.style.display = 'block';
  }

  function chainForFlash(btnId) {
    if (btnId === 'buyUp') return ['fireUp', 'buyUp'];
    if (btnId === 'buyDown') return ['fireDown', 'buyDown'];
    if (btnId === 'reversal') return ['sell', 'reversal'];
    return [btnId];
  }

  /* v0.3.0: a Board flash is also a call point on the line. The
   * SELL light is the exit story (the Scorekeeper annotations own
   * it), so only the buy and reversal lights pin call markers. The
   * Board carries no engine attribution, so these wear no initial. */
  function addFlashMarker(id) {
    if (id !== 'buyUp' && id !== 'buyDown' && id !== 'reversal') return;
    var a = anchorNow();
    var s = a.sample;
    var side = null, pct = null;
    if (id === 'buyUp') { side = 'up'; pct = s ? s.upPct : null; }
    else if (id === 'buyDown') { side = 'down'; pct = s ? s.downPct : null; }
    else if (s && s.upPct !== null && s.downPct !== null) {
      side = s.upPct >= s.downPct ? 'up' : 'down';
      pct = Math.max(s.upPct, s.downPct);
    }
    var verb = id === 'buyUp' ? 'BUY UP' : id === 'buyDown' ? 'BUY DOWN' : 'REVERSAL';
    addMarker({ t: a.t, price: a.price, side: side,
                pct: (typeof pct === 'number') ? pct : null, engine: null, kind: 'call',
                label: callLabel(verb, (typeof pct === 'number') ? pct : null, a.t) });
  }

  function boardWatch() {
    for (var i = 0; i < BOARD_IDS.length; i++) {
      var id = BOARD_IDS[i];
      var elm = findTarget(id);
      if (!elm) { prevBoardState[id] = null; continue; }
      var st = elm.getAttribute('data-bb-state');
      if (st === 'flash' && prevBoardState[id] !== 'flash') {
        recordProof(id);
        addFlashMarker(id);
        lightChain(chainForFlash(id));
      }
      prevBoardState[id] = st;
    }
  }

  /* ---------------- redraw + poll ---------------- */

  function redraw() {
    if (state.mode === 'tutorial') renderTutorial();
    else if (state.mode === 'sim') { drawSim(); }
    else if (state.mode === 'test') { drawTest(); }
    else if (state.mode === 'live') { liveRefresh(); }
    else { showIdle(); }
  }

  /* ---------------- go ---------------- */

  function start() {
    loadState();
    buildLens();
    if (!state.tutorialOff) {
      startTutorial(0);
    } else {
      showIdle();
    }
    // Sync discipline: one snappy poll for LIVE annotations — the
    // Lens reads the same shared stream as every other layer and
    // never lets its annotations lag it by a second or more. The
    // same tick keeps the blob-connect geometry fresh and watches
    // the Board's lights for proofs + sequence chains.
    setInterval(function () {
      boardWatch();
      scoreWatch();
      drawLinks();
      if (state.liveOn && state.mode === 'live') liveRefresh();
    }, LIVE_POLL_MS);
    // Receive-only: the Trigger announces practice sequences; the
    // Lens lights the chain. The Lens never sends this event.
    try { window.addEventListener('blobbtn:sequence', onSequenceEvent); } catch (e) {}
  }

  // Read-only snapshot for the test harness (and for David's own
  // inspection in the console): exposes state, changes nothing.
  try {
    window.BlobLensState = function () {
      return JSON.parse(JSON.stringify({
        locked: state.locked, layout: state.layout, opacity: state.opacity,
        tutorialOff: state.tutorialOff, mode: state.mode, liveOn: state.liveOn,
        tutorialStep: tut.step, tutorialHl: state.mode === 'tutorial' ? TUT[tut.step].hl : null,
        sim: { phase: sim.phase, idx: sim.idx, events: sim.events.map(function (e) { return e.kind; }), feed: sim.feed },
        test: { phase: test.phase, score: test.score, answered: test.answered, di: test.di },
        live: { label: live.label, info: live.info, watch: live.watch || '',
                seriesPoints: live.series.length, seriesSource: live.seriesSource,
                seriesLabel: live.seriesLabel, hasLine: live.hasLine, engines: live.engines,
                aura: live.aura, auraLevel: live.auraLevel },
        markers: markers.map(function (m) {
          return { kind: m.kind, side: m.side, pct: m.pct, engine: m.engine, label: m.label, t: m.t };
        }),
        position: { open: posState.open, side: posState.side, entryPct: posState.entryPct,
                    entryT: posState.entryT, hold: holdLabel() },
        effects: state.effects,
        fx: { bursts: fxState.bursts, lastBurst: fxState.lastBurst,
              active: fxLayer ? fxLayer.childElementCount : 0 },
        links: { lit: chain.steps.slice(), callout: chain.callout,
                 badges: chain.badges.map(function (b) { return b.g.getAttribute('data-bl-badge'); }) },
        proofs: proofs.map(function (p) { return { btn: p.btn, text: p.text }; }),
        scores: loadScores()
      }));
    };
  } catch (e) {}

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', start);
  } else {
    start();
  }
})();
