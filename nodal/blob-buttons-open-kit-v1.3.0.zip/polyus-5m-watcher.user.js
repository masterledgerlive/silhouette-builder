// ==UserScript==
// @name         Blob Buttons — Poly US 5M Watcher (READ-ONLY)
// @namespace    blob-buttons/koda-kai
// @version      0.2.1
// @description  READ-ONLY watcher for the Polymarket US BTC Up/Down 5-minute page: reads window, price to beat, Up/Down %, and countdown from the page every second and keeps a sample log on-device. v0.2.0: multi-strategy % extraction (explicit % / cent prices / aria / trade panel) with the winning strategy recorded per sample, a 120-point price series on the newest sample, and a local HH:MM:SS stamp on every sample. v0.2.1: the panel is free — drag it by its header, resize it by the corner grip; position + size persist on-device. It never clicks anything. Pack #2 of the Blob Button Field (blob-button-pack/0, id: polyus-5m-watcher).
// @author       Koda Kai Network (David's house build)
// @match        *://polymarket.us/event/btc-updown-5m-*
// @run-at       document-idle
// @grant        none
// ==/UserScript==

(function () {
  'use strict';

  /* ------------------------------------------------------------------
   * Blob Buttons Pack #2 — Poly US 5M Watcher
   *
   * HARD GUARANTEE: READ-ONLY. This script contains no click call, no
   * event dispatch, no form interaction, and no network call. It reads
   * text that the page is already showing, in David's own browser, in
   * David's own logged-in session — the session is never touched,
   * copied, or sent anywhere. The only buttons anywhere in this file
   * belong to the watcher's own little panel (Copy log / Clear), and
   * they act on the watcher's own log, never on the page.
   *
   * What it reads (all text/role-based, defensive — every reader takes
   * the *shortest* element whose text matches, which is the deepest,
   * most specific node carrying that value):
   *   - window title + time range ("BTC UP OR DOWN 5M", "7:25 – 7:30 PM ET")
   *   - price to beat (the value beside the "Price to beat" label)
   *   - current price (beside "Current price"; often "—" mid-window)
   *   - Up % / Down % (see the strategy ladder below)
   *   - countdown remaining (the MM:SS ring by the chart)
   *
   * THE % LADDER (v0.2.0). On the real page the v0.1.0 reader — which
   * only recognised a button whose whole text was "Up 62%" — read "—"
   * for 1,000+ samples while window/beat/countdown read fine. So each
   * side's percentage is now hunted four ways, in order, first hit
   * wins, and the winning strategy is recorded on the sample
   * (pctSource, plus upPctSource / downPctSource per side):
   *   S1 "pct"   — explicit "NN%" tied to the side: a whole element
   *                reading "Up 62%", or a bare "62%" leaf inside the
   *                Up control's own subtree.
   *   S2 "cents" — the trade buttons' cent prices treated as the
   *                implied percentage (62¢ = 62%): "Up 62¢", "Up 62c",
   *                "Up $0.62", whole-element or a leaf in the control.
   *   S3 "aria"  — an aria-label / title attribute that names the side
   *                and carries a number ("…62 percent", "…62%", "…62¢",
   *                "$0.62"; a bare number only on the control itself).
   *   S4 "panel" — a standalone "NN%" leaf inside the trade-panel
   *                region (the smallest box holding both controls),
   *                assigned to the side whose control precedes it.
   * If none hit, the percentage stays null and the source stays null —
   * honest "—", never a guessed number. A side is never derived from
   * the other side.
   *
   * Samples: the page is read every 1 s and on change. A sample is
   * written when any watched value differs from the last written
   * sample (the ticking countdown means samples land roughly every
   * tick inside a window), plus a 30 s heartbeat so a stalled page
   * still leaves a trace. Every sample carries the local wall-clock
   * time (localTime, "HH:MM:SS") beside the ISO timestamp.
   *
   * THE SERIES: the newest written sample carries `series` — the last
   * 120 observed current-price points, {t: epoch ms, price} — mirrored
   * there (and only there) so the Lens can draw the real line off the
   * same shared stream. The live surface is also exposed as
   * window.BlobWatcherState() -> {version, latest, series,
   * samplesLogged} for any layer that wants the freshest read.
   * Log lives in localStorage, capped at 2000 samples, exportable as
   * JSON from the panel. v0.1.0 sample fields are unchanged; v0.2.0
   * only adds fields.
   *
   * FREE PANEL (v0.2.1): the panel is no longer nailed to the
   * bottom-right corner. Drag it by its header strip, resize it by
   * the corner grip; position + size persist on-device under
   * 'blobbtn.watcher.panel.v1' and restore on the next load. With no
   * saved geometry it keeps the v0.2.0 bottom-right placement. The
   * panel's own buttons (Copy log JSON / Clear) are never drag
   * starts. Nothing about the reads, the log, or the series changed.
   * ------------------------------------------------------------------ */

  var STORAGE_KEY = 'blobbtn.poly5m.v1';
  var PANEL_ID = 'blobbtn-poly5m-panel';
  var PANEL_HEAD_ID = 'blobbtn-poly5m-head';
  var PANEL_GRIP_ID = 'blobbtn-poly5m-grip';
  var PANEL_GEO_KEY = 'blobbtn.watcher.panel.v1';
  var MAX_SAMPLES = 2000;
  var SAMPLE_MS = 1000;
  var HEARTBEAT_MS = 30000;
  var SERIES_MAX = 120;
  var REGION_MAX_TEXT = 1200;

  /* ---------------- small helpers ---------------- */

  function normText(el) {
    try {
      return String(el.textContent || '').replace(/\s+/g, ' ').trim();
    } catch (e) { return ''; }
  }

  function isOurs(el) {
    var n = el;
    while (n) {
      if (n.id === PANEL_ID) return true;
      n = n.parentElement || n.parentNode || null;
    }
    return false;
  }

  function allEls() {
    var out = [];
    try {
      var nodes = document.querySelectorAll('*');
      for (var i = 0; i < nodes.length; i++) {
        if (!isOurs(nodes[i])) out.push(nodes[i]);
      }
    } catch (e) {}
    return out;
  }

  // Shortest element whose whole text matches `re` (deepest carrier).
  function shortestFullMatch(els, re) {
    var best = null, bestLen = Infinity;
    for (var i = 0; i < els.length; i++) {
      var t = normText(els[i]);
      if (t && t.length < bestLen && re.test(t)) { best = els[i]; bestLen = t.length; }
    }
    return best;
  }

  // Shortest element whose text *contains* a match of `re`; returns the match.
  function shortestContaining(els, re) {
    var best = null, bestLen = Infinity;
    for (var i = 0; i < els.length; i++) {
      var t = normText(els[i]);
      var m = t.match(re);
      if (m && t.length < bestLen) { best = m[0]; bestLen = t.length; }
    }
    return best;
  }

  function leavesWithin(root) {
    var out = [];
    (function walk(el) {
      if (!el || isOurs(el)) return;
      var kids = el.children || [];
      if (kids.length === 0) { out.push(el); return; }
      for (var i = 0; i < kids.length; i++) walk(kids[i]);
    })(root);
    return out;
  }

  function parseMoney(t) {
    var m = String(t || '').match(/\$([\d,]+\.\d{2})/);
    return m ? parseFloat(m[1].replace(/,/g, '')) : null;
  }

  function pad2(n) { return (n < 10 ? '0' : '') + n; }

  function localTimeString(d) {
    return pad2(d.getHours()) + ':' + pad2(d.getMinutes()) + ':' + pad2(d.getSeconds());
  }

  function validPct(v) {
    return typeof v === 'number' && isFinite(v) && v >= 0 && v <= 100;
  }

  function insideEl(el, root) {
    var n = el;
    while (n) {
      if (n === root) return true;
      n = n.parentElement || n.parentNode || null;
    }
    return false;
  }

  function commonAncestor(a, b) {
    var seen = [], n = a;
    while (n) { seen.push(n); n = n.parentElement || n.parentNode || null; }
    n = b;
    while (n) {
      if (seen.indexOf(n) !== -1) return n;
      n = n.parentElement || n.parentNode || null;
    }
    return null;
  }

  /* ---------------- the readers ---------------- */

  function readTitle(els) {
    var el = shortestFullMatch(els, /^BTC Up or Down 5m$/i);
    if (el) return normText(el);
    try { return String(document.title || '').split('|')[0].trim() || null; }
    catch (e) { return null; }
  }

  function readWindowLabel(els) {
    return shortestContaining(els,
      /\d{1,2}:\d{2}\s*[–—-]\s*\d{1,2}:\d{2}\s*(?:AM|PM)\s*ET/i);
  }

  // Value beside a small label leaf ("Price to beat" -> "$64,979.98").
  // Only the label's own box is searched: climbing further would steal
  // the neighbouring stat's value (the "Current price" box sits right
  // beside "Price to beat", and its honest mid-window value is "—").
  function readLabelledMoney(els, label) {
    for (var i = 0; i < els.length; i++) {
      if ((els[i].children || []).length === 0 && normText(els[i]) === label) {
        var box = els[i].parentElement || els[i].parentNode;
        if (!box) return null;
        var leaves = leavesWithin(box);
        for (var j = 0; j < leaves.length; j++) {
          if (leaves[j] === els[i]) continue;
          var v = parseMoney(normText(leaves[j]));
          if (v !== null) return v;
        }
        return null; // label found, value not (yet) a number
      }
    }
    return null;
  }

  function readPriceToBeat(els) {
    var v = readLabelledMoney(els, 'Price to beat');
    if (v !== null) return v;
    // Fallback: the chart's target tag, "$64,979.98 target".
    var tag = shortestContaining(els, /\$[\d,]+\.\d{2}\s*target/i);
    return tag ? parseMoney(tag) : null;
  }

  function readCountdown(els) {
    var el = shortestFullMatch(els, /^\d{1,2}:\d{2}$/);
    if (!el) return { text: null, seconds: null };
    var t = normText(el);
    var parts = t.split(':');
    var sec = parseInt(parts[0], 10) * 60 + parseInt(parts[1], 10);
    return { text: t, seconds: isNaN(sec) ? null : sec };
  }

  /* ---------------- the % ladder (v0.2.0) ----------------
   * Per side, strategies run S1 -> S4; first hit wins. A "control" is
   * the shortest button-ish element whose text starts with the side
   * word. The trade-panel region is the smallest box holding both
   * controls, refused if its text is implausibly large for a panel. */

  var PCT_LEAF_RE = /^(\d+(?:\.\d+)?)%$/;
  var CENTS_LEAF_RE = /^(?:\$0\.(\d{2})|(\d+(?:\.\d+)?)\s*[¢c])$/i;

  function pctFullRe(word) {
    return new RegExp('^' + word + '[\\s:\\u2013\\u2014-]*([0-9]+(?:\\.[0-9]+)?)%$');
  }
  function centsFullRe(word) {
    return new RegExp('^' + word + '\\s+(?:\\$0\\.([0-9]{2})|([0-9]+(?:\\.[0-9]+)?)\\s*[¢c])$', 'i');
  }
  // A cents match carries either the $0.NN digits (group 1) or a plain
  // cent amount (group 2); both are the implied percentage.
  function centsValue(m) {
    if (!m) return null;
    if (m[1] !== undefined && m[1] !== null) return parseInt(m[1], 10);
    if (m[2] !== undefined && m[2] !== null) return parseFloat(m[2]);
    return null;
  }

  function findSideControl(els, word) {
    var re = new RegExp('^' + word + '\\b');
    var bestBtn = null, bestBtnLen = Infinity, best = null, bestLen = Infinity;
    for (var i = 0; i < els.length; i++) {
      var el = els[i], t = normText(el);
      if (!t || t.length > 48 || !re.test(t)) continue;
      var role = '';
      try { role = String((el.getAttribute && el.getAttribute('role')) || ''); } catch (e) {}
      var btnish = el.tagName === 'BUTTON' || el.tagName === 'A' || role === 'button';
      if (btnish && t.length < bestBtnLen) { bestBtn = el; bestBtnLen = t.length; }
      if (t.length < bestLen) { best = el; bestLen = t.length; }
    }
    return bestBtn || best;
  }

  function buildCtx(els) {
    var up = findSideControl(els, 'Up');
    var dn = findSideControl(els, 'Down');
    var region = null;
    if (up && dn) {
      var anc = commonAncestor(up, dn);
      if (anc && normText(anc).length <= REGION_MAX_TEXT) region = anc;
    }
    return { els: els, controls: { Up: up, Down: dn }, panelRegion: region };
  }

  // S1 "pct": explicit NN% tied to the side.
  function stratPct(ctx, word) {
    var re = pctFullRe(word);
    var el = shortestFullMatch(ctx.els, re);
    if (el) {
      var m = normText(el).match(re);
      if (m) { var v = parseFloat(m[1]); if (validPct(v)) return v; }
    }
    var ctl = ctx.controls[word];
    if (ctl) {
      var leaves = leavesWithin(ctl);
      for (var i = 0; i < leaves.length; i++) {
        if (leaves[i] === ctl) continue;
        var mm = normText(leaves[i]).match(PCT_LEAF_RE);
        if (mm) { var vv = parseFloat(mm[1]); if (validPct(vv)) return vv; }
      }
    }
    return null;
  }

  // S2 "cents": the side's cent price is its implied percentage.
  function stratCents(ctx, word) {
    var re = centsFullRe(word);
    var el = shortestFullMatch(ctx.els, re);
    if (el) {
      var v = centsValue(normText(el).match(re));
      if (validPct(v)) return v;
    }
    var ctl = ctx.controls[word];
    if (ctl) {
      var leaves = leavesWithin(ctl);
      for (var i = 0; i < leaves.length; i++) {
        if (leaves[i] === ctl) continue;
        var vv = centsValue(normText(leaves[i]).match(CENTS_LEAF_RE));
        if (validPct(vv)) return vv;
      }
    }
    return null;
  }

  // A number carried by an attribute string: %, "percent", $0.NN, or
  // cents first; a bare number only when allowBare (the control's own
  // attribute — elsewhere a stray number is too easy to misread).
  function pctFromAttrText(text, allowBare) {
    var s = String(text || '');
    var m = s.match(/(\d+(?:\.\d+)?)\s*(?:%|percent\b)/i);
    if (m) { var v = parseFloat(m[1]); if (validPct(v)) return v; }
    m = s.match(/\$0\.(\d{2})/);
    if (m) return parseInt(m[1], 10);
    m = s.match(/(\d+(?:\.\d+)?)\s*(?:¢|\bcents?\b)/i);
    if (m) { var v2 = parseFloat(m[1]); if (validPct(v2)) return v2; }
    if (allowBare) {
      m = s.match(/\b(\d{1,2}(?:\.\d+)?)\b/);
      if (m) { var v3 = parseFloat(m[1]); if (v3 > 0 && v3 < 100) return v3; }
    }
    return null;
  }

  // S3 "aria": aria-label / title attributes naming the side.
  function stratAria(ctx, word) {
    var wordRe = new RegExp('\\b' + word + '\\b', 'i');
    var ctl = ctx.controls[word];
    var cands = [];
    for (var i = 0; i < ctx.els.length; i++) {
      var el = ctx.els[i], attr = null;
      try {
        attr = (el.getAttribute && (el.getAttribute('aria-label') || el.getAttribute('title'))) || null;
      } catch (e) {}
      if (attr && wordRe.test(String(attr))) {
        cands.push({ attr: String(attr), own: el === ctl });
      }
    }
    cands.sort(function (a, b) { return a.attr.length - b.attr.length; });
    for (var j = 0; j < cands.length; j++) {
      var v = pctFromAttrText(cands[j].attr, cands[j].own);
      if (v !== null) return v;
    }
    return null;
  }

  // Which side a panel leaf belongs to: the control that most recently
  // precedes it in document order; a leaf before both controls belongs
  // to the first control.
  function leafBelongsToWord(posLeaf, posWord, posOther) {
    if (posWord < posLeaf && posOther < posLeaf) return posWord > posOther;
    if (posWord < posLeaf) return true;
    if (posOther < posLeaf) return false;
    return posWord < posOther;
  }

  // S4 "panel": standalone NN% leaves inside the trade-panel region.
  function stratPanel(ctx, word, otherWord) {
    var region = ctx.panelRegion;
    var ctl = ctx.controls[word], other = ctx.controls[otherWord];
    if (!region || !ctl || !other) return null;
    var posCtl = ctx.els.indexOf(ctl), posOther = ctx.els.indexOf(other);
    if (posCtl < 0 || posOther < 0) return null;
    var leaves = leavesWithin(region);
    for (var i = 0; i < leaves.length; i++) {
      var leaf = leaves[i];
      if (insideEl(leaf, ctl) || insideEl(leaf, other)) continue;
      var m = normText(leaf).match(PCT_LEAF_RE);
      if (!m) continue;
      var posLeaf = ctx.els.indexOf(leaf);
      if (posLeaf < 0) continue;
      if (!leafBelongsToWord(posLeaf, posCtl, posOther)) continue;
      var v = parseFloat(m[1]);
      if (validPct(v)) return v;
    }
    return null;
  }

  function readSidePct(ctx, word, otherWord) {
    var v = stratPct(ctx, word);
    if (v !== null) return { value: v, source: 'pct' };
    v = stratCents(ctx, word);
    if (v !== null) return { value: v, source: 'cents' };
    v = stratAria(ctx, word);
    if (v !== null) return { value: v, source: 'aria' };
    v = stratPanel(ctx, word, otherWord);
    if (v !== null) return { value: v, source: 'panel' };
    return { value: null, source: null };
  }

  function readPage() {
    var els = allEls();
    var ctx = buildCtx(els);
    var cd = readCountdown(els);
    var up = readSidePct(ctx, 'Up', 'Down');
    var dn = readSidePct(ctx, 'Down', 'Up');
    var slug = null;
    try { slug = String(window.location.pathname || ''); } catch (e) {}
    var now = new Date();
    return {
      ts: now.toISOString(),
      localTime: localTimeString(now),
      slug: slug,
      title: readTitle(els),
      window: readWindowLabel(els),
      priceToBeat: readPriceToBeat(els),
      currentPrice: readLabelledMoney(els, 'Current price'),
      upPct: up.value,
      downPct: dn.value,
      upPctSource: up.source,
      downPctSource: dn.source,
      pctSource: up.source || dn.source,
      countdown: cd.text,
      countdownSec: cd.seconds
    };
  }

  /* ---------------- the log + the series ---------------- */

  function loadLog() {
    try {
      var raw = window.localStorage.getItem(STORAGE_KEY);
      if (raw) {
        var arr = JSON.parse(raw);
        if (Object.prototype.toString.call(arr) === '[object Array]') return arr;
      }
    } catch (e) {}
    return [];
  }

  function saveLog() {
    try {
      window.localStorage.setItem(STORAGE_KEY, JSON.stringify(samples));
    } catch (e) { /* panel still shows live readings */ }
  }

  var samples = loadLog();
  var lastKey = null;
  var lastSampleAt = 0;
  var lastRead = null;

  // The price series ring: last SERIES_MAX observed current-price
  // points. Seeded from the stored log's newest sample so a page
  // reload keeps the line it had already drawn.
  var seriesRing = [];
  (function seedSeries() {
    try {
      var last = samples[samples.length - 1];
      if (last && Object.prototype.toString.call(last.series) === '[object Array]') {
        for (var i = 0; i < last.series.length; i++) {
          var pt = last.series[i];
          if (pt && typeof pt.t === 'number' && typeof pt.price === 'number') {
            seriesRing.push({ t: pt.t, price: pt.price });
          }
        }
        while (seriesRing.length > SERIES_MAX) seriesRing.shift();
      }
    } catch (e) {}
  })();

  function pushSeriesPoint(price, nowMs) {
    if (typeof price !== 'number' || !isFinite(price)) return;
    seriesRing.push({ t: nowMs, price: price });
    while (seriesRing.length > SERIES_MAX) seriesRing.shift();
  }

  function sampleKey(s) {
    return JSON.stringify([s.window, s.priceToBeat, s.currentPrice,
                           s.upPct, s.downPct, s.countdownSec]);
  }

  function takeSample(force) {
    var s = readPage();
    lastRead = s;
    var now = Date.now();
    pushSeriesPoint(s.currentPrice, now);
    var key = sampleKey(s);
    if (!force && key === lastKey && (now - lastSampleAt) < HEARTBEAT_MS) {
      renderPanel(s);
      return;
    }
    // The series tail lives on the newest sample only: strip it from
    // the previous tail before the new tail lands.
    if (samples.length) {
      try { delete samples[samples.length - 1].series; } catch (e) {}
    }
    s.series = seriesRing.slice();
    samples.push(s);
    while (samples.length > MAX_SAMPLES) samples.shift();
    lastKey = key;
    lastSampleAt = now;
    saveLog();
    renderPanel(s);
  }

  // The shared live surface: the freshest read + the series, for any
  // layer (the Lens draws the real line from this or from the newest
  // log sample's `series` — same points, same order).
  try {
    window.BlobWatcherState = function () {
      return {
        version: '0.2.1',
        latest: lastRead,
        series: seriesRing.slice(),
        samplesLogged: samples.length
      };
    };
  } catch (e) {}

  /* ---------------- the panel (the watcher's own UI) ---------------- */

  var panel = null, valLine = null, metaLine = null, statusLine = null, exportBox = null;

  /* ---------------- the free panel geometry (v0.2.1) ----------------
   * Position + size persist on-device under PANEL_GEO_KEY as
   * {l, t, w, h} (h stays null until the panel is first resized, so
   * an unresized panel keeps its natural height). No saved geometry
   * -> the v0.2.0 placement: bottom-right, 230px wide. Dragging
   * starts only on the header strip and resizing only on the corner
   * grip, so the panel's buttons stay plain buttons. Same pointer
   * idiom as the Trigger deck's header drag. */

  var PANEL_MIN_W = 180, PANEL_MIN_H = 96;

  function loadPanelGeo() {
    try {
      var raw = window.localStorage.getItem(PANEL_GEO_KEY);
      if (!raw) return null;
      var g = JSON.parse(raw);
      if (!g || typeof g.l !== 'number' || typeof g.t !== 'number' ||
          typeof g.w !== 'number' || !isFinite(g.l) || !isFinite(g.t) ||
          !isFinite(g.w) || g.w < PANEL_MIN_W || g.w > 4000) return null;
      var h = (g.h === undefined ? null : g.h);
      if (h !== null && (typeof h !== 'number' || !isFinite(h) ||
                         h < PANEL_MIN_H || h > 4000)) h = null;
      return { l: g.l, t: g.t, w: g.w, h: h };
    } catch (e) { return null; }
  }

  function savePanelGeo() {
    if (!panel) return;
    try {
      var rect = panel.getBoundingClientRect();
      var g = {
        l: Math.round(rect.left),
        t: Math.round(rect.top),
        w: Math.round(rect.width),
        h: panel.style.height ? Math.round(rect.height) : null
      };
      window.localStorage.setItem(PANEL_GEO_KEY, JSON.stringify(g));
    } catch (e) {}
  }

  function clampPanelPos(x, y) {
    var vw = window.innerWidth || 1280, vh = window.innerHeight || 720;
    return {
      x: Math.max(0, Math.min(vw - 70, x)),
      y: Math.max(0, Math.min(vh - 30, y))
    };
  }

  function applyPanelGeo() {
    if (!panel) return;
    var g = loadPanelGeo();
    if (!g) return;
    var p = clampPanelPos(g.l, g.t);
    panel.style.right = 'auto';
    panel.style.bottom = 'auto';
    panel.style.left = p.x + 'px';
    panel.style.top = p.y + 'px';
    panel.style.width = g.w + 'px';
    if (g.h !== null) {
      panel.style.height = g.h + 'px';
      panel.style.overflow = 'auto';
    }
  }

  // Switch the panel from its default right/bottom anchoring to
  // explicit left/top (same spot) before a drag or resize moves it.
  function anchorPanelAtRect() {
    var rect = panel.getBoundingClientRect();
    panel.style.right = 'auto';
    panel.style.bottom = 'auto';
    panel.style.left = rect.left + 'px';
    panel.style.top = rect.top + 'px';
    return rect;
  }

  function wirePanelDrag(head) {
    var drag = null;
    head.addEventListener('pointerdown', function (ev) {
      if (ev.target && ev.target.closest &&
          ev.target.closest('button, input, select, textarea, a')) return;
      var rect = anchorPanelAtRect();
      drag = { startX: ev.clientX, startY: ev.clientY,
               origX: rect.left, origY: rect.top, moved: false };
      try { head.setPointerCapture(ev.pointerId); } catch (e) {}
    });
    head.addEventListener('pointermove', function (ev) {
      if (!drag) return;
      var dx = ev.clientX - drag.startX, dy = ev.clientY - drag.startY;
      if (Math.abs(dx) + Math.abs(dy) > 3) drag.moved = true;
      var p = clampPanelPos(drag.origX + dx, drag.origY + dy);
      panel.style.left = p.x + 'px';
      panel.style.top = p.y + 'px';
    });
    function endDrag() {
      if (!drag) return;
      if (drag.moved) savePanelGeo();
      drag = null;
    }
    head.addEventListener('pointerup', endDrag);
    head.addEventListener('pointercancel', endDrag);
  }

  function wirePanelResize(grip) {
    var rz = null;
    grip.addEventListener('pointerdown', function (ev) {
      var rect = anchorPanelAtRect();
      rz = { startX: ev.clientX, startY: ev.clientY,
             origW: rect.width, origH: rect.height,
             left: rect.left, top: rect.top, moved: false };
      panel.style.width = rect.width + 'px';
      panel.style.height = rect.height + 'px';
      panel.style.overflow = 'auto';
      try { grip.setPointerCapture(ev.pointerId); } catch (e) {}
      if (ev.stopPropagation) ev.stopPropagation();
    });
    grip.addEventListener('pointermove', function (ev) {
      if (!rz) return;
      var vw = window.innerWidth || 1280, vh = window.innerHeight || 720;
      var dx = ev.clientX - rz.startX, dy = ev.clientY - rz.startY;
      if (Math.abs(dx) + Math.abs(dy) > 3) rz.moved = true;
      var w = Math.max(PANEL_MIN_W, Math.min(vw - rz.left, rz.origW + dx));
      var h = Math.max(PANEL_MIN_H, Math.min(vh - rz.top, rz.origH + dy));
      panel.style.width = w + 'px';
      panel.style.height = h + 'px';
    });
    function endResize() {
      if (!rz) return;
      if (rz.moved) savePanelGeo();
      rz = null;
    }
    grip.addEventListener('pointerup', endResize);
    grip.addEventListener('pointercancel', endResize);
  }

  function buildPanel() {
    try {
      panel = document.createElement('div');
      panel.id = PANEL_ID;
      panel.style.cssText =
        'position:fixed;right:8px;bottom:8px;z-index:2147483647;width:230px;' +
        'box-sizing:border-box;' +
        'background:rgba(11,14,20,0.88);color:#e8ecf1;border:1px solid #22303f;' +
        'border-radius:10px;padding:8px 10px;' +
        'font:12px/1.5 -apple-system,Arial,sans-serif;';
      var head = document.createElement('div');
      head.id = PANEL_HEAD_ID;
      head.textContent = '👁 Poly 5M Watcher — read-only';
      head.title = 'Drag to move';
      head.style.cssText = 'font-weight:bold;color:#7ee787;cursor:move;' +
        'touch-action:none;user-select:none;-webkit-user-select:none;';
      valLine = document.createElement('div');
      metaLine = document.createElement('div');
      metaLine.style.cssText = 'color:#9fb4c8;';
      statusLine = document.createElement('div');
      statusLine.style.cssText = 'color:#9fb4c8;padding-right:16px;';
      var row = document.createElement('div');
      row.style.cssText = 'margin-top:5px;';
      var copyBtn = document.createElement('button');
      copyBtn.textContent = 'Copy log JSON';
      copyBtn.style.cssText = 'margin-right:6px;padding:3px 8px;border-radius:6px;border:1px solid #22303f;background:#10151d;color:#e8ecf1;';
      copyBtn.addEventListener('click', exportLog);
      var clearBtn = document.createElement('button');
      clearBtn.textContent = 'Clear';
      clearBtn.style.cssText = 'padding:3px 8px;border-radius:6px;border:1px solid #22303f;background:#10151d;color:#e8ecf1;';
      clearBtn.addEventListener('click', function () {
        samples = [];
        lastKey = null;
        seriesRing = [];
        saveLog();
        setStatus('log cleared');
        renderPanel(readPage());
      });
      row.appendChild(copyBtn);
      row.appendChild(clearBtn);
      exportBox = document.createElement('textarea');
      exportBox.style.cssText = 'display:none;width:100%;height:90px;margin-top:6px;background:#0b0e14;color:#7ee787;border:1px solid #22303f;border-radius:6px;';
      exportBox.setAttribute('readonly', 'readonly');
      var grip = document.createElement('div');
      grip.id = PANEL_GRIP_ID;
      grip.title = 'Drag to resize';
      grip.style.cssText = 'position:absolute;right:2px;bottom:2px;width:14px;height:14px;' +
        'cursor:nwse-resize;touch-action:none;border-radius:0 0 8px 0;' +
        'background:repeating-linear-gradient(135deg,transparent 0 3px,#41546a 3px 4px,transparent 4px 7px);';
      panel.appendChild(head);
      panel.appendChild(valLine);
      panel.appendChild(metaLine);
      panel.appendChild(row);
      panel.appendChild(exportBox);
      panel.appendChild(statusLine);
      panel.appendChild(grip);
      (document.body || document.documentElement).appendChild(panel);
      applyPanelGeo();
      wirePanelDrag(head);
      wirePanelResize(grip);
    } catch (e) { panel = null; }
  }

  function setStatus(msg) {
    if (statusLine) statusLine.textContent = msg;
  }

  function fmtMoney(v) {
    return (v === null || v === undefined) ? '—' : '$' + Number(v).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  }
  var SRC_TAG = { pct: 'pct', cents: '¢', aria: 'aria', panel: 'panel' };
  function fmtPct(v, source) {
    if (v === null || v === undefined) return '—';
    return v + '%' + (source ? ' (' + (SRC_TAG[source] || source) + ')' : '');
  }

  function renderPanel(s) {
    if (!panel || !valLine) return;
    try {
      valLine.textContent =
        'Beat ' + fmtMoney(s.priceToBeat) + ' · Now ' + fmtMoney(s.currentPrice) + '\n' +
        'Up ' + fmtPct(s.upPct, s.upPctSource) + ' · Down ' + fmtPct(s.downPct, s.downPctSource) + ' · ⏳ ' + (s.countdown || '—');
      valLine.style.whiteSpace = 'pre-line';
      metaLine.textContent =
        (s.window || 'window —') + ' · ' + samples.length + ' samples logged' +
        (s.localTime ? ' · ' + s.localTime : '');
    } catch (e) {}
  }

  function exportLog() {
    var json = JSON.stringify(samples, null, 1);
    function fallback() {
      try {
        exportBox.value = json;
        exportBox.style.display = 'block';
        exportBox.select();
        setStatus('log shown below — copy it manually');
      } catch (e) {}
    }
    try {
      if (window.navigator && window.navigator.clipboard && window.navigator.clipboard.writeText) {
        window.navigator.clipboard.writeText(json).then(function () {
          setStatus('log copied ✓ (' + samples.length + ' samples)');
        }, fallback);
      } else {
        fallback();
      }
    } catch (e) { fallback(); }
  }

  /* ---------------- the watch ---------------- */

  var scheduled = false;
  function scheduleSample() {
    if (scheduled) return;
    scheduled = true;
    setTimeout(function () { scheduled = false; takeSample(false); }, 150);
  }

  function start() {
    buildPanel();
    takeSample(true);
    try {
      var obs = new MutationObserver(scheduleSample);
      obs.observe(document.documentElement, { childList: true, subtree: true, characterData: true });
    } catch (e) {}
    setInterval(function () { takeSample(false); }, SAMPLE_MS);
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', start);
  } else {
    start();
  }
})();
