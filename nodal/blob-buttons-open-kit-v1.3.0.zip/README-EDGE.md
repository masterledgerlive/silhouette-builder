# Blob Buttons — The Full Kit (Microsoft Edge package)

**What this is.** The complete Blob Buttons system for the Polymarket US
"BTC Up or Down 5m" page, as ONE Edge (Chromium, Manifest V3) extension with
zero permissions. Four packs, one stream, everything synced:

- **Pack #2 — the Watcher (eyes).** Read-only. Reads window, price to beat,
  Up/Down %, countdown from the page; samples ~2 s into an on-device log
  (localStorage `blobbtn.poly5m.v1`). Every other layer drinks from this
  one stream.
- **Pack #3 — the Board (lights) v0.1.2.** BUY UP / BUY DOWN / SELL /
  REVERSAL buttons pre-placed over the real trade controls (drag + resize
  in EDIT mode; your saved layout wins). LOCKED = pointer-events:none —
  your tap passes through the light to the real control. A passive journal
  (it only listens) records each tap-through: CORRECT / WRONG-CONTROL and
  your reaction time — header shows "⚡ last 0.84s ✓ · best 0.61s · hits 3/3".
  Polls the stream every 250 ms; header shows the stream age. Flash rules
  are the labeled DEMO rules until the desk's real gate law is wired in.
- **Pack #4 — the Trigger (David's finger).** Cents box (default 10,
  HARD CAP 75 enforced in code) + FIRE UP / FIRE DOWN. Double-press only:
  first press arms and spells out the exact fire; second press runs it.
  Ships in DRY mode — fills the ticket and stops before Place. Going LIVE
  takes a double-press on its own toggle, and every page load boots DRY.
  Aborts itself, with the reason on the panel, if anything on the page
  doesn't match expectations.
- **Pack #5 — the Lens (teacher).** A translucent overlay for the chart:
  opacity slider (any level), a six-card tutorial (beat line → momentum →
  flip → the call bar → exits → the reversal confirm) with a
  "don't show again", a fast simulation, and a scored test simulation
  (high scores saved on-device). LIVE mode annotates the chart from the
  watcher stream (beat, clock, %, stream age, last reaction). Slice 2 —
  bridging the desk's sealed calls into LIVE — is not in this build.

**Install (any Edge — David's other computer included).**

1. Unzip this package into a folder and keep the folder (Edge loads from it).
2. In Edge open `edge://extensions`.
3. Turn on **Developer mode**.
4. **Load unpacked** → select the folder.
5. Open a Polymarket US BTC Up or Down 5m page — watcher panel bottom-right,
   Board on the trade controls, Trigger panel left, Lens over the chart.
   Arrange, resize, lock.

**Uninstall.** `edge://extensions` → Remove.

**Safety.** The Watcher, Board, and Lens never press anything (grep-proven).
The Trigger presses only on David's double-press, inside his caps, DRY by
default. Nothing here trades on its own. Built + harness-proven 2026-11-16:
Board 43/43 · Trigger 48/48 · Lens 52/52.

**v1.1.0 (2026-11-16, David's live-round changes).** Watcher samples every
1 s and hunts the Up/Down % four ways (%, cent-price-implied, labels, panel),
tagging its source; it keeps a 120-point price series for the Lens. The
Board boots LOCKED when your layout is saved ("TAP-THROUGH ARMED" pill),
each button has glass transparency (EDIT → GLASS cycles 100/70/50/35/20),
and the Scorekeeper runs: ARM ("GET READY") then FIRE; your tap-through
scores POINT / SLOW / NO-PRESS / MISSED EXIT, flags ⚑ GREED and
⚑ GAMBLING, labels TAKE PROFIT, and counts WINs at the settle. The Trigger
is now the Practice Deck: free-move, minimize, buy/sell marks that coach
your press sequence against live prices (the proven fire path remains
behind EXECUTE). The Lens LIVE stage draws the real series (auto-scaled),
shows PLAIN/EARLY/FINAL with their why, draws the blob-connect links
(FIRE → BUY → SELL) with numbered press badges, fires block-burst effects
on strong moves, and pins a proof-of-decision card for every call.
Harness totals this round: Watcher 55 · Board 78 · Trigger 70 · Lens 78.

---

# Open Kit v1.3.0 — the final final (2026-11-16)

FREE. The whole set is free — for anyone who pulls it.

What changed since v1.1.0:
- EVERYTHING is movable + resizable (Watcher panel, Board toolbar + buttons,
  Trigger panel, Lens) and every panel remembers where you put it.
- The Board has FIVE buttons now: BUY UP · BUY DOWN · BUY (the page's submit —
  it fires blue "PRESS BUY TO CONFIRM" when a side is hot) · SELL · REVERSAL.
- The Lens pins CALL POINTS on the live line — time + accuracy % on every
  call — plus ENTRY / HOLDING / MISSED EXIT markers for your position.
- NEW: the Venue Plug (venue-plug.user.js + README-FOR-ANYONE.md). Plug in
  YOUR OWN Polymarket US or Kalshi API keys — they live only in your browser,
  the plug READS ONLY (it cannot place orders), and it cross-checks the
  page's BTC numbers against the venue's own: the BTC TRUTH line.
  The BTC data does not lie.
- Purpose (David, 2026-11-16): more of our ideas flowing into other systems,
  to learn — joining and aiding together, in numbers.
