# Venue Plug — plug in your own venue account (read-only)

An optional add-on for the **Blob Buttons Full Kit**. The kit's Watcher reads the
Polymarket US 5-minute BTC page. This plug lets *you* — whoever is sitting at the
keyboard — plug in **your own** Polymarket US or Kalshi account so the kit can:

1. **Prove the plug works** by reading your balance back to you, and
2. **Cross-check the BTC numbers** on the page against the venue's own BTC
   reference every ~15 seconds — the **BTC TRUTH line** — because the BTC data
   does not lie, and if two honest reads of it ever disagree, you want to know.

It is one file: `venue-plug.user.js`. No build step, no account with us, nothing
to sign up for.

## The read-only law (read this first)

- **This plug READS ONLY. It cannot place orders.** There is no order code in
  the file at all — every network call it makes is a read, and you can grep it
  and check. The test file (`test_venue_plug.js`) greps it too, on every run.
- **Your keys live only in your browser**, in its local storage, on your
  machine. They are sent only to *your own venue*, as signing headers on reads.
- **DISCONNECT wipes the keys** from the browser. One click, gone.
- Keys are never shown back, never logged, and the plug's status surface
  (`window.BlobVenuePlugState()`) contains no key material — the tests check.

## Install (about 2 minutes)

You need a current **Edge or Chrome** (the plug signs reads with the browser's
built-in WebCrypto, including Ed25519 — very old browsers can't).

1. Get the Full Kit folder (the Blob Buttons extension folder) onto your
   machine — it pulls as one folder, the same way it always has.
2. Drop `venue-plug.user.js` into that same folder, next to
   `polyus-5m-watcher.user.js`. That's the whole "integration": the plug finds
   the Watcher by itself.
3. Open `edge://extensions` (or `chrome://extensions`), turn on
   **Developer mode**, and if the kit is already loaded, click **Reload** on
   its card. (First time: **Load unpacked** → pick the kit folder.)
4. Open any Polymarket US **BTC Up or Down 5m** event page. A **🔌 VENUE**
   chip appears at the bottom-left. Click it, pick your venue, paste your
   keys, press **CONNECT**. If it reads your balance back, you're plugged in —
   and it stays plugged in on the next visit until you disconnect.

## Getting your keys

### Polymarket US

1. Go to **polymarket.us**, sign in, and open the **Developer** page
   (polymarket.us/developer).
2. Create an API key. The site shows you a **Key ID** and a **Secret Key**.
   **The secret is shown once** — copy it somewhere safe right then; if you
   lose it, delete the key and make a new one.
3. In the plug: pick **Polymarket US**, paste the Key ID and the Secret,
   CONNECT. You should see `CONNECTED ✓ — balance $…`.

### Kalshi

1. Go to **kalshi.com**, sign in, and open **Settings → API Keys**
   (Account & security → API).
2. Create a key. Kalshi has you generate a **private key file** (a `.key`
   file) and gives you a **Key ID**. Keep the `.key` file — Kalshi does not
   keep a copy; lose it and you create a new key.
   Kalshi issues two kinds of keys over the years — RSA and Ed25519. **This
   plug reads the kind straight out of your key file and handles both.**
3. In the plug: pick **Kalshi**, paste the Key ID, and paste the *contents*
   of the `.key` file (the whole `-----BEGIN … PRIVATE KEY-----` block) into
   the private-key box. CONNECT. Kalshi counts money in cents; the plug shows
   you dollars.

## The BTC TRUTH line — and two venue truths nobody should dress up

While you're connected, the panel cross-checks BTC about every 15 seconds:

- **Kalshi plugged in:** the venue value is the live **KXBTC15M** market's
  strike, from Kalshi's public feed. It's compared to the page's
  price-to-beat. Both are window-open BTC strikes, so they should match;
  a gap over $25 prints **⚠ DIVERGES** with the size of the gap.
- **Polymarket US plugged in:** there is no second BTC feed to ask — see the
  truth below — so the plug reads the page's beat *directly off the page*
  with its own small reader and compares it to the Watcher's beat. Two
  independent reads of the same number should agree exactly.
- If a value can't be fetched, the line **says so** ("venue check
  unavailable"). It never prints a match it didn't measure.

The two venue truths, printed in the panel too:

- **Kalshi has NO 5-minute BTC game.** Its fastest is the 15-minute
  KXBTC15M. This plug watches that market and your account — nothing more
  is claimed.
- **The Polymarket 5M game's data lives on the page.** The Poly API mirrors
  your *account* (balance, positions) — the game itself is what the Watcher
  reads off the page. That's why the plug's Poly cross-check compares two
  reads of the page, and why the balance read is the plug's proof.

## If something's off

- **NOT CONNECTED — HTTP 401 …** → the key ID and the secret/private key
  don't match each other, or the key was deleted at the venue. Make a fresh
  key at the venue and paste the new pair.
- **network/CORS failure …** → your browser couldn't reach the venue's API
  from the page. Check your connection; some strict browser setups block
  cross-site API calls from pages.
- **"this browser's WebCrypto may not support Ed25519 yet"** → update
  Edge/Chrome; Ed25519 signing needs a current browser.
- **BTC TRUTH — watcher not found** → the Watcher pack isn't loaded on the
  page. The plug needs it; it's the kit's shared stream.

## For the curious: how the signing works

Both recipes are copied from clients that already run verified against
these venues (provenance in `pack.json`):

- **Polymarket US** — sign `timestamp_ms + method + path` with Ed25519;
  headers `X-PM-Access-Key / X-PM-Timestamp / X-PM-Signature` (signature
  base64). Balance: `GET https://api.polymarket.us/v1/account/balances`.
- **Kalshi** — sign `timestamp_ms + method + full path` (the path carries
  its `/trade-api/v2` prefix) with your key — RSA-PSS/SHA-256 if your key
  is RSA, Ed25519 if it isn't; headers `KALSHI-ACCESS-KEY /
  KALSHI-ACCESS-SIGNATURE / KALSHI-ACCESS-TIMESTAMP`. Balance:
  `GET https://api.elections.kalshi.com/trade-api/v2/portfolio/balance`.

`test_venue_plug.js` proves both signers against throwaway keys — every
signature the plug produces in the tests is verified against the matching
public key, and no test ever calls a live venue.
