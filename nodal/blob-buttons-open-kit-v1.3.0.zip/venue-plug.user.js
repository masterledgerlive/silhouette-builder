// ==UserScript==
// @name         Blob Buttons — Venue Plug (READ-ONLY venue accounts + BTC truth line)
// @namespace    blob-buttons/koda-kai
// @version      0.1.0
// @description  OPTIONAL add-on for the Blob Buttons Full Kit: plug in YOUR OWN Polymarket US or Kalshi API keys — stored only in this browser, used only to READ your balance — and cross-check the page's BTC numbers against the venue's own BTC reference, because the BTC data does not lie. It cannot place orders: every network call in this file is a read, by construction. Talks to the Watcher only through window.BlobWatcherState() and its on-device log. Pack: venue-plug (blob-button-pack/0, id: venue-plug).
// @author       Koda Kai Network (David's house build)
// @match        *://polymarket.us/event/btc-updown-5m-*
// @run-at       document-idle
// @grant        none
// ==/UserScript==

(function () {
  'use strict';

  /* ------------------------------------------------------------------
   * Blob Buttons — VENUE PLUG v0.1.0
   *
   * What this is: the kit, made easy for anyone. The Watcher reads the
   * Polymarket US 5-minute BTC page. This plug lets the person at the
   * keyboard plug in their OWN venue account — Polymarket US or
   * Kalshi — so the kit can (a) prove the plug works by reading the
   * account balance back, and (b) cross-check the BTC numbers on the
   * page against the venue's own BTC reference (the BTC TRUTH line).
   *
   * THE READ-ONLY LAW, by construction:
   *   - Every network call in this file is an HTTP read (the fetch
   *     calls below all pass the read method explicitly — grep them).
   *   - There is no order code here at all: no order endpoints, no
   *     order payload builders, nothing that could move money.
   *   - Keys are stored ONLY in this browser's localStorage, on this
   *     machine (key 'blobbtn.venueplug.v1'). They are sent ONLY to
   *     the venue they belong to, as signing headers on reads.
   *   - DISCONNECT wipes the stored keys from this browser.
   *
   * SIGNING RECIPES (copied from the house's verified clients — see
   * README-FOR-ANYONE.md for provenance):
   *   - Polymarket US (official SDK recipe): message =
   *     timestamp_ms + method + path, Ed25519, signature base64;
   *     headers X-PM-Access-Key / X-PM-Timestamp / X-PM-Signature.
   *     The secret the venue shows you is base64: a 32-byte seed, or
   *     a 64-byte key whose first 32 bytes are the seed.
   *     Balance read: GET https://api.polymarket.us/v1/account/balances
   *   - Kalshi (the house client's recipe, production-verified):
   *     message = timestamp_ms + method + FULL path (the path carries
   *     its /trade-api/v2 prefix), signature base64; headers
   *     KALSHI-ACCESS-KEY / KALSHI-ACCESS-SIGNATURE /
   *     KALSHI-ACCESS-TIMESTAMP. Kalshi issues BOTH RSA and Ed25519
   *     keys; this plug reads the algorithm out of your key file and
   *     signs accordingly (RSA-PSS with SHA-256, or Ed25519). A
   *     PKCS#1 RSA key ("BEGIN RSA PRIVATE KEY") is wrapped into
   *     PKCS#8 in-memory so WebCrypto can import it.
   *     Balance read: GET https://api.elections.kalshi.com/trade-api/v2/portfolio/balance
   *     (the venue answers in cents; the panel shows dollars).
   *
   * THE BTC TRUTH LINE (polled every ~15 s while connected):
   *   - Kalshi: the venue value is the live KXBTC15M market's strike
   *     (floor_strike), read from Kalshi's PUBLIC events feed — no key
   *     needed for that read. It is cross-checked against the page's
   *     price-to-beat from the Watcher. Both are window-open BTC
   *     strikes, so they should agree; a gap over $25 is flagged.
   *   - Polymarket US: the venue has no separate BTC feed for this
   *     game — its prices live on this page (the API mirrors the
   *     account, not the game). So the plug reads the page's own beat
   *     directly off the page with a small independent reader and
   *     cross-checks the Watcher's beat against it: two independent
   *     reads of the same number should agree exactly.
   *   - Honesty law: if a value cannot be fetched or read, the line
   *     SAYS SO ("venue check unavailable", "page beat unreadable").
   *     It never prints a match it did not measure.
   *
   * VENUE TRUTHS, printed in the panel where nobody can miss them:
   *   - Kalshi has NO 5-minute BTC game. Its fastest is the
   *     15-minute KXBTC15M. This plug watches that market + your
   *     account; it does not pretend otherwise.
   *   - The Polymarket 5M game's data lives on the page. The Poly API
   *     mirrors your account; the game itself is read by the Watcher.
   *
   * Talks to the Watcher ONLY through its published surfaces:
   * window.BlobWatcherState() and its localStorage log
   * 'blobbtn.poly5m.v1'. If the Watcher is absent, the panel says so.
   * ------------------------------------------------------------------ */

  var STORE_KEY = 'blobbtn.venueplug.v1';
  var WATCHER_LOG_KEY = 'blobbtn.poly5m.v1';
  var CHIP_ID = 'blobbtn-venueplug-chip';
  var PANEL_ID = 'blobbtn-venueplug-panel';
  var KALSHI_BASE = 'https://api.elections.kalshi.com/trade-api/v2';
  var POLY_API = 'https://api.polymarket.us';
  var TRUTH_MS = 15000;
  var DIVERGE_USD = 25;

  var VENUE_LINES = {
    poly: 'Venue truth: Polymarket US has no separate BTC feed for this game — ' +
          'the 5-minute prices live on this page. The API mirrors your account ' +
          '(balance, positions), not the game.',
    kalshi: 'Venue truth: Kalshi has NO 5-minute BTC game — its fastest is the ' +
            '15-minute KXBTC15M. This plug reads your Kalshi account and ' +
            'cross-checks BTC against that market\u2019s strike.',
    none: 'Page-watch only: the Watcher reads the page; no venue account is plugged in.'
  };

  /* ---------------- small helpers ---------------- */

  function $(id) { return document.getElementById(id); }

  function fmtMoney(v) {
    return (v === null || v === undefined || !isFinite(v)) ? '\u2014'
      : '$' + Number(v).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  }

  function utf8Bytes(str) {
    var out = [];
    var s = String(str);
    for (var i = 0; i < s.length; i++) {
      var c = s.charCodeAt(i);
      if (c < 0x80) { out.push(c); }
      else if (c < 0x800) { out.push(0xc0 | (c >> 6), 0x80 | (c & 0x3f)); }
      else if (c >= 0xd800 && c <= 0xdbff && i + 1 < s.length) {
        var cp = 0x10000 + ((c - 0xd800) << 10) + (s.charCodeAt(++i) - 0xdc00);
        out.push(0xf0 | (cp >> 18), 0x80 | ((cp >> 12) & 0x3f),
                 0x80 | ((cp >> 6) & 0x3f), 0x80 | (cp & 0x3f));
      } else { out.push(0xe0 | (c >> 12), 0x80 | ((c >> 6) & 0x3f), 0x80 | (c & 0x3f)); }
    }
    return new Uint8Array(out);
  }

  function b64ToBytes(b64) {
    var clean = String(b64 || '').replace(/\s+/g, '').replace(/-/g, '+').replace(/_/g, '/');
    while (clean.length % 4) clean += '=';
    var bin = atob(clean);
    var out = new Uint8Array(bin.length);
    for (var i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i);
    return out;
  }

  function bytesToB64(bytes) {
    var s = '';
    var CH = 0x8000;
    for (var i = 0; i < bytes.length; i += CH) {
      s += String.fromCharCode.apply(null, bytes.subarray(i, i + CH));
    }
    return btoa(s);
  }

  function hexToBytes(hex) {
    var out = new Uint8Array(hex.length / 2);
    for (var i = 0; i < out.length; i++) out[i] = parseInt(hex.substr(i * 2, 2), 16);
    return out;
  }

  /* ---------------- tiny DER kit (key import only) ---------------- */

  function derLen(n) {
    if (n < 0x80) return [n];
    var bytes = [];
    var v = n;
    while (v > 0) { bytes.unshift(v & 0xff); v = v >> 8; }
    return [0x80 | bytes.length].concat(bytes);
  }

  function derTlv(tag, content) {
    var head = [tag].concat(derLen(content.length));
    var out = new Uint8Array(head.length + content.length);
    out.set(head, 0);
    out.set(content, head.length);
    return out;
  }

  // "BEGIN PRIVATE KEY" (PKCS#8) or "BEGIN RSA PRIVATE KEY" (PKCS#1)
  // -> { der, kind: 'pkcs8' | 'pkcs1' }
  function pemToDer(pem) {
    var text = String(pem || '');
    var kind = /BEGIN RSA PRIVATE KEY/.test(text) ? 'pkcs1' : 'pkcs8';
    var body = text.replace(/-----BEGIN [^-]+-----/, '')
                   .replace(/-----END [^-]+-----/, '');
    return { der: b64ToBytes(body), kind: kind };
  }

  // Wrap a PKCS#1 RSA key in a PKCS#8 envelope so WebCrypto imports it.
  function pkcs1ToPkcs8(pkcs1) {
    var algId = derTlv(0x30, hexToBytes('06092a864886f70d0101010500')); // rsaEncryption + NULL
    var version = derTlv(0x02, new Uint8Array([0]));
    var octets = derTlv(0x04, pkcs1);
    var body = new Uint8Array(version.length + algId.length + octets.length);
    body.set(version, 0);
    body.set(algId, version.length);
    body.set(octets, version.length + algId.length);
    return derTlv(0x30, body);
  }

  // Read the algorithm OID out of a PKCS#8 blob: SEQUENCE { INTEGER,
  // SEQUENCE { OID, ... }, OCTET STRING }.
  function pkcs8AlgOid(der) {
    var pos = 0;
    // Reads a TLV header and leaves pos at the content start.
    function readHeader() {
      var tag = der[pos++];
      var len = der[pos++];
      if (len & 0x80) {
        var n = len & 0x7f;
        len = 0;
        for (var i = 0; i < n; i++) len = (len << 8) | der[pos++];
      }
      return { tag: tag, start: pos, len: len };
    }
    if (der[pos] !== 0x30) return null;
    readHeader();                    // outer SEQUENCE — step in
    if (der[pos] !== 0x02) return null;
    var v = readHeader();            // version INTEGER — skip it
    pos = v.start + v.len;
    if (der[pos] !== 0x30) return null;
    readHeader();                    // algorithm SEQUENCE — step in
    if (der[pos] !== 0x06) return null;
    var oidTlv = readHeader();
    var bytes = der.subarray(oidTlv.start, oidTlv.start + oidTlv.len);
    if (!bytes.length) return null;
    var first = bytes[0];
    var parts = first >= 80 ? [2, first - 80] : [Math.floor(first / 40), first % 40];
    var val = 0;
    for (var i = 1; i < bytes.length; i++) {
      val = (val << 7) | (bytes[i] & 0x7f);
      if (!(bytes[i] & 0x80)) { parts.push(val); val = 0; }
    }
    return parts.join('.');
  }

  var OID_RSA = '1.2.840.113549.1.1.1';
  var OID_ED25519 = '1.3.101.112';
  var ED25519_PKCS8_PREFIX = '302e020100300506032b657004220420';

  function subtle() {
    if (!window.crypto || !window.crypto.subtle) {
      throw new Error('this browser has no WebCrypto (crypto.subtle) — the plug cannot sign reads here');
    }
    return window.crypto.subtle;
  }

  /* ---------------- Kalshi signing ----------------
   * Recipe (house client, production-verified): the signed string is
   * timestamp_ms + method + FULL path (with its /trade-api/v2 prefix).
   * Kalshi issues RSA and Ed25519 keys; the algorithm is read from the
   * key file itself. */

  function importKalshiKey(pem) {
    var parsed = pemToDer(pem);
    var der = parsed.der;
    var alg = null;
    if (parsed.kind === 'pkcs1') {
      der = pkcs1ToPkcs8(der);
      alg = 'rsa';
    } else {
      var oid = pkcs8AlgOid(der);
      if (oid === OID_RSA) alg = 'rsa';
      else if (oid === OID_ED25519) alg = 'ed25519';
      else throw new Error('unrecognised Kalshi key type (algorithm OID ' + (oid || 'unreadable') +
                           ') — Kalshi keys are RSA or Ed25519');
    }
    var sc = subtle();
    var importAlg = alg === 'rsa'
      ? { name: 'RSA-PSS', hash: 'SHA-256' }
      : { name: 'Ed25519' };
    return sc.importKey('pkcs8', der, importAlg, false, ['sign']).then(function (key) {
      return { key: key, alg: alg };
    }, function (e) {
      throw new Error('Kalshi key import failed: ' + (e && e.message ? e.message : e));
    });
  }

  function signKalshi(imported, timestamp, method, fullPath) {
    var msg = utf8Bytes(String(timestamp) + method + fullPath);
    var sc = subtle();
    var p = imported.alg === 'rsa'
      ? sc.sign({ name: 'RSA-PSS', saltLength: 32 }, imported.key, msg)
      : sc.sign({ name: 'Ed25519' }, imported.key, msg);
    return p.then(function (sig) { return bytesToB64(new Uint8Array(sig)); });
  }

  /* ---------------- Polymarket US signing ----------------
   * Recipe (official SDK): the signed string is
   * timestamp_ms + method + path. The secret is base64: a 32-byte
   * Ed25519 seed, or 64 bytes whose first 32 are the seed. */

  function importPolyKey(secretB64) {
    var raw = b64ToBytes(secretB64);
    if (raw.length === 64) raw = raw.subarray(0, 32);
    if (raw.length !== 32) {
      throw new Error('Polymarket secret decoded to ' + raw.length +
                      ' bytes — expected the base64 secret the venue showed you (32-byte seed)');
    }
    var der = new Uint8Array(ED25519_PKCS8_PREFIX.length / 2 + 32);
    der.set(hexToBytes(ED25519_PKCS8_PREFIX), 0);
    der.set(raw, ED25519_PKCS8_PREFIX.length / 2);
    return subtle().importKey('pkcs8', der, { name: 'Ed25519' }, false, ['sign'])
      .then(function (key) { return { key: key, alg: 'ed25519' }; }, function (e) {
        throw new Error('Polymarket key import failed (this browser\u2019s WebCrypto may not support Ed25519 yet): ' +
                        (e && e.message ? e.message : e));
      });
  }

  function signPoly(imported, timestamp, method, path) {
    var msg = utf8Bytes(String(timestamp) + method + path);
    return subtle().sign({ name: 'Ed25519' }, imported.key, msg)
      .then(function (sig) { return bytesToB64(new Uint8Array(sig)); });
  }

  /* ---------------- read-only HTTP ----------------
   * The ONLY network helper in this file. It takes no method: reads
   * are the only thing it can express. */

  function httpGetJson(url, headers) {
    var opts = { method: 'GET', headers: headers || {} };
    return fetch(url, opts).then(function (res) {
      return res.text().then(function (text) {
        var json = null;
        try { json = JSON.parse(text); } catch (e) {}
        if (!res.ok) {
          var why = 'HTTP ' + res.status;
          if (json && (json.message || json.error)) why += ' — ' + (json.message || json.error);
          else if (text) why += ' — ' + text.slice(0, 120);
          throw new Error(why);
        }
        if (json === null) throw new Error('venue answered with non-JSON (HTTP ' + res.status + ')');
        return json;
      });
    }, function (e) {
      throw new Error('network/CORS failure reaching the venue: ' + (e && e.message ? e.message : e));
    });
  }

  /* ---------------- venue balance reads ---------------- */

  function kalshiBalance(cred) {
    var path = '/trade-api/v2/portfolio/balance';
    return importKalshiKey(cred.pem).then(function (imported) {
      var ts = String(Date.now());
      return signKalshi(imported, ts, 'GET', path).then(function (sig) {
        return httpGetJson(KALSHI_BASE + '/portfolio/balance', {
          'KALSHI-ACCESS-KEY': cred.keyId,
          'KALSHI-ACCESS-SIGNATURE': sig,
          'KALSHI-ACCESS-TIMESTAMP': ts,
          'Accept': 'application/json'
        });
      });
    }).then(function (json) {
      if (typeof json.balance !== 'number') {
        throw new Error('Kalshi balance reply had no balance field');
      }
      return {
        balanceUsd: json.balance / 100,
        extraUsd: typeof json.portfolio_value === 'number' ? json.portfolio_value / 100 : null,
        extraLabel: 'portfolio'
      };
    });
  }

  function polyBalance(cred) {
    var path = '/v1/account/balances';
    return importPolyKey(cred.secret).then(function (imported) {
      var ts = String(Date.now());
      return signPoly(imported, ts, 'GET', path).then(function (sig) {
        return httpGetJson(POLY_API + path, {
          'X-PM-Access-Key': cred.keyId,
          'X-PM-Timestamp': ts,
          'X-PM-Signature': sig,
          'Accept': 'application/json'
        });
      });
    }).then(function (json) {
      var list = json && json.balances;
      if (!list || !list.length) throw new Error('Polymarket balance reply had no balances');
      var pick = null;
      for (var i = 0; i < list.length; i++) {
        if (list[i] && String(list[i].currency || '').toUpperCase() === 'USD') { pick = list[i]; break; }
      }
      pick = pick || list[0];
      if (typeof pick.currentBalance !== 'number') {
        throw new Error('Polymarket balance reply had no currentBalance');
      }
      return {
        balanceUsd: pick.currentBalance,
        extraUsd: typeof pick.buyingPower === 'number' ? pick.buyingPower : null,
        extraLabel: 'buying power'
      };
    });
  }

  /* ---------------- the BTC truth line ---------------- */

  // Kalshi's public BTC reference: the live KXBTC15M market's strike.
  function kalshiBtcReference() {
    var url = KALSHI_BASE + '/events?series_ticker=KXBTC15M&status=open&with_nested_markets=true&limit=5';
    return httpGetJson(url, { 'Accept': 'application/json' }).then(function (json) {
      var evs = (json && json.events) || [];
      var now = Date.now();
      for (var i = 0; i < evs.length; i++) {
        var markets = evs[i].markets || [];
        for (var j = 0; j < markets.length; j++) {
          var m = markets[j];
          if (!m || !m.close_time) continue;
          var closeMs = Date.parse(m.close_time);
          if (isNaN(closeMs) || closeMs <= now) continue;
          var strike = (typeof m.floor_strike === 'number') ? m.floor_strike
                     : (typeof m.floor_strike === 'string' ? parseFloat(m.floor_strike) : null);
          if (strike === null || !isFinite(strike)) continue;
          return { value: strike, ticker: m.ticker || null, closeTime: m.close_time };
        }
      }
      throw new Error('no open KXBTC15M market with a strike right now');
    });
  }

  // The Watcher, through its published surfaces only.
  function watcherLatest() {
    try {
      if (typeof window.BlobWatcherState === 'function') {
        var st = window.BlobWatcherState();
        if (st && st.latest) return st.latest;
      }
    } catch (e) {}
    try {
      var raw = window.localStorage.getItem(WATCHER_LOG_KEY);
      if (raw) {
        var arr = JSON.parse(raw);
        if (arr && arr.length) return arr[arr.length - 1];
      }
    } catch (e) {}
    return null;
  }

  function isOurs(el) {
    var n = el;
    while (n) {
      if (n.id === PANEL_ID || n.id === CHIP_ID) return true;
      n = n.parentElement || n.parentNode || null;
    }
    return false;
  }

  // A small independent read of the page's own "Price to beat" — the
  // second pair of eyes the Poly cross-check compares the Watcher to.
  function pageBeatDirect() {
    try {
      var els = document.querySelectorAll('*');
      for (var i = 0; i < els.length; i++) {
        var el = els[i];
        if (isOurs(el)) continue;
        if ((el.children || []).length !== 0) continue;
        if (String(el.textContent || '').replace(/\s+/g, ' ').trim() !== 'Price to beat') continue;
        var box = el.parentElement || el.parentNode;
        if (!box) return null;
        var leaves = box.querySelectorAll('*');
        for (var j = 0; j < leaves.length; j++) {
          if (leaves[j] === el || isOurs(leaves[j])) continue;
          if ((leaves[j].children || []).length !== 0) continue;
          var m = String(leaves[j].textContent || '').match(/\$([\d,]+\.\d{2})/);
          if (m) return parseFloat(m[1].replace(/,/g, ''));
        }
        return null;
      }
    } catch (e) {}
    return null;
  }

  /* ---------------- stored plug state ---------------- */

  var state = {
    venue: 'none',           // 'none' | 'poly' | 'kalshi'
    connected: false,
    balanceUsd: null,
    extraUsd: null,
    extraLabel: null,
    lastError: null,
    truth: null              // {kind, text, pageVal, venueVal, diff, at}
  };
  var importedCache = {};    // venue -> imported key (memory only)

  function loadStore() {
    try {
      var raw = window.localStorage.getItem(STORE_KEY);
      if (raw) {
        var s = JSON.parse(raw);
        if (s && typeof s === 'object') return s;
      }
    } catch (e) {}
    return null;
  }

  function saveStore(s) {
    try { window.localStorage.setItem(STORE_KEY, JSON.stringify(s)); } catch (e) {}
  }

  function wipeStore() {
    try { window.localStorage.removeItem(STORE_KEY); } catch (e) {}
  }

  function storeCreds() {
    var s = loadStore() || {};
    if (state.venue === 'poly') {
      return (s.poly && s.poly.keyId && s.poly.secret) ? s.poly : null;
    }
    if (state.venue === 'kalshi') {
      return (s.kalshi && s.kalshi.keyId && s.kalshi.pem) ? s.kalshi : null;
    }
    return null;
  }

  function hasCreds(venue) {
    var s = loadStore() || {};
    if (venue === 'poly') return !!(s.poly && s.poly.keyId && s.poly.secret);
    if (venue === 'kalshi') return !!(s.kalshi && s.kalshi.keyId && s.kalshi.pem);
    return false;
  }

  /* ---------------- truth computation ---------------- */

  function setTruth(kind, text, pageVal, venueVal, diff) {
    state.truth = { kind: kind, text: text, pageVal: pageVal, venueVal: venueVal,
                    diff: diff, at: new Date().toISOString() };
    renderTruth();
  }

  function computeTruth() {
    if (!state.connected || state.venue === 'none') return Promise.resolve();
    var w = watcherLatest();
    var watcherBeat = w && typeof w.priceToBeat === 'number' ? w.priceToBeat : null;
    var live = w && typeof w.currentPrice === 'number' ? w.currentPrice : null;
    var liveBit = live !== null ? ' \u00b7 live ' + fmtMoney(live) : '';

    if (state.venue === 'kalshi') {
      return kalshiBtcReference().then(function (ref) {
        if (watcherBeat === null) {
          setTruth('unavailable',
            'BTC TRUTH \u2014 page beat unreadable \u00b7 Kalshi strike ' + fmtMoney(ref.value) +
            ' \u00b7 cannot cross-check' + liveBit, null, ref.value, null);
          return;
        }
        var diff = Math.abs(watcherBeat - ref.value);
        if (diff <= DIVERGE_USD) {
          setTruth('match',
            'BTC TRUTH \u2014 page ' + fmtMoney(watcherBeat) + ' \u00b7 venue ' + fmtMoney(ref.value) +
            ' \u00b7 MATCH \u2713' + liveBit, watcherBeat, ref.value, diff);
        } else {
          setTruth('diverge',
            'BTC TRUTH \u2014 page ' + fmtMoney(watcherBeat) + ' \u00b7 venue ' + fmtMoney(ref.value) +
            ' \u00b7 \u26a0 DIVERGES ' + fmtMoney(diff) + liveBit, watcherBeat, ref.value, diff);
        }
      }, function (e) {
        setTruth('unavailable',
          'BTC TRUTH \u2014 venue check unavailable (' + (e && e.message ? e.message : e) + ')' + liveBit,
          watcherBeat, null, null);
      });
    }

    // Polymarket US: no venue BTC feed exists for this game; the page's
    // own beat, read independently, is the reference.
    var direct = pageBeatDirect();
    if (watcherBeat === null && direct === null) {
      setTruth('unavailable',
        'BTC TRUTH \u2014 page beat unreadable on this page yet' + liveBit, null, null, null);
      return Promise.resolve();
    }
    if (watcherBeat === null) {
      setTruth('unavailable',
        'BTC TRUTH \u2014 page ' + fmtMoney(direct) + ' \u00b7 watcher not found \u2014 ' +
        'install the Watcher pack for the cross-check' + liveBit, direct, null, null);
      return Promise.resolve();
    }
    if (direct === null) {
      setTruth('unavailable',
        'BTC TRUTH \u2014 watcher ' + fmtMoney(watcherBeat) + ' \u00b7 page beat unreadable for the cross-check' + liveBit,
        watcherBeat, null, null);
      return Promise.resolve();
    }
    var pdiff = Math.abs(watcherBeat - direct);
    if (pdiff <= DIVERGE_USD) {
      setTruth('match',
        'BTC TRUTH \u2014 page ' + fmtMoney(direct) + ' \u00b7 watcher ' + fmtMoney(watcherBeat) +
        ' \u00b7 MATCH \u2713' + liveBit, direct, watcherBeat, pdiff);
    } else {
      setTruth('diverge',
        'BTC TRUTH \u2014 page ' + fmtMoney(direct) + ' \u00b7 watcher ' + fmtMoney(watcherBeat) +
        ' \u00b7 \u26a0 DIVERGES ' + fmtMoney(pdiff) + liveBit, direct, watcherBeat, pdiff);
    }
    return Promise.resolve();
  }

  /* ---------------- connect / disconnect ---------------- */

  var truthTimer = null;

  function startTruthTimer() {
    stopTruthTimer();
    computeTruth();
    truthTimer = setInterval(function () { computeTruth(); }, TRUTH_MS);
  }

  function stopTruthTimer() {
    if (truthTimer) { clearInterval(truthTimer); truthTimer = null; }
  }

  function connect() {
    var cred = storeCreds();
    if (state.venue === 'none') {
      state.connected = false;
      state.lastError = 'pick a venue first';
      renderStatus();
      return Promise.resolve();
    }
    if (!cred) {
      state.connected = false;
      state.lastError = 'no keys saved for this venue yet';
      renderStatus();
      return Promise.resolve();
    }
    var read = state.venue === 'poly' ? polyBalance(cred) : kalshiBalance(cred);
    return read.then(function (bal) {
      state.connected = true;
      state.balanceUsd = bal.balanceUsd;
      state.extraUsd = bal.extraUsd;
      state.extraLabel = bal.extraLabel;
      state.lastError = null;
      renderStatus();
      startTruthTimer();
    }, function (e) {
      state.connected = false;
      state.balanceUsd = null;
      state.lastError = e && e.message ? e.message : String(e);
      renderStatus();
    });
  }

  function disconnect() {
    wipeStore();
    importedCache = {};
    state.connected = false;
    state.balanceUsd = null;
    state.extraUsd = null;
    state.extraLabel = null;
    state.lastError = null;
    state.truth = null;
    stopTruthTimer();
    var ki = $('blobbtn-vp-poly-key'); if (ki) ki.value = '';
    var ks = $('blobbtn-vp-poly-secret'); if (ks) ks.value = '';
    var kk = $('blobbtn-vp-kalshi-key'); if (kk) kk.value = '';
    var kp = $('blobbtn-vp-kalshi-pem'); if (kp) kp.value = '';
    renderStatus();
    renderTruth();
  }

  /* ---------------- the panel ---------------- */

  var chip = null, panel = null, statusLine = null, truthLine = null, venueLine = null;

  function loadGeo(which) {
    var s = loadStore() || {};
    var g = s[which];
    if (g && typeof g.l === 'number' && typeof g.t === 'number') return g;
    return null;
  }

  function saveGeo(which, geo) {
    var s = loadStore() || {};
    s[which] = geo;
    saveStore(s);
  }

  function wireDrag(handle, target, geoKey) {
    var drag = null;
    var dragState = { moved: false };
    handle.addEventListener('pointerdown', function (ev) {
      if (ev.target && ev.target.closest &&
          ev.target.closest('button, input, select, textarea, a')) return;
      var rect = target.getBoundingClientRect();
      target.style.right = 'auto';
      target.style.bottom = 'auto';
      target.style.left = rect.left + 'px';
      target.style.top = rect.top + 'px';
      drag = { startX: ev.clientX, startY: ev.clientY, origX: rect.left, origY: rect.top, moved: false };
      try { handle.setPointerCapture(ev.pointerId); } catch (e) {}
    });
    handle.addEventListener('pointermove', function (ev) {
      if (!drag) return;
      var dx = ev.clientX - drag.startX, dy = ev.clientY - drag.startY;
      if (Math.abs(dx) + Math.abs(dy) > 3) drag.moved = true;
      var vw = window.innerWidth || 1280, vh = window.innerHeight || 720;
      var x = Math.max(0, Math.min(vw - 70, drag.origX + dx));
      var y = Math.max(0, Math.min(vh - 30, drag.origY + dy));
      target.style.left = x + 'px';
      target.style.top = y + 'px';
    });
    function end() {
      if (!drag) return;
      dragState.moved = drag.moved;
      if (drag.moved) {
        var rect = target.getBoundingClientRect();
        saveGeo(geoKey, { l: Math.round(rect.left), t: Math.round(rect.top) });
      }
      drag = null;
    }
    handle.addEventListener('pointerup', end);
    handle.addEventListener('pointercancel', end);
    return dragState;
  }

  function applyGeo(el, geo) {
    if (!el || !geo) return;
    el.style.right = 'auto';
    el.style.bottom = 'auto';
    el.style.left = geo.l + 'px';
    el.style.top = geo.t + 'px';
  }

  function fieldRow(labelText, input) {
    var wrap = document.createElement('div');
    wrap.style.cssText = 'margin-top:6px;';
    var lab = document.createElement('div');
    lab.textContent = labelText;
    lab.style.cssText = 'color:#9fb4c8;font-size:11px;';
    wrap.appendChild(lab);
    wrap.appendChild(input);
    return wrap;
  }

  function textInput(id, placeholder, password) {
    var el = document.createElement('input');
    el.id = id;
    el.type = password ? 'password' : 'text';
    el.placeholder = placeholder;
    el.autocomplete = 'off';
    el.style.cssText = 'width:100%;box-sizing:border-box;margin-top:2px;padding:4px 6px;' +
      'border-radius:6px;border:1px solid #22303f;background:#0b0e14;color:#e8ecf1;font:12px monospace;';
    return el;
  }

  function buildPanel() {
    try {
      chip = document.createElement('div');
      chip.id = CHIP_ID;
      chip.textContent = '\ud83d\udd0c VENUE';
      chip.title = 'Venue Plug \u2014 plug in your own venue account (read-only). Drag to move.';
      chip.style.cssText =
        'position:fixed;left:8px;bottom:8px;z-index:2147483646;cursor:pointer;' +
        'background:rgba(11,14,20,0.88);color:#7ee787;border:1px solid #22303f;' +
        'border-radius:999px;padding:5px 12px;font:bold 12px/1.4 -apple-system,Arial,sans-serif;' +
        'touch-action:none;user-select:none;-webkit-user-select:none;';
      (document.body || document.documentElement).appendChild(chip);
      applyGeo(chip, loadGeo('chipGeo'));
      var chipDrag = wireDrag(chip, chip, 'chipGeo');
      chip.addEventListener('click', function () {
        if (chipDrag.moved) { chipDrag.moved = false; return; }
        if (panel) panel.style.display = panel.style.display === 'none' ? 'block' : 'none';
      });

      panel = document.createElement('div');
      panel.id = PANEL_ID;
      panel.style.cssText =
        'position:fixed;left:8px;bottom:44px;z-index:2147483647;width:300px;display:none;' +
        'box-sizing:border-box;background:rgba(11,14,20,0.94);color:#e8ecf1;' +
        'border:1px solid #22303f;border-radius:10px;padding:8px 10px;' +
        'font:12px/1.5 -apple-system,Arial,sans-serif;';
      var head = document.createElement('div');
      head.style.cssText = 'display:flex;justify-content:space-between;align-items:center;cursor:move;touch-action:none;user-select:none;-webkit-user-select:none;';
      var title = document.createElement('span');
      title.textContent = '\ud83d\udd0c Venue Plug \u2014 read-only';
      title.style.cssText = 'font-weight:bold;color:#7ee787;';
      var xBtn = document.createElement('button');
      xBtn.textContent = '\u00d7';
      xBtn.title = 'Close (the chip reopens it)';
      xBtn.style.cssText = 'padding:0 7px;border-radius:6px;border:1px solid #22303f;background:#10151d;color:#e8ecf1;cursor:pointer;';
      xBtn.addEventListener('click', function () { panel.style.display = 'none'; });
      head.appendChild(title);
      head.appendChild(xBtn);
      panel.appendChild(head);

      var warn = document.createElement('div');
      warn.textContent = 'Keys live only in this browser. This plug READS ONLY \u2014 it cannot place orders.';
      warn.style.cssText = 'margin-top:5px;color:#ffd479;font-size:11px;';
      panel.appendChild(warn);

      var picker = document.createElement('div');
      picker.style.cssText = 'margin-top:7px;display:flex;gap:5px;';
      var venues = [['poly', 'Polymarket US'], ['kalshi', 'Kalshi'], ['none', 'None']];
      for (var i = 0; i < venues.length; i++) {
        (function (v, label) {
          var b = document.createElement('button');
          b.textContent = label;
          b.setAttribute('data-vp-venue', v);
          b.style.cssText = 'flex:1;padding:4px 2px;border-radius:6px;border:1px solid #22303f;background:#10151d;color:#e8ecf1;cursor:pointer;font-size:11px;';
          b.addEventListener('click', function () { pickVenue(v); });
          picker.appendChild(b);
        })(venues[i][0], venues[i][1]);
      }
      panel.appendChild(picker);

      venueLine = document.createElement('div');
      venueLine.style.cssText = 'margin-top:5px;color:#9fb4c8;font-size:11px;';
      panel.appendChild(venueLine);

      var polyBox = document.createElement('div');
      polyBox.id = 'blobbtn-vp-poly-box';
      polyBox.appendChild(fieldRow('Polymarket US \u2014 API Key ID', textInput('blobbtn-vp-poly-key', 'key id from polymarket.us/developer', false)));
      polyBox.appendChild(fieldRow('Secret key (base64, shown once at creation)', textInput('blobbtn-vp-poly-secret', 'base64 secret', true)));
      panel.appendChild(polyBox);

      var kalshiBox = document.createElement('div');
      kalshiBox.id = 'blobbtn-vp-kalshi-box';
      kalshiBox.appendChild(fieldRow('Kalshi \u2014 API Key ID', textInput('blobbtn-vp-kalshi-key', 'key id from your Kalshi API keys', false)));
      var pem = document.createElement('textarea');
      pem.id = 'blobbtn-vp-kalshi-pem';
      pem.placeholder = 'paste your private key (.key file contents, -----BEGIN ... PRIVATE KEY-----)';
      pem.style.cssText = 'width:100%;box-sizing:border-box;margin-top:2px;height:64px;padding:4px 6px;' +
        'border-radius:6px;border:1px solid #22303f;background:#0b0e14;color:#e8ecf1;font:11px monospace;';
      kalshiBox.appendChild(fieldRow('Private key (RSA or Ed25519, the .key file you downloaded)', pem));
      panel.appendChild(kalshiBox);

      var row = document.createElement('div');
      row.style.cssText = 'margin-top:8px;display:flex;gap:6px;';
      var connectBtn = document.createElement('button');
      connectBtn.id = 'blobbtn-vp-connect';
      connectBtn.textContent = 'CONNECT';
      connectBtn.style.cssText = 'flex:1;padding:5px 8px;border-radius:6px;border:1px solid #2c5f3a;background:#12351f;color:#7ee787;cursor:pointer;font-weight:bold;';
      connectBtn.addEventListener('click', function () { saveFieldsAndConnect(); });
      var discBtn = document.createElement('button');
      discBtn.id = 'blobbtn-vp-disconnect';
      discBtn.textContent = 'DISCONNECT \u2014 wipe keys';
      discBtn.style.cssText = 'flex:1;padding:5px 8px;border-radius:6px;border:1px solid #5f2c2c;background:#351212;color:#ff9c9c;cursor:pointer;';
      discBtn.addEventListener('click', function () { disconnect(); });
      row.appendChild(connectBtn);
      row.appendChild(discBtn);
      panel.appendChild(row);

      statusLine = document.createElement('div');
      statusLine.id = 'blobbtn-vp-status';
      statusLine.style.cssText = 'margin-top:6px;white-space:pre-line;';
      panel.appendChild(statusLine);

      truthLine = document.createElement('div');
      truthLine.id = 'blobbtn-vp-truth';
      truthLine.style.cssText = 'margin-top:4px;color:#9fb4c8;white-space:pre-line;';
      panel.appendChild(truthLine);

      (document.body || document.documentElement).appendChild(panel);
      applyGeo(panel, loadGeo('panelGeo'));
      wireDrag(head, panel, 'panelGeo');

      hydrateFields();
      pickVenue(state.venue, true);
      renderStatus();
      renderTruth();
    } catch (e) { panel = null; chip = null; }
  }

  function hydrateFields() {
    var s = loadStore() || {};
    if (s.poly) {
      var ki = $('blobbtn-vp-poly-key'); if (ki && s.poly.keyId) ki.value = s.poly.keyId;
      var ks = $('blobbtn-vp-poly-secret'); if (ks && s.poly.secret) ks.value = s.poly.secret;
    }
    if (s.kalshi) {
      var kk = $('blobbtn-vp-kalshi-key'); if (kk && s.kalshi.keyId) kk.value = s.kalshi.keyId;
      var kp = $('blobbtn-vp-kalshi-pem'); if (kp && s.kalshi.pem) kp.value = s.kalshi.pem;
    }
  }

  function pickVenue(v, silent) {
    state.venue = v;
    var s = loadStore() || {};
    s.venue = v;
    saveStore(s);
    var polyBox = $('blobbtn-vp-poly-box');
    var kalshiBox = $('blobbtn-vp-kalshi-box');
    if (polyBox) polyBox.style.display = v === 'poly' ? 'block' : 'none';
    if (kalshiBox) kalshiBox.style.display = v === 'kalshi' ? 'block' : 'none';
    if (venueLine) venueLine.textContent = VENUE_LINES[v] || '';
    var btns = panel ? panel.querySelectorAll('[data-vp-venue]') : [];
    for (var i = 0; i < btns.length; i++) {
      var on = btns[i].getAttribute('data-vp-venue') === v;
      btns[i].style.borderColor = on ? '#7ee787' : '#22303f';
      btns[i].style.color = on ? '#7ee787' : '#e8ecf1';
    }
    if (v === 'none') {
      state.connected = false;
      stopTruthTimer();
      state.truth = null;
      renderStatus();
      renderTruth();
    } else if (!silent) {
      renderStatus();
    }
  }

  function saveFieldsAndConnect() {
    var s = loadStore() || {};
    s.venue = state.venue;
    if (state.venue === 'poly') {
      s.poly = {
        keyId: ($('blobbtn-vp-poly-key') || {}).value || '',
        secret: ($('blobbtn-vp-poly-secret') || {}).value || ''
      };
      s.poly.keyId = String(s.poly.keyId).trim();
      s.poly.secret = String(s.poly.secret).trim();
    } else if (state.venue === 'kalshi') {
      s.kalshi = {
        keyId: String((($('blobbtn-vp-kalshi-key') || {}).value || '')).trim(),
        pem: String((($('blobbtn-vp-kalshi-pem') || {}).value || '')).trim()
      };
    }
    saveStore(s);
    importedCache = {};
    connect();
  }

  function renderStatus() {
    if (!statusLine) return;
    if (state.venue === 'none') {
      statusLine.textContent = 'PAGE-WATCH ONLY \u2014 no venue plugged in';
      statusLine.style.color = '#9fb4c8';
      return;
    }
    if (state.connected) {
      var t = 'CONNECTED \u2713 \u2014 balance ' + fmtMoney(state.balanceUsd);
      if (state.extraUsd !== null && state.extraUsd !== undefined) {
        t += ' \u00b7 ' + state.extraLabel + ' ' + fmtMoney(state.extraUsd);
      }
      statusLine.textContent = t;
      statusLine.style.color = '#7ee787';
      return;
    }
    statusLine.textContent = 'NOT CONNECTED' + (state.lastError ? ' \u2014 ' + state.lastError : '');
    statusLine.style.color = '#ff9c9c';
  }

  function renderTruth() {
    if (!truthLine) return;
    if (!state.truth) {
      truthLine.textContent = state.connected
        ? 'BTC TRUTH \u2014 checking\u2026'
        : 'BTC TRUTH \u2014 plug in a venue to cross-check the BTC data';
      truthLine.style.color = '#9fb4c8';
      return;
    }
    truthLine.textContent = state.truth.text;
    truthLine.style.color = state.truth.kind === 'match' ? '#7ee787'
      : state.truth.kind === 'diverge' ? '#ff9c9c' : '#ffd479';
  }

  /* ---------------- live surface (state only, never keys) ---------------- */

  try {
    window.BlobVenuePlugState = function () {
      return {
        version: '0.1.0',
        venue: state.venue,
        connected: state.connected,
        balanceUsd: state.balanceUsd,
        extraUsd: state.extraUsd,
        extraLabel: state.extraLabel,
        lastError: state.lastError,
        truth: state.truth,
        hasCreds: { poly: hasCreds('poly'), kalshi: hasCreds('kalshi') }
      };
    };
    // Test hooks: the pure signers + parsers, for the pack's local
    // signature-verification harness. No key material lives here —
    // these take keys as arguments and return signatures.
    window.BlobVenuePlugTest = {
      importKalshiKey: importKalshiKey,
      signKalshi: signKalshi,
      importPolyKey: importPolyKey,
      signPoly: signPoly,
      kalshiBtcReference: kalshiBtcReference,
      pageBeatDirect: pageBeatDirect,
      pemToDer: pemToDer,
      pkcs1ToPkcs8: pkcs1ToPkcs8,
      pkcs8AlgOid: pkcs8AlgOid
    };
  } catch (e) {}

  /* ---------------- go ---------------- */

  function start() {
    var s = loadStore();
    if (s && (s.venue === 'poly' || s.venue === 'kalshi')) state.venue = s.venue;
    buildPanel();
    // A saved plug re-verifies itself on load: plug once, stays plugged.
    if (state.venue !== 'none' && storeCreds()) connect();
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', start);
  } else {
    start();
  }
})();
