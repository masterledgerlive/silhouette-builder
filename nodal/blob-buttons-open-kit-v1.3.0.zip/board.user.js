// ==UserScript==
// @name         Blob Buttons — The Board (Pack #3, LIGHTS ONLY)
// @namespace    blob-buttons/koda-kai
// @version      0.1.5
// @description  The Board: draggable, resizable call buttons that sit over the Polymarket US BTC 5-minute page and FLASH the call — BUY UP / BUY DOWN / BUY (the page's submit confirm) / SELL / REVERSAL — in big high-contrast words. It reads Pack #2's watcher stream and lights up; David's own tap on the page is what trades. The Board never presses anything. Pack #3 of the Blob Button Field (blob-button-pack/0, id: board).
// @author       Koda Kai Network (David's house build)
// @match        *://polymarket.us/event/btc-updown-5m-*
// @run-at       document-idle
// @grant        none
// ==/UserScript==

(function () {
  'use strict';

  /* ------------------------------------------------------------------
   * Blob Buttons Pack #3 — THE BOARD
   *
   * HARD GUARANTEE: LIGHTS ONLY. This script never presses, taps, or
   * activates any control the page owns. It contains no programmatic
   * press call, no synthetic event delivery, no form interaction, and
   * no network call of any kind. It does exactly three things:
   *   1. READS the newest sample from Pack #2's watcher stream
   *      (the watcher's own on-device log, localStorage key
   *      "blobbtn.poly5m.v1" — the Board produces no readings of its
   *      own on the real page), or, on practice.html only, the
   *      practice page's big demo percentage.
   *   2. RENDERS its own overlay buttons and changes their words,
   *      colours, and pulse according to the rules below.
   *   3. REMEMBERS its own layout (positions, sizes, lock) and its
   *      demo position in its own localStorage key.
   *   4. WATCHES taps pass through it (v0.1.2, the reaction journal):
   *      one passive document click listener — capture-phase, passive,
   *      LOCKED mode only — records where a tap landed, what it hit,
   *      and how long after the flash it came. It never prevents,
   *      stops, or redirects a tap; the page's own handlers always
   *      run exactly as they would without the Board.
   *   5. BOOTS LOCKED whenever a saved layout exists (v0.1.3): a
   *      reload can never strand David in EDIT with his taps
   *      dragging the buttons instead of passing through — only a
   *      true first run boots EDIT. The toolbar lock control is a
   *      big state pill that spells the mode in words, an EDIT-mode
   *      tap on a button raises a reminder toast, and every button
   *      carries a per-button glass opacity (applied in both modes)
   *      so the page's numbers stay readable through the light.
   *   6. KEEPS SCORE (v0.1.4, the Scorekeeper): the DEMO flash law
   *      is two-stage — ARM (pulsing outline, "GET READY") prepares
   *      the human, then FIRE — and in LOCKED play the Board scores
   *      what David does with each fire: POINT for a fast correct
   *      tap-through, SLOW and NO-PRESS misses, TAKE PROFIT and
   *      MISSED EXIT on the sell light, ⚑ GREED and ⚑ GAMBLING
   *      flags, and a WIN when a point's side settles right at the
   *      window roll. The score lives on-device in localStorage
   *      "blobbtn.board.score.v1"; the journal stays passive-only.
   *   7. FREEFORM + BUY (v0.1.5, David's live-test fixes): a FIFTH
   *      button, BUY, sits over the page's big submit control —
   *      picking a side is not the trade; the page still makes him
   *      press its "Buy $…" submit, and v0.1.4 had the SELL blob
   *      parked on that spot, mislabelled. BUY's light mirrors the
   *      sides (dark with no pick, ARM glow with a heating pick,
   *      FIRE when a pick is hot — "PRESS BUY TO CONFIRM"), SELL's
   *      default moves just below the submit, and a LOCKED tap
   *      through BUY onto the submit IS the entry tap for the hot
   *      side (POINT/SLOW as usual; BUY with no light = ⚑ GAMBLING;
   *      BUY's own fire clearing untapped is never a NO-PRESS —
   *      the side's fire carries that verdict). The TOOLBAR is
   *      freeform too: drag it by its header in either mode, resize
   *      it by its corner grip; its geometry persists in the same
   *      store. And the boot rule got broader: ANY earlier store
   *      shape carrying button geometry — old key names, old
   *      containers, a version field with remnants — counts as a
   *      saved layout and boots LOCKED.
   * Apart from that one passive listener, the only elements it ever
   * listens to are its own overlay elements.
   *
   * THE PARTNERSHIP MODEL (David's design): the layover lights up,
   * DAVID taps. In LOCKED (live) mode the Board's buttons are
   * pointer-events:none — pure light — so David's tap passes straight
   * through the glowing button to the real page control underneath it.
   * In EDIT (unlocked) mode the buttons accept his pointer so he can
   * drag them over the page's controls, resize them to match, and —
   * demo only — tap a lit BUY button to mark "I took it", which is
   * how the demo SELL / REVERSAL rules get a position to work with.
   *
   * RULES STATUS: DEMO RULES v0. The thresholds below are placeholders
   * that prove the light states; they are labelled DEMO in the UI and
   * in pack.json. The desk's real signal rules are a later wiring.
   *
   * David is deaf: the visual signal IS the interface. Every state is
   * carried by the WORD on the button plus colour — never colour alone.
   * ------------------------------------------------------------------ */

  var BOARD_KEY = 'blobbtn.board.v1';
  var WATCH_KEY = 'blobbtn.poly5m.v1'; // Pack #2's sample stream
  var ROOT_ID = 'blobbtn-board';
  var POLL_MS = 250; // v0.1.2: tightened from 400 — light lag behind the stream stays sub-second
  var WATCH_FRESH_MS = 20000;
  var TAPS_KEY = 'blobbtn.board.taps.v1'; // the reaction journal (v0.1.2)
  var TAPS_CAP = 200;
  var SCORE_KEY = 'blobbtn.board.score.v1'; // the Scorekeeper (v0.1.4)
  var POINT_MAX_MS = 2000; // a correct tap slower than this is a SLOW miss, not a point
  var FEED_KEEP = 12;      // flag events remembered in the score store
  var FEED_SHOW = 4;       // flag events shown in the toolbar feed

  /* DEMO RULES v0 — thresholds (percent points) */
  var ARM_PCT = 55;    // side at/above this = ARMED
  var CALL_PCT = 62;   // side at/above this = FLASHING CALL
  var SELL_DROP = 5;   // position side this far under entry = SELL armed
  var SELL_FLOOR = 50; // position side at/below this = SELL flashing
  var LATE_SEC = 60;   // countdown at/below this = SELL armed
  var LAST_SEC = 15;   // countdown at/below this (+ side < 60) = SELL flashing

  var BUTTON_DEFS = [
    { id: 'buyUp',    label: 'BUY UP',   side: 'up'   },
    { id: 'buyDown',  label: 'BUY DOWN', side: 'down' },
    { id: 'sell',     label: 'SELL',     side: null   },
    { id: 'reversal', label: 'REVERSAL', side: null   },
    { id: 'buy',      label: 'BUY',      side: null   }
  ];

  /* First-run defaults (v0.1.1): pre-placed over the real page's
   * Trade panel, right-anchored to the viewport and sized to match
   * the page's own controls — Up/Down ~152x49 side by side, the wide
   * action button ~318x49 under the Amount row (geometry verified
   * from a live screenshot of the 5M page, 2026-11-15). Computed from
   * window.innerWidth at first run; used ONLY when no saved layout
   * exists — David's own saved placements always win, and RESET
   * LAYOUT returns to these computed defaults.
   * v0.1.5: the wide row under the Amount row is the page's SUBMIT
   * ("Buy $…") — that anchor now belongs to BUY; SELL's default sits
   * just below the submit area and REVERSAL below that. */
  function defaultLayout() {
    var vw = 0;
    try { vw = window.innerWidth || 0; } catch (e) {}
    function rx(off) { return Math.max(8, vw - off); }
    return {
      buyUp:    { x: rx(366), y: 261, w: 152, h: 49 },
      buyDown:  { x: rx(198), y: 261, w: 152, h: 49 },
      buy:      { x: rx(366), y: 470, w: 318, h: 49 },
      sell:     { x: rx(366), y: 535, w: 318, h: 49 },
      reversal: { x: rx(366), y: 600, w: 318, h: 49 }
    };
  }

  /* Toolbar geometry (v0.1.5): the bar starts where it always has
   * (top-left, CSS-sized); w/h stay null — "the current geometry" —
   * until David resizes it by its corner grip, after which the
   * numbers persist like any other part of the layout. */
  function defaultBar() {
    return { x: 8, y: 8, w: null, h: null };
  }

  /* ---------------- state (ours only) ---------------- */

  /* Per-button glass steps (v0.1.3): the cycle on each button. */
  var OP_STEPS = [1, 0.7, 0.5, 0.35, 0.2];

  var state = {
    locked: false,
    layout: defaultLayout(),
    bar: defaultBar(), // toolbar geometry (v0.1.5): {x, y, w|null, h|null}
    opacity: {}, // per-button glass (v0.1.3): button id -> 0.2..1
    position: null // demo only: {side:'up'|'down', entryPct:n, window:label|null}
  };
  for (var oi = 0; oi < BUTTON_DEFS.length; oi++) state.opacity[BUTTON_DEFS[oi].id] = 1;

  /* One geometry record, any era's shape: finite x/y/w/h, numbers
   * or numeric strings (older stores were not always tidy). */
  function geomOk(g) {
    return !!g && typeof g === 'object' &&
      isFinite(+g.x) && isFinite(+g.y) && isFinite(+g.w) && isFinite(+g.h);
  }

  /* v0.1.5 BOOT-LOCK ROBUSTNESS: "a saved layout exists" used to
   * mean "geometry under a CURRENT button id in s.layout" — but
   * David's real stores from the v0.1.0/v0.1.1 era carried their
   * geometry under older key names and older containers, so two of
   * his machines booted EDIT on layouts he had plainly saved. The
   * rule now: ANY prior store shape carrying button geometry —
   * geometry under any key of the layout map (known ids or not),
   * under an older container name, at the top level under a button
   * id, or a version field alongside any layout-ish remnant —
   * counts as a saved layout. Detection only: geometry that maps
   * onto current ids is still merged by loadState below; geometry
   * that cannot map still proves he placed a Board before, which
   * is all the boot rule needs. */
  function storeHasLayout(s) {
    if (!s || typeof s !== 'object') return false;
    var i, k, m;
    if (s.layout && typeof s.layout === 'object') {
      for (k in s.layout) { if (geomOk(s.layout[k])) return true; }
    }
    var altKeys = ['buttons', 'geometry', 'positions', 'rects', 'btns'];
    for (i = 0; i < altKeys.length; i++) {
      m = s[altKeys[i]];
      if (m && typeof m === 'object') {
        for (k in m) { if (geomOk(m[k])) return true; }
      }
    }
    for (i = 0; i < BUTTON_DEFS.length; i++) {
      if (geomOk(s[BUTTON_DEFS[i].id])) return true;
    }
    var hasVersion = (typeof s.version === 'string' || typeof s.version === 'number' ||
                      typeof s.v === 'string' || typeof s.v === 'number');
    if (hasVersion && (s.layout || s.buttons || s.geometry || s.positions ||
                       s.position || s.opacity)) return true;
    return false;
  }

  function numOr(v, dflt) {
    var n = +v;
    return isFinite(n) ? n : dflt;
  }

  function loadState() {
    try {
      var raw = window.localStorage.getItem(BOARD_KEY);
      if (!raw) return; // true first run: boots EDIT (the state defaults)
      var s = JSON.parse(raw);
      if (!s || typeof s !== 'object') return;
      if (s.layout) {
        for (var i = 0; i < BUTTON_DEFS.length; i++) {
          var g = s.layout[BUTTON_DEFS[i].id];
          if (geomOk(g)) {
            state.layout[BUTTON_DEFS[i].id] = { x: +g.x, y: +g.y, w: +g.w, h: +g.h };
          }
        }
      }
      if (s.opacity) {
        for (var j = 0; j < BUTTON_DEFS.length; j++) {
          var o = s.opacity[BUTTON_DEFS[j].id];
          if (typeof o === 'number' && o >= 0.1 && o <= 1) state.opacity[BUTTON_DEFS[j].id] = o;
        }
      }
      /* Toolbar geometry (v0.1.5): additive — older stores simply
       * have no bar field and keep the default placement. */
      if (s.bar && typeof s.bar === 'object') {
        state.bar = {
          x: Math.max(0, numOr(s.bar.x, 8)),
          y: Math.max(0, numOr(s.bar.y, 8)),
          w: (typeof s.bar.w === 'number' && s.bar.w >= 200) ? s.bar.w : null,
          h: (typeof s.bar.h === 'number' && s.bar.h >= 100) ? s.bar.h : null
        };
      }
      /* v0.1.3 BOOT RULE, broadened in v0.1.5: a saved layout means
       * David has placed the Board before — boot LOCKED
       * (tap-through armed) no matter what mode the store was left
       * in, so a reload can never strand him dragging buttons when
       * he means to tap through. Only a true first run (no saved
       * layout in ANY era's shape) boots EDIT. Stores saved by
       * v0.1.1/v0.1.2 load unchanged. */
      if (storeHasLayout(s)) state.locked = true;
      else if (typeof s.locked === 'boolean') state.locked = s.locked;
      if (s.position && (s.position.side === 'up' || s.position.side === 'down')) {
        state.position = s.position;
      }
    } catch (e) {}
  }

  function saveState() {
    try {
      window.localStorage.setItem(BOARD_KEY, JSON.stringify(state));
    } catch (e) {}
  }

  /* ---------------- feeds ----------------
   * Both adapters return the watcher's sample shape (subset):
   * {upPct, downPct, countdownSec, window, source}. */

  function watcherSample() {
    try {
      var raw = window.localStorage.getItem(WATCH_KEY);
      if (!raw) return null;
      var arr = JSON.parse(raw);
      if (!arr || Object.prototype.toString.call(arr) !== '[object Array]' || !arr.length) return null;
      var s = arr[arr.length - 1];
      if (!s || typeof s.upPct !== 'number' || typeof s.downPct !== 'number') return null;
      var age = Date.now() - Date.parse(s.ts || '');
      if (isNaN(age) || age > WATCH_FRESH_MS) return null; // stale stream: not a live reading
      return {
        upPct: s.upPct, downPct: s.downPct,
        countdownSec: (typeof s.countdownSec === 'number') ? s.countdownSec : null,
        window: s.window || null,
        ageMs: age,
        source: 'watcher'
      };
    } catch (e) { return null; }
  }

  function practiceSample() {
    try {
      var el = document.getElementById('pct');
      if (!el) return null;
      var m = String(el.textContent || '').match(/(\d+)\s*%/);
      if (!m) return null;
      var up = parseInt(m[1], 10);
      if (isNaN(up)) return null;
      return {
        upPct: up, downPct: 100 - up, countdownSec: null,
        window: null, source: 'practice'
      };
    } catch (e) { return null; }
  }

  function currentSample() {
    return watcherSample() || practiceSample();
  }

  /* ---------------- styles ---------------- */

  var CSS = [
    '#' + ROOT_ID + '{position:fixed;left:0;top:0;width:0;height:0;z-index:2147483646;',
    'font-family:Arial,Helvetica,sans-serif;-webkit-user-select:none;user-select:none;}',
    '#' + ROOT_ID + ' .bb-bar{position:fixed;left:8px;top:8px;pointer-events:auto;z-index:2;',
    'background:rgba(11,14,20,0.92);border:1px solid #22303f;border-radius:10px;',
    'padding:6px 8px;color:#e8ecf1;max-width:400px;box-sizing:border-box;}',
    /* v0.1.5: the header is the bar's drag handle — in BOTH modes */
    '#' + ROOT_ID + ' .bb-bar .bb-title{font-size:12px;font-weight:bold;color:#7ee787;letter-spacing:0.5px;cursor:move;}',
    /* v0.1.5: the bar's corner resize grip — always reachable */
    '#' + ROOT_ID + ' .bb-bargrip{position:absolute;right:0;bottom:0;width:22px;height:22px;',
    'cursor:nwse-resize;z-index:3;}',
    '#' + ROOT_ID + ' .bb-bargrip:before{content:"";position:absolute;right:3px;bottom:3px;width:12px;height:12px;',
    'border-right:4px solid #7ee787;border-bottom:4px solid #7ee787;}',
    '#' + ROOT_ID + ' .bb-bar .bb-status{font-size:11px;color:#9fb4c8;line-height:1.45;margin-top:2px;white-space:pre-line;}',
    '#' + ROOT_ID + ' .bb-bar .bb-stats{font-size:11px;color:#ffd94d;line-height:1.45;margin-top:2px;}',
    /* v0.1.4: the Scorekeeper's line + flags feed */
    '#' + ROOT_ID + ' .bb-bar .bb-score{font-size:12px;font-weight:bold;color:#7ee787;line-height:1.45;margin-top:3px;}',
    '#' + ROOT_ID + ' .bb-bar .bb-feed{font-size:11px;line-height:1.5;margin-top:2px;color:#9fb4c8;}',
    '#' + ROOT_ID + ' .bb-bar .bb-feed .fl-red{color:#ff9d94;}',
    '#' + ROOT_ID + ' .bb-bar .bb-feed .fl-good{color:#7ee787;}',
    '#' + ROOT_ID + ' .bb-bar button{pointer-events:auto;margin:4px 4px 0 0;padding:4px 10px;',
    'border-radius:6px;border:1px solid #22303f;background:#10151d;color:#e8ecf1;font-size:12px;font-weight:bold;}',
    /* v0.1.3: the lock control is a big state PILL — the mode in
       words, impossible to miss, never colour alone */
    '#' + ROOT_ID + ' .bb-bar .bb-pill{display:block;width:100%;margin:6px 0 2px 0;padding:10px 12px;',
    'font-size:15px;border-radius:8px;border:2px solid #22303f;box-sizing:border-box;}',
    '#' + ROOT_ID + '.bb-live .bb-pill{background:#0d5c26;border-color:#39d353;color:#eafff0;}',
    '#' + ROOT_ID + '.bb-editing .bb-pill{background:#5c4308;border-color:#ffd94d;color:#fff6d8;}',
    /* v0.1.3: the EDIT-mode reminder toast */
    '#' + ROOT_ID + ' .bb-toast{display:none;margin-top:6px;padding:8px 10px;border-radius:8px;',
    'background:#5c4308;border:2px solid #ffd94d;color:#fff6d8;font-size:13px;font-weight:bold;line-height:1.4;}',
    '#' + ROOT_ID + ' .bb-toast.bb-show{display:block;}',
    /* v0.1.3: per-button glass control (EDIT mode only). Kept to a
       deterministic 16px height in the top corner so it can never
       reach the button's centre — David's tap point stays the
       button's own, even on the small 152x49 defaults. */
    '#' + ROOT_ID + ' .bb-opctl{position:absolute;top:2px;right:2px;display:none;z-index:3;',
    'background:rgba(11,14,20,0.92);color:#ffd94d;border:1px solid #ffd94d;border-radius:6px;',
    'font-size:10px;font-weight:bold;padding:1px 4px;cursor:pointer;line-height:1.2;}',
    '#' + ROOT_ID + '.bb-editing .bb-opctl{display:block;}',
    '#' + ROOT_ID + ' .bb-btn{position:fixed;border-radius:14px;border:4px solid #3a4656;z-index:1;',
    'background:rgba(16,21,29,0.88);color:#e8ecf1;overflow:hidden;box-sizing:border-box;',
    'display:flex;flex-direction:column;align-items:center;justify-content:center;text-align:center;}',
    '#' + ROOT_ID + '.bb-editing .bb-btn{pointer-events:auto;cursor:move;}',
    '#' + ROOT_ID + '.bb-live .bb-btn{pointer-events:none;}',
    '#' + ROOT_ID + ' .bb-word{font-size:32px;font-weight:900;letter-spacing:1px;line-height:1.05;padding:0 6px;max-width:100%;white-space:nowrap;}',
    '#' + ROOT_ID + ' .bb-sub{font-size:13px;font-weight:bold;color:#c8d4e2;line-height:1.3;padding:2px 8px 0 8px;}',
    '#' + ROOT_ID + ' .bb-handle{position:absolute;right:0;bottom:0;width:22px;height:22px;',
    'cursor:nwse-resize;display:none;}',
    '#' + ROOT_ID + ' .bb-handle:before{content:"";position:absolute;right:3px;bottom:3px;width:12px;height:12px;',
    'border-right:4px solid #ffd94d;border-bottom:4px solid #ffd94d;}',
    '#' + ROOT_ID + '.bb-editing .bb-handle{display:block;}',
    /* states: the WORD changes with the state; colour is the backup singer */
    '#' + ROOT_ID + ' .bb-btn.st-armed{border-color:#ffd94d;background:rgba(66,54,8,0.92);animation:bbArmPulse 0.9s infinite;}',
    '#' + ROOT_ID + ' .bb-btn.st-armed .bb-sub{color:#ffd94d;}',
    '@keyframes bbArmPulse{0%{box-shadow:0 0 0 0 rgba(255,217,77,0.55);}100%{box-shadow:0 0 0 10px rgba(255,217,77,0);}}',
    '#' + ROOT_ID + ' .bb-btn.side-up.st-flash{animation:bbPulseUp 0.7s infinite alternate;}',
    '#' + ROOT_ID + ' .bb-btn.side-down.st-flash{animation:bbPulseDown 0.7s infinite alternate;}',
    '#' + ROOT_ID + ' .bb-btn.act-sell.st-flash{animation:bbPulseSell 0.7s infinite alternate;}',
    '#' + ROOT_ID + ' .bb-btn.act-rev.st-flash{animation:bbPulseRev 0.7s infinite alternate;}',
    /* v0.1.5: BUY flashes in the page submit's own blue */
    '#' + ROOT_ID + ' .bb-btn.act-buy.st-flash{animation:bbPulseBuy 0.7s infinite alternate;}',
    '#' + ROOT_ID + ' .bb-btn.st-flash .bb-word{font-size:36px;}',
    '#' + ROOT_ID + ' .bb-btn.st-flash .bb-sub{color:#ffffff;font-size:12px;}',
    '@keyframes bbPulseUp{from{background:#0d5c26;border-color:#39d353;}to{background:#23a344;border-color:#a7f3c0;}}',
    '@keyframes bbPulseDown{from{background:#5c0d12;border-color:#f85149;}to{background:#c92a2e;border-color:#ffc1bc;}}',
    '@keyframes bbPulseSell{from{background:#5c2d0d;border-color:#ffa94d;}to{background:#d97c06;border-color:#ffe1b0;}}',
    '@keyframes bbPulseRev{from{background:#34155c;border-color:#b197fc;}to{background:#7048c9;border-color:#e5dbff;}}',
    '@keyframes bbPulseBuy{from{background:#0d2f5c;border-color:#4d9fff;}to{background:#0b5ed7;border-color:#b0d4ff;}}'
  ].join('\n');

  /* ---------------- build the overlay ---------------- */

  var root = null, statusEl = null, statsEl = null, lockBtn = null, toastEl = null, glassBtn = null;
  var scoreEl = null, feedEl = null;
  var barEl = null, barGripEl = null;
  var btnEls = {}; // id -> {box, word, sub, op}

  function buildBoard() {
    var style = document.createElement('style');
    style.textContent = CSS;
    (document.head || document.documentElement).appendChild(style);

    root = document.createElement('div');
    root.id = ROOT_ID;

    var bar = document.createElement('div');
    bar.className = 'bb-bar';
    barEl = bar;
    var title = document.createElement('div');
    title.className = 'bb-title';
    title.textContent = '🌊 THE BOARD — lights only, never presses · DEMO RULES · ⠿ drag to move';
    statusEl = document.createElement('div');
    statusEl.className = 'bb-status';
    statusEl.textContent = 'waiting for readings…';
    statsEl = document.createElement('div');
    statsEl.className = 'bb-stats';
    statsEl.textContent = '⚡ reaction journal — no taps yet this session';
    scoreEl = document.createElement('div');
    scoreEl.className = 'bb-score';
    feedEl = document.createElement('div');
    feedEl.className = 'bb-feed';
    lockBtn = document.createElement('button');
    lockBtn.type = 'button';
    lockBtn.className = 'bb-pill';
    lockBtn.addEventListener('click', function () {
      state.locked = !state.locked;
      saveState();
      applyMode();
    });
    toastEl = document.createElement('div');
    toastEl.className = 'bb-toast';
    toastEl.textContent = 'EDIT MODE — taps drag here. LOCK to pass taps through.';
    var resetBtn = document.createElement('button');
    resetBtn.type = 'button';
    resetBtn.textContent = 'RESET LAYOUT';
    resetBtn.addEventListener('click', function () {
      state.layout = defaultLayout();
      for (var ri = 0; ri < BUTTON_DEFS.length; ri++) state.opacity[BUTTON_DEFS[ri].id] = 1;
      state.position = null;
      saveState();
      applyLayout();
      updateGlassBtn();
      evaluate(lastSample);
    });
    glassBtn = document.createElement('button');
    glassBtn.type = 'button';
    glassBtn.className = 'bb-glass';
    glassBtn.textContent = 'ALL GLASS 50%';
    glassBtn.addEventListener('click', function () {
      var allHalf = true, gi;
      for (gi = 0; gi < BUTTON_DEFS.length; gi++) {
        if (state.opacity[BUTTON_DEFS[gi].id] !== 0.5) { allHalf = false; break; }
      }
      var target = allHalf ? 1 : 0.5;
      for (gi = 0; gi < BUTTON_DEFS.length; gi++) state.opacity[BUTTON_DEFS[gi].id] = target;
      saveState();
      applyLayout();
      updateGlassBtn();
    });
    barGripEl = document.createElement('div');
    barGripEl.className = 'bb-bargrip';
    bar.appendChild(title);
    bar.appendChild(statusEl);
    bar.appendChild(statsEl);
    bar.appendChild(scoreEl);
    bar.appendChild(feedEl);
    bar.appendChild(lockBtn);
    bar.appendChild(toastEl);
    bar.appendChild(resetBtn);
    bar.appendChild(glassBtn);
    bar.appendChild(barGripEl);
    root.appendChild(bar);
    attachBarDrag(title);
    attachBarResize(barGripEl);

    for (var i = 0; i < BUTTON_DEFS.length; i++) {
      (function (def) {
        var box = document.createElement('div');
        box.className = 'bb-btn ' + (def.side ? 'side-' + def.side
          : (def.id === 'sell' ? 'act-sell' : (def.id === 'buy' ? 'act-buy' : 'act-rev')));
        box.setAttribute('data-bb-id', def.id);
        var word = document.createElement('div');
        word.className = 'bb-word';
        word.textContent = def.label;
        var sub = document.createElement('div');
        sub.className = 'bb-sub';
        sub.textContent = '—';
        var op = document.createElement('div');
        op.className = 'bb-opctl';
        op.textContent = 'GLASS 100%';
        var handle = document.createElement('div');
        handle.className = 'bb-handle';
        box.appendChild(word);
        box.appendChild(sub);
        box.appendChild(op);
        box.appendChild(handle);
        root.appendChild(box);
        btnEls[def.id] = { box: box, word: word, sub: sub, op: op, def: def };
        attachOpacity(op, def.id);
        attachPointer(box, handle, def.id);
      })(BUTTON_DEFS[i]);
    }

    (document.body || document.documentElement).appendChild(root);
    applyLayout();
    applyBar();
    applyMode();
    updateGlassBtn();
    updateStats();
    renderScore();
  }

  function applyLayout() {
    for (var id in btnEls) {
      if (!btnEls.hasOwnProperty(id)) continue;
      var g = state.layout[id], el = btnEls[id].box;
      el.style.left = g.x + 'px';
      el.style.top = g.y + 'px';
      el.style.width = g.w + 'px';
      el.style.height = g.h + 'px';
      // v0.1.3: the glass applies in BOTH modes — the locked
      // transparency is the point (David reads the data under it).
      var opv = (typeof state.opacity[id] === 'number') ? state.opacity[id] : 1;
      el.style.opacity = String(opv);
      if (btnEls[id].op) btnEls[id].op.textContent = 'GLASS ' + Math.round(opv * 100) + '%';
    }
  }

  function applyMode() {
    if (!root) return;
    root.className = state.locked ? 'bb-live' : 'bb-editing';
    if (lockBtn) lockBtn.textContent = state.locked ? '🔒 LOCKED — TAP-THROUGH ARMED' : '✏️ EDIT — TAPS DRAG';
  }

  /* ---------------- toolbar freeform (v0.1.5) ----------------
   * The bar is David's console, not a button: it stays grabbable in
   * BOTH modes (its buttons are separate elements with their own
   * handlers, and the buttons' drag only exists in EDIT), so he can
   * always shove it out of the way mid-play. Drag by the header,
   * resize by the corner grip; geometry persists in the board
   * store like the buttons' layout. */

  function applyBar() {
    if (!barEl) return;
    barEl.style.left = state.bar.x + 'px';
    barEl.style.top = state.bar.y + 'px';
    if (typeof state.bar.w === 'number') {
      barEl.style.width = state.bar.w + 'px';
      barEl.style.maxWidth = 'none';
    } else {
      barEl.style.width = '';
      barEl.style.maxWidth = '';
    }
    if (typeof state.bar.h === 'number') {
      barEl.style.height = state.bar.h + 'px';
      barEl.style.overflow = 'auto'; // a hand-shrunk bar stays reachable
    } else {
      barEl.style.height = '';
      barEl.style.overflow = '';
    }
  }

  function attachBarDrag(handleEl) {
    var drag = null;
    handleEl.addEventListener('pointerdown', function (ev) {
      drag = { startX: ev.clientX, startY: ev.clientY, origX: state.bar.x, origY: state.bar.y };
      try { handleEl.setPointerCapture(ev.pointerId); } catch (e) {}
      ev.preventDefault();
    });
    handleEl.addEventListener('pointermove', function (ev) {
      if (!drag) return;
      state.bar.x = Math.max(0, drag.origX + (ev.clientX - drag.startX));
      state.bar.y = Math.max(0, drag.origY + (ev.clientY - drag.startY));
      applyBar();
    });
    handleEl.addEventListener('pointerup', function () {
      if (!drag) return;
      drag = null;
      saveState();
    });
  }

  function attachBarResize(gripEl) {
    var drag = null;
    gripEl.addEventListener('pointerdown', function (ev) {
      var r = barEl.getBoundingClientRect();
      drag = { startX: ev.clientX, startY: ev.clientY, origW: r.width, origH: r.height };
      try { gripEl.setPointerCapture(ev.pointerId); } catch (e) {}
      ev.preventDefault();
      ev.stopPropagation();
    });
    gripEl.addEventListener('pointermove', function (ev) {
      if (!drag) return;
      state.bar.w = Math.max(260, Math.round(drag.origW + (ev.clientX - drag.startX)));
      state.bar.h = Math.max(120, Math.round(drag.origH + (ev.clientY - drag.startY)));
      applyBar();
    });
    gripEl.addEventListener('pointerup', function () {
      if (!drag) return;
      drag = null;
      saveState();
    });
  }

  /* ---------------- glass: per-button opacity (v0.1.3) ---------------- */

  function attachOpacity(op, id) {
    // The glass control is a control, not a button tap: it keeps its
    // pointer events to itself, so the box never starts a drag off
    // it and the demo bookkeeping never sees it.
    op.addEventListener('pointerdown', function (ev) { ev.stopPropagation(); });
    op.addEventListener('pointerup', function (ev) { ev.stopPropagation(); });
    op.addEventListener('click', function (ev) {
      ev.stopPropagation();
      var idx = OP_STEPS.indexOf(state.opacity[id]);
      state.opacity[id] = OP_STEPS[(idx + 1) % OP_STEPS.length];
      saveState();
      applyLayout();
      updateGlassBtn();
    });
  }

  function updateGlassBtn() {
    if (!glassBtn) return;
    var allHalf = true;
    for (var i = 0; i < BUTTON_DEFS.length; i++) {
      if (state.opacity[BUTTON_DEFS[i].id] !== 0.5) { allHalf = false; break; }
    }
    glassBtn.textContent = allHalf ? 'ALL GLASS 100%' : 'ALL GLASS 50%';
  }

  /* ---------------- the EDIT-mode reminder toast (v0.1.3) ---------------- */

  var toastTimer = null;

  function showToast() {
    if (!toastEl) return;
    toastEl.classList.add('bb-show');
    if (toastTimer) clearTimeout(toastTimer);
    toastTimer = setTimeout(function () {
      if (toastEl) toastEl.classList.remove('bb-show');
    }, 2000);
  }

  /* ---------------- drag / resize / tap (our own elements only) ---------------- */

  function attachPointer(box, handle, id) {
    var drag = null;

    box.addEventListener('pointerdown', function (ev) {
      if (state.locked) return; // live mode: we are light, not a surface
      var onHandle = ev.target === handle;
      drag = {
        mode: onHandle ? 'resize' : 'move',
        startX: ev.clientX, startY: ev.clientY,
        orig: { x: state.layout[id].x, y: state.layout[id].y, w: state.layout[id].w, h: state.layout[id].h },
        moved: false
      };
      try { box.setPointerCapture(ev.pointerId); } catch (e) {}
      ev.preventDefault();
    });

    box.addEventListener('pointermove', function (ev) {
      if (!drag) return;
      var dx = ev.clientX - drag.startX, dy = ev.clientY - drag.startY;
      if (Math.abs(dx) + Math.abs(dy) > 6) drag.moved = true;
      var g = state.layout[id];
      if (drag.mode === 'move') {
        g.x = Math.max(0, drag.orig.x + dx);
        g.y = Math.max(0, drag.orig.y + dy);
      } else {
        g.w = Math.max(90, drag.orig.w + dx);
        g.h = Math.max(54, drag.orig.h + dy);
      }
      applyLayout();
    });

    box.addEventListener('pointerup', function (ev) {
      if (!drag) return;
      var wasTap = !drag.moved;
      drag = null;
      saveState();
      if (wasTap) {
        if (!state.locked) showToast(); // v0.1.3: EDIT is never a silent surprise
        onBoardTap(id);
      }
    });
  }

  /* Demo-only bookkeeping: in EDIT mode, tapping a board button marks
   * what David did on the real page ("I took it" / "I'm out" /
   * "I flipped it"). On the real page in LIVE mode there is no tap —
   * the tap goes through to the page, and position truth belongs to
   * the page. This demo marker is labelled demo wherever it shows. */
  function onBoardTap(id) {
    var s = lastSample;
    if (!s) return;
    if (id === 'buyUp' || id === 'buyDown') {
      var side = (id === 'buyUp') ? 'up' : 'down';
      state.position = {
        side: side,
        entryPct: (side === 'up') ? s.upPct : s.downPct,
        window: s.window || null
      };
    } else if (id === 'buy') {
      // v0.1.5 demo bookkeeping: confirming a hot pick marks the
      // position on the hotter side, exactly as tapping that side's
      // own button would — BUY is the confirm press of the flow.
      var hotSide = (s.upPct >= s.downPct) ? 'up' : 'down';
      var hotPct = Math.max(s.upPct, s.downPct);
      if (hotPct >= CALL_PCT) {
        state.position = { side: hotSide, entryPct: hotPct, window: s.window || null };
      }
    } else if (id === 'sell') {
      state.position = null;
    } else if (id === 'reversal') {
      if (state.position) {
        var ns = (state.position.side === 'up') ? 'down' : 'up';
        state.position = {
          side: ns,
          entryPct: (ns === 'up') ? s.upPct : s.downPct,
          window: s.window || null
        };
      }
    }
    saveState();
    evaluate(s);
  }

  /* ---------------- the light logic (DEMO RULES v0) ---------------- */

  var lastSample = null;

  /* Two-stage stage bookkeeping (v0.1.4): for each button, the
   * moment the current ARM began and the moment the current FIRE
   * began — the ARM is the "preparing for human" stage, so the
   * journal can time a tap against both (ready = ARM→tap, reaction
   * = FIRE→tap). A fire that ignites straight from idle gets
   * arm == fire: no separate prep stage happened. */
  var stageInfo = {};  // id -> {armPerf, armWall, firePerf, fireWall, window}
  var activeFire = {}; // id -> {fireWall, scored, takeProfit, sidePct}

  function setBtn(id, st, word, sub) {
    var b = btnEls[id];
    if (!b) return;
    var prev = b.box.getAttribute('data-bb-state') || 'idle';
    if (st !== prev) {
      var nowP = performance.now(), nowW = Date.now();
      if (prev === 'flash' && st !== 'flash') onFireEnd(id);
      if (st === 'armed') {
        var sa = stageInfo[id] || (stageInfo[id] = {});
        sa.armPerf = nowP; sa.armWall = nowW;
      } else if (st === 'flash') {
        var sf = stageInfo[id] || (stageInfo[id] = {});
        if (prev !== 'armed' || typeof sf.armWall !== 'number') {
          sf.armPerf = nowP; sf.armWall = nowW; // no prep stage: arm == fire
        }
        sf.firePerf = nowP; sf.fireWall = nowW;
        sf.window = (lastSample && lastSample.window) || null;
        onFireStart(id);
      } else { // idle: the episode is over
        delete stageInfo[id];
      }
    }
    b.box.classList.remove('st-idle', 'st-armed', 'st-flash');
    b.box.classList.add('st-' + st);
    b.box.setAttribute('data-bb-state', st);
    if (word) b.word.textContent = word;
    if (sub !== undefined) b.sub.textContent = sub;
  }

  function fmtCd(sec) {
    if (sec === null || sec === undefined) return '—';
    var m = Math.floor(sec / 60), s = sec % 60;
    return m + ':' + (s < 10 ? '0' : '') + s;
  }

  function evaluate(s) {
    var prevSample = lastSample;
    lastSample = s;
    if (!root) return;

    // Scorekeeper: the window rolled — settle any open point
    // against the closing window's final reading (v0.1.4).
    if (s && prevSample && prevSample.window && s.window && prevSample.window !== s.window) {
      settleWindow(prevSample);
    }

    if (!s) {
      setBtn('buyUp', 'idle', 'BUY UP', 'no readings yet');
      setBtn('buyDown', 'idle', 'BUY DOWN', 'no readings yet');
      setBtn('buy', 'idle', 'BUY', 'no readings yet');
      setBtn('sell', 'idle', 'SELL', 'no readings yet');
      setBtn('reversal', 'idle', 'REVERSAL', 'no readings yet');
      if (statusEl) statusEl.textContent = 'waiting for readings…';
      return;
    }

    // A new window rolls the demo position off (demo bookkeeping only).
    if (state.position && s.window && state.position.window && s.window !== state.position.window) {
      state.position = null;
      saveState();
    }

    var up = s.upPct, dn = s.downPct, cd = s.countdownSec;

    // BUY buttons: the side's own percentage drives its own light.
    var sides = [
      { id: 'buyUp', label: 'BUY UP', pct: up, pageWord: 'UP' },
      { id: 'buyDown', label: 'BUY DOWN', pct: dn, pageWord: 'DOWN' }
    ];
    for (var i = 0; i < sides.length; i++) {
      var sd = sides[i];
      if (sd.pct >= CALL_PCT) {
        setBtn(sd.id, 'flash', sd.label, "TAP THE PAGE'S " + sd.pageWord + ' BUTTON · ' + sd.pct + '%');
      } else if (sd.pct >= ARM_PCT) {
        setBtn(sd.id, 'armed', sd.label, 'GET READY · ' + sd.pct + '% and climbing');
      } else {
        setBtn(sd.id, 'idle', sd.label, sd.pct + '% · watching');
      }
    }

    // BUY (v0.1.5): the page's submit confirm. Picking a side is
    // not the trade — the page still wants its own "Buy $…" press,
    // and this light rides over that control. Its law mirrors the
    // sides (DEMO, labelled): DARK while no side is chosen, ARM
    // glow while a pick heats up, FIRE when a pick is hot — the
    // confirm is the press that counts.
    var hotPct = Math.max(up, dn);
    var hotWord = (up >= dn) ? 'UP' : 'DOWN';
    if (hotPct >= CALL_PCT) {
      setBtn('buy', 'flash', 'BUY', 'PRESS BUY TO CONFIRM · ' + hotWord + ' ' + hotPct + '%');
    } else if (hotPct >= ARM_PCT) {
      setBtn('buy', 'armed', 'BUY', 'GET READY · ' + hotWord + ' pick heating up · ' + hotPct + '%');
    } else {
      setBtn('buy', 'idle', 'BUY', 'no side chosen yet');
    }

    // SELL / REVERSAL: driven by the demo position, when one is marked.
    var pos = state.position;
    if (!pos) {
      setBtn('sell', 'idle', 'SELL', 'no position marked (demo)');
      setBtn('reversal', 'idle', 'REVERSAL', 'needs a position first (demo)');
    } else {
      var sidePct = (pos.side === 'up') ? up : dn;
      var oppPct = (pos.side === 'up') ? dn : up;
      var oppWord = (pos.side === 'up') ? 'DOWN' : 'UP';

      var sellFlash = sidePct <= SELL_FLOOR || (cd !== null && cd <= LAST_SEC && sidePct < 60);
      var sellArmed = sidePct <= pos.entryPct - SELL_DROP || (cd !== null && cd <= LATE_SEC);
      if (sellFlash) {
        // Scorekeeper: with a scored point still open, this fire is
        // the TAKE PROFIT moment for that entry — the button says so.
        var tpNote = score.openEntry
          ? ' · TAKE PROFIT on your ' + score.openEntry.side.toUpperCase() + ' point' : '';
        setBtn('sell', 'flash', 'SELL', 'EXIT NOW · your side ' + sidePct + '% · in @ ' + pos.entryPct + '%' + tpNote);
      } else if (sellArmed) {
        setBtn('sell', 'armed', 'SELL', 'GET READY · position ' + pos.side.toUpperCase() + ' @ ' + pos.entryPct + '% · side now ' + sidePct + '% — watch the exit');
      } else {
        setBtn('sell', 'idle', 'SELL', 'position ' + pos.side.toUpperCase() + ' @ ' + pos.entryPct + '% · side ' + sidePct + '% · holding');
      }

      // David's page-flow fact, named on the button: pressing the
      // opposite side prompts "do you agree to reverse" — a confirm
      // step exists in the flow, so the light says so before he taps.
      var revSub = "Page asks: 'Do you agree to reverse?' — tap " + oppWord + ', then confirm';
      if (oppPct >= CALL_PCT) {
        setBtn('reversal', 'flash', 'REVERSE?', revSub + ' · other side ' + oppPct + '%');
      } else if (oppPct >= ARM_PCT) {
        setBtn('reversal', 'armed', 'REVERSAL', 'GET READY · ' + revSub + ' · other side ' + oppPct + '%');
      } else {
        setBtn('reversal', 'idle', 'REVERSAL', 'other side ' + oppPct + '% · your side is holding');
      }
    }

    if (statusEl) {
      statusEl.textContent =
        (s.source === 'watcher' ? 'WATCHER FEED' : 'DEMO FEED (practice page)') +
        ' · Up ' + up + '% · Down ' + dn + '% · ⏳ ' + fmtCd(cd) +
        (s.source === 'watcher' && typeof s.ageMs === 'number'
          ? ' · stream ' + (s.ageMs / 1000).toFixed(1) + 's old' : '') +
        '\n' + (pos ? 'demo position: ' + pos.side.toUpperCase() + ' @ ' + pos.entryPct + '%' : 'no demo position') +
        ' · ' + (state.locked ? 'LOCKED — lights only' : 'EDIT — drag to place');
    }
  }

  /* ---------------- the Scorekeeper (v0.1.4) ----------------
   * David's law: the detector fires, he clicks through, and the
   * Board keeps score — real points or misses. The fire is
   * two-stage (ARM prepares the human, then FIRE), and in LOCKED
   * (live) play every fire is judged exactly once:
   *   POINT        a correct tap-through within 2 s of the FIRE
   *   SLOW miss    a correct tap, but over 2 s after the FIRE —
   *                human lag, no point
   *   NO-PRESS     the fire went out with no tap at all
   *   TAKE PROFIT  the SELL light fires while a point is open
   *   MISSED EXIT  that SELL fire goes out untapped
   *   ⚑ GREED      a buy tap (or any wrong control) during a
   *                SELL / REVERSAL fire — chasing while the exit
   *                light is up
   *   ⚑ GAMBLING   a tap-through with no light up anywhere
   *   WIN          at the window roll, the open point's side
   *                matches the settled direction read from the
   *                stream's final % majority — never invented:
   *                an unreadable settle scores nothing.
   *   BUY (v0.1.5) the fifth light, over the page's submit: a tap
   *                through it while a side FIREs is that side's
   *                entry tap (POINT/SLOW above, judged on BUY's own
   *                fire clock — the two light in the same pass);
   *                with no light up it is ⚑ GAMBLING like any
   *                no-light tap; its own fire clearing untapped is
   *                never a NO-PRESS (the side's fire carries it).
   * EDIT mode is placement and demo: no score is kept there. The
   * score persists on-device in SCORE_KEY; the flags feed (last
   * FEED_SHOW events) renders under the score line, SELL / TAKE
   * PROFIT / GREED in red — word + symbol, never colour alone. */

  var score = freshScore();

  function freshScore() {
    return {
      points: 0, slow: 0, noPress: 0, missedExits: 0,
      greed: 0, gambling: 0, wins: 0,
      feed: [],        // newest first: {t, kind, label}
      openEntry: null  // last POINT not yet exited/settled: {side, entryPct, window}
    };
  }

  function loadScore() {
    try {
      var raw = window.localStorage.getItem(SCORE_KEY);
      if (!raw) return;
      var s = JSON.parse(raw);
      if (!s || typeof s !== 'object') return;
      var nums = ['points', 'slow', 'noPress', 'missedExits', 'greed', 'gambling', 'wins'];
      for (var i = 0; i < nums.length; i++) {
        if (typeof s[nums[i]] === 'number' && s[nums[i]] >= 0) score[nums[i]] = Math.floor(s[nums[i]]);
      }
      if (s.feed && Object.prototype.toString.call(s.feed) === '[object Array]') {
        score.feed = s.feed.slice(0, FEED_KEEP);
      }
      if (s.openEntry && (s.openEntry.side === 'up' || s.openEntry.side === 'down')) {
        score.openEntry = s.openEntry;
      }
    } catch (e) {}
  }

  function saveScore() {
    try { window.localStorage.setItem(SCORE_KEY, JSON.stringify(score)); } catch (e) {}
  }

  function labelOf(id) {
    for (var i = 0; i < BUTTON_DEFS.length; i++) {
      if (BUTTON_DEFS[i].id === id) return BUTTON_DEFS[i].label;
    }
    return id;
  }

  function sampleSidePct(side) {
    if (!lastSample) return null;
    return side === 'up' ? lastSample.upPct : lastSample.downPct;
  }

  /* The side button flashing right now (v0.1.5: a BUY tap is
   * judged as the entry tap for this side). Both sides at FIRE at
   * once cannot happen on a two-outcome stream — the percentages
   * sum to 100 — but if it ever did, the fresher fire wins, so the
   * verdict stays deterministic. */
  function flashingSideId() {
    var upF = btnEls.buyUp && btnEls.buyUp.box.getAttribute('data-bb-state') === 'flash';
    var dnF = btnEls.buyDown && btnEls.buyDown.box.getAttribute('data-bb-state') === 'flash';
    if (upF && dnF) {
      var au = stageInfo.buyUp, ad = stageInfo.buyDown;
      return (au && ad && typeof ad.firePerf === 'number' &&
              typeof au.firePerf === 'number' && ad.firePerf > au.firePerf) ? 'buyDown' : 'buyUp';
    }
    if (upF) return 'buyUp';
    if (dnF) return 'buyDown';
    return null;
  }

  function pushFeed(kind, label) {
    score.feed.unshift({ t: new Date().toISOString(), kind: kind, label: label });
    if (score.feed.length > FEED_KEEP) score.feed.length = FEED_KEEP;
  }

  var RED_KINDS = { 'takeprofit': 1, 'missed-exit': 1, 'greed': 1, 'exit': 1 };
  var GOOD_KINDS = { 'point': 1, 'win': 1 };

  function fmtClock(iso) {
    try {
      var d = new Date(iso);
      function p2(n) { return (n < 10 ? '0' : '') + n; }
      return p2(d.getHours()) + ':' + p2(d.getMinutes()) + ':' + p2(d.getSeconds());
    } catch (e) { return ''; }
  }

  function renderScore() {
    if (scoreEl) {
      var misses = score.slow + score.noPress;
      scoreEl.textContent =
        'SCORE ' + score.points + ' pts · misses ' + misses +
        ' (slow ' + score.slow + ' · no-press ' + score.noPress + ')' +
        ' · exits missed ' + score.missedExits +
        ' · ⚑ greed ' + score.greed + ' · ⚑ gambling ' + score.gambling +
        ' · wins ' + score.wins;
    }
    if (feedEl) {
      feedEl.innerHTML = '';
      if (!score.feed.length) {
        feedEl.textContent = 'flags feed — quiet so far';
        return;
      }
      var items = score.feed.slice(0, FEED_SHOW);
      for (var i = 0; i < items.length; i++) {
        var div = document.createElement('div');
        if (RED_KINDS[items[i].kind]) div.className = 'fl-red';
        else if (GOOD_KINDS[items[i].kind]) div.className = 'fl-good';
        div.textContent = fmtClock(items[i].t) + ' ' + items[i].label;
        feedEl.appendChild(div);
      }
    }
  }

  /* A fire ignites (LOCKED play only scores): if it is the SELL
   * light and a point is open, this fire IS the take-profit moment. */
  function onFireStart(id) {
    var f = { fireWall: Date.now(), scored: null, takeProfit: false, sidePct: null };
    activeFire[id] = f;
    if (!state.locked) return;
    if (id === 'sell' && score.openEntry) {
      f.takeProfit = true;
      f.sidePct = sampleSidePct(score.openEntry.side);
      pushFeed('takeprofit',
        'TAKE PROFIT — SELL is flashing on your ' + score.openEntry.side.toUpperCase() +
        ' point · the good exit is up (DEMO law)');
      saveScore();
      renderScore();
    }
  }

  /* A fire goes out: untapped, it is a miss — a missed exit when it
   * was the take-profit fire, a plain no-press otherwise. BUY is
   * the exception (v0.1.5): its fire is the echo of a side's fire,
   * and the side's fire carries the verdict — BUY clearing untapped
   * is never a second NO-PRESS for the same moment. (A BUY tap,
   * when it comes, marks the side's fire scored — see scoreTap.) */
  function onFireEnd(id) {
    var f = activeFire[id];
    delete activeFire[id];
    if (id === 'buy') return;
    if (!state.locked || !f || f.scored) return;
    if (id === 'sell' && f.takeProfit) {
      score.missedExits++;
      pushFeed('missed-exit',
        (typeof f.sidePct === 'number' && f.sidePct <= 45)
          ? 'MISSED EXIT — good profit was there (DEMO: your side ' + f.sidePct + '% at the flash) and the SELL light went out untapped'
          : 'MISSED EXIT — the SELL light came and went untapped');
    } else {
      score.noPress++;
      pushFeed('no-press', 'MISS · NO-PRESS — ' + labelOf(id) + ' flashed and nobody pressed');
    }
    saveScore();
    renderScore();
  }

  /* The window rolled: settle the open point against the closing
   * window's final reading. A tie (or missing numbers) is NOT a
   * readable settle — score nothing, never invent a win. */
  function settleWindow(prev) {
    if (!state.locked) return;
    var e = score.openEntry;
    if (!e) return;
    if (e.window && prev.window && e.window !== prev.window) {
      score.openEntry = null; // a leftover from an older window: just close it
      saveScore();
      return;
    }
    var settled = null;
    if (typeof prev.upPct === 'number' && typeof prev.downPct === 'number') {
      if (prev.upPct > prev.downPct) settled = 'up';
      else if (prev.downPct > prev.upPct) settled = 'down';
    }
    if (settled && e.side === settled) {
      score.wins++;
      pushFeed('win', 'WIN 🏆 — your ' + e.side.toUpperCase() + ' point settled ' +
        settled.toUpperCase() + ' at the window roll');
    }
    score.openEntry = null;
    saveScore();
    renderScore();
  }

  /* Judge one journal record. Called from the passive journal with
   * the record and the button whose fire the tap was judged
   * against (null for NO-LIGHT). One score per fire: the first
   * correct tap settles the fire; later taps still journal. */
  function scoreTap(rec, jbId) {
    if (!state.locked) return; // the journal is locked-only anyway; belt & braces
    if (rec.result === 'NO-LIGHT') {
      score.gambling++;
      pushFeed('gambling', '⚑ GAMBLING — tapped' +
        (rec.targetText ? ' "' + rec.targetText + '"' : '') + ' with no light up');
      saveScore();
      renderScore();
      return;
    }
    if (!jbId || typeof rec.flashToTapMs !== 'number') return;
    var f = activeFire[jbId];
    if (rec.result === 'WRONG-CONTROL') {
      if (jbId === 'sell' || jbId === 'reversal') {
        score.greed++;
        pushFeed('greed', jbId === 'sell'
          ? '⚑ GREED — tapped a buy while SELL was flashing'
          : '⚑ GREED — wrong control during the REVERSAL fire');
        saveScore();
        renderScore();
      }
      return;
    }
    if (rec.result !== 'CORRECT') return;
    if (f && f.scored) return; // this fire already has its verdict
    var secs = fmtSec(rec.flashToTapMs);
    if (jbId === 'buy') {
      /* v0.1.5: a tap through BUY onto the page's submit IS the
       * entry tap for whichever side is firing — the confirm press
       * is the press that counts. It settles BOTH fires (BUY's own
       * and the side's), so neither can later clear as a NO-PRESS,
       * and a side already settled by its own tap settles BUY too:
       * one fire, one verdict, whichever control he pressed. */
      var hot = flashingSideId();
      if (!hot) return;
      var sideFire = activeFire[hot];
      if (sideFire && sideFire.scored) { if (f) f.scored = sideFire.scored; return; }
      var hotSide = (hot === 'buyUp') ? 'up' : 'down';
      if (rec.flashToTapMs <= POINT_MAX_MS) {
        if (f) f.scored = 'point';
        if (sideFire) sideFire.scored = 'point';
        score.points++;
        pushFeed('point', 'POINT ✓ BUY — the ' + hotSide.toUpperCase() +
          ' pick confirmed in ' + secs);
        score.openEntry = { side: hotSide, entryPct: sampleSidePct(hotSide), window: rec.window || null };
      } else {
        if (f) f.scored = 'slow';
        if (sideFire) sideFire.scored = 'slow';
        score.slow++;
        pushFeed('slow', 'MISS · SLOW — human lag · BUY (the ' + hotSide.toUpperCase() +
          ' pick) tapped ' + secs + ' after the flash (over 2s — no point)');
      }
      saveScore();
      renderScore();
      return;
    }
    if (jbId === 'sell') {
      if (f) f.scored = 'taken';
      if (rec.flashToTapMs > POINT_MAX_MS) {
        score.slow++;
        pushFeed('slow', 'MISS · SLOW — human lag · SELL pressed ' + secs + ' after the flash');
      } else {
        pushFeed('exit', 'EXIT TAKEN — SELL pressed in ' + secs);
      }
      score.openEntry = null;
      saveScore();
      renderScore();
      return;
    }
    if (rec.flashToTapMs <= POINT_MAX_MS) {
      if (f) f.scored = 'point';
      score.points++;
      pushFeed('point', 'POINT ✓ ' + labelOf(jbId) + ' — taken in ' + secs);
      if (jbId === 'buyUp') {
        score.openEntry = { side: 'up', entryPct: sampleSidePct('up'), window: rec.window || null };
      } else if (jbId === 'buyDown') {
        score.openEntry = { side: 'down', entryPct: sampleSidePct('down'), window: rec.window || null };
      } else if (jbId === 'reversal' && score.openEntry) {
        var ns = (score.openEntry.side === 'up') ? 'down' : 'up';
        score.openEntry = { side: ns, entryPct: sampleSidePct(ns), window: rec.window || null };
      }
    } else {
      if (f) f.scored = 'slow';
      score.slow++;
      pushFeed('slow', 'MISS · SLOW — human lag · ' + labelOf(jbId) +
        ' tapped ' + secs + ' after the flash (over 2s — no point)');
    }
    saveScore();
    renderScore();
  }

  /* ---------------- reaction journal (v0.1.2, passive) ----------------
   * One stream drives every layer: the watcher writes samples, the
   * Board polls them every POLL_MS and lights up. The journal closes
   * the loop — when David taps THROUGH a locked (pure-light) button,
   * did the tap land on the real control the light meant, and how
   * fast? It is a LISTENER ONLY: a capture-phase, passive document
   * click listener, active in LOCKED mode, that reads the event and
   * writes a record. It never prevents, stops, or redirects a tap;
   * the page's own click handlers always run exactly as they would
   * without the Board. Records live on-device in localStorage
   * (TAPS_KEY, capped at TAPS_CAP); the toolbar stats line is the
   * fun-data readout — last reaction, best reaction, hits. */

  var sessionTaps = [];  // this page session's journal records
  var storedTaps = [];   // the persisted journal (TAPS_KEY)

  function loadTaps() {
    try {
      var raw = window.localStorage.getItem(TAPS_KEY);
      var a = raw ? JSON.parse(raw) : null;
      if (a && Object.prototype.toString.call(a) === '[object Array]') {
        storedTaps = a.slice(-TAPS_CAP);
      }
    } catch (e) {}
  }

  function saveTaps() {
    try { window.localStorage.setItem(TAPS_KEY, JSON.stringify(storedTaps)); } catch (e) {}
  }

  function sideOf(id) {
    for (var i = 0; i < BUTTON_DEFS.length; i++) {
      if (BUTTON_DEFS[i].id === id) return BUTTON_DEFS[i].side || BUTTON_DEFS[i].id;
    }
    return id;
  }

  /* Does the tapped control's visible text name the control this
   * light meant? BUY UP means the page's Up outcome control, SELL
   * means a sell control, REVERSAL means the opposite side's control
   * (the page then asks "Do you agree to reverse?"), and BUY (v0.1.5)
   * means the page's submit control, whose text opens with "Buy". */
  function textMatches(id, text) {
    if (!text) return false;
    if (id === 'buyUp') return /^up/i.test(text);
    if (id === 'buyDown') return /^down/i.test(text);
    if (id === 'buy') return /^buy/i.test(text);
    if (id === 'sell') return /sell/i.test(text);
    if (id === 'reversal') {
      if (state.position) return state.position.side === 'up' ? /^down/i.test(text) : /^up/i.test(text);
      return /^up/i.test(text) || /^down/i.test(text);
    }
    return false;
  }

  function fmtSec(ms) { return (ms / 1000).toFixed(2) + 's'; }

  function updateStats() {
    if (!statsEl) return;
    if (!sessionTaps.length) {
      statsEl.textContent = '⚡ reaction journal — no taps yet this session';
      return;
    }
    var correct = 0, best = null, lastTimed = null, lastReady = null;
    for (var i = 0; i < sessionTaps.length; i++) {
      var r = sessionTaps[i];
      if (r.result === 'CORRECT') {
        correct++;
        if (typeof r.flashToTapMs === 'number' && (best === null || r.flashToTapMs < best)) best = r.flashToTapMs;
      }
      if (typeof r.flashToTapMs === 'number') lastTimed = r;
      // v0.1.4: the human-prep measure — ARM→tap on the latest
      // tap whose fire had a real ARM stage in front of it.
      if (typeof r.readyMs === 'number') lastReady = r.readyMs;
    }
    statsEl.textContent =
      '⚡ last ' + (lastTimed ? fmtSec(lastTimed.flashToTapMs) + (lastTimed.result === 'CORRECT' ? ' ✓' : ' ✗') : '—') +
      ' · best ' + (best !== null ? fmtSec(best) : '—') +
      ' · hits ' + correct + '/' + sessionTaps.length +
      (lastReady !== null ? ' · ready ' + fmtSec(lastReady) : '');
  }

  function onDocClick(ev) {
    if (!state.locked) return; // the journal only watches live (locked) play
    try {
      if (root && ev.target && root.contains(ev.target)) return; // our own toolbar
      var x = ev.clientX, y = ev.clientY, now = performance.now();
      var id, r;

      // (a) which Board button's rect contains the tap point, if any
      var hitId = null;
      for (id in btnEls) {
        if (!btnEls.hasOwnProperty(id)) continue;
        r = btnEls[id].box.getBoundingClientRect();
        if (x >= r.left && x <= r.right && y >= r.top && y <= r.bottom) { hitId = id; break; }
      }

      // The light that "meant" something: a button flashing right now —
      // the one tapped through if that is it, else the freshest flash.
      // v0.1.5: BUY's fire is an echo of a side's fire, lit in the
      // same pass a hair later — a stray tap must still be judged
      // against the light that MEANT the moment, so the fallback
      // prefers any non-BUY flash and only falls back to BUY when
      // nothing else is lit. A tap ON the BUY button itself is
      // judged against BUY by the hit rule above, as it should be.
      var jbId = null;
      if (hitId && btnEls[hitId].box.getAttribute('data-bb-state') === 'flash') {
        jbId = hitId;
      } else {
        for (var pass = 0; pass < 2 && !jbId; pass++) {
          for (id in btnEls) {
            if (!btnEls.hasOwnProperty(id)) continue;
            if (pass === 0 && id === 'buy') continue;
            if (btnEls[id].box.getAttribute('data-bb-state') === 'flash' && stageInfo[id] &&
                typeof stageInfo[id].firePerf === 'number' &&
                (!jbId || stageInfo[id].firePerf > stageInfo[jbId].firePerf)) jbId = id;
          }
        }
      }

      // (b) the actual tap target's identity: visible text + rect
      var targetText = '';
      var tRect = null;
      if (ev.target) {
        if (ev.target.textContent) {
          targetText = String(ev.target.textContent).replace(/\s+/g, ' ').trim().slice(0, 40);
        }
        if (ev.target.getBoundingClientRect) tRect = ev.target.getBoundingClientRect();
      }

      var rec;
      if (jbId && stageInfo[jbId] && typeof stageInfo[jbId].firePerf === 'number') {
        var jr = btnEls[jbId].box.getBoundingClientRect();
        var near = (x >= jr.left && x <= jr.right && y >= jr.top && y <= jr.bottom) ||
          (tRect && tRect.left <= jr.right && tRect.right >= jr.left &&
           tRect.top <= jr.bottom && tRect.bottom >= jr.top);
        var si = stageInfo[jbId];
        rec = {
          t: new Date().toISOString(),
          window: si.window || (lastSample && lastSample.window) || null,
          side: sideOf(jbId),
          flashToTapMs: Math.round(now - si.firePerf),
          // v0.1.4: the two-stage timestamps — when this fire's ARM
          // began and when the FIRE began (equal if it lit direct).
          armAt: si.armWall,
          fireAt: si.fireWall,
          // v0.1.4: ARM→tap, the human-prep measure — only when a
          // real ARM stage preceded the FIRE.
          readyMs: (typeof si.armPerf === 'number' && si.armPerf < si.firePerf)
            ? Math.round(now - si.armPerf) : null,
          result: (near && textMatches(jbId, targetText)) ? 'CORRECT' : 'WRONG-CONTROL',
          targetText: targetText
        };
      } else {
        rec = {
          t: new Date().toISOString(),
          window: (lastSample && lastSample.window) || null,
          side: hitId ? sideOf(hitId) : null,
          flashToTapMs: null,
          result: 'NO-LIGHT',
          targetText: targetText
        };
      }

      storedTaps.push(rec);
      if (storedTaps.length > TAPS_CAP) storedTaps.splice(0, storedTaps.length - TAPS_CAP);
      saveTaps();
      sessionTaps.push(rec);
      updateStats();
      scoreTap(rec, jbId); // v0.1.4: the Scorekeeper judges the same record
    } catch (e) {}
  }

  /* ---------------- go ---------------- */

  function start() {
    loadState();
    loadTaps();
    loadScore();
    buildBoard();
    document.addEventListener('click', onDocClick, { capture: true, passive: true });
    evaluate(currentSample());
    setInterval(function () { evaluate(currentSample()); }, POLL_MS);
  }

  // Read-only snapshot for the test harness (and for David's own
  // inspection in the console): exposes state, changes nothing.
  try {
    window.BlobBoardState = function () {
      return JSON.parse(JSON.stringify({
        locked: state.locked, layout: state.layout, bar: state.bar,
        opacity: state.opacity, position: state.position,
        lastSample: lastSample, taps: sessionTaps, score: score
      }));
    };
  } catch (e) {}

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', start);
  } else {
    start();
  }
})();

