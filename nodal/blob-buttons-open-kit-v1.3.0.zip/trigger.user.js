// ==UserScript==
// @name         Blob Buttons — The Trigger (Pack #4, PRACTICE DECK + DOUBLE-PRESS EXECUTION)
// @namespace    blob-buttons/koda-kai
// @version      0.2.1
// @description  The Trigger, v0.2.1 "Free Panel+": a free-moving, minimizable, resizable panel for the Polymarket US BTC Up/Down 5-minute page. It boots in PRACTICE mode — David sets BUY and SELL price marks, the panel watches the shared watcher stream, and when the live price crosses a mark it coaches his press sequence (step cards light in order, a blobbtn:sequence event goes out for the Lens) and times his tap from the Board's reaction journal. Practice never presses anything. Behind the PRACTICE/EXECUTE switch sits the original v0.1.0 execution trigger, untouched: stake in cents (hard cap 75 in code), double-press FIRE UP / FIRE DOWN, DRY by default and on every boot, LIVE behind its own double-press. Pack #4 of the Blob Button Field (blob-button-pack/0, id: trigger).
// @author       Koda Kai Network (David's house build)
// @match        *://polymarket.us/event/btc-updown-5m-*
// @run-at       document-idle
// @grant        none
// ==/UserScript==

(function () {
  'use strict';

  /* ------------------------------------------------------------------
   * Blob Buttons Pack #4 — THE TRIGGER, v0.2.1 "FREE PANEL+"
   *
   * One panel, two decks, and a hard wall between them:
   *
   * PRACTICE (the headline; every page load boots here). David sets a
   * BUY MARK and a SELL MARK — price levels, prefilled from the
   * watcher's current beat ± $25 until he edits them. The panel polls
   * the shared watcher stream (localStorage "blobbtn.poly5m.v1",
   * READ-ONLY here) every 250 ms. When the live price crosses a mark,
   * the press-sequence coach runs: three step cards light IN ORDER
   * (1 READ THE LIGHT → 2 PRESS BUY UP / BUY DOWN, or PRESS SELL →
   * 3 SET YOUR SELL / WATCH THE SETTLE), a "blobbtn:sequence"
   * CustomEvent goes out on window for the Lens to draw from, and the
   * panel then watches the Board's reaction journal (localStorage
   * "blobbtn.board.taps.v1", READ-ONLY here) for David's tap and
   * shows his reaction ("⚡ 0.84s — sharp"). PRACTICE NEVER PRESSES
   * ANYTHING: the whole practice code path lives between the
   * PRACTICE SECTION markers below and references no ticket or press
   * helper — the test harness greps that section to prove it.
   *
   * EXECUTE (behind the PRACTICE/EXECUTE switch). The original
   * v0.1.0 trigger, its code path intact:
   *   1. David sets a stake in CENTS in the panel. Hard cap 75 in
   *      code (his standing micro-test caps: $0.10 preferred / $0.25
   *      standard / $0.75 ceiling per position). Anything above 75
   *      is clamped and the panel says so.
   *   2. FIRST press of FIRE UP / FIRE DOWN only ARMS, for 3 seconds.
   *      The button's word becomes exactly what will happen:
   *      "TAP AGAIN — $0.10 UP". A second press inside the window
   *      FIRES. The window lapsing disarms silently. A press on the
   *      other fire button, on the stake box, or anywhere on the
   *      page cancels the arm — a side can never be switched mid-arm.
   *   3. The fire sequence discovers every page control by VISIBLE
   *      TEXT at runtime and demands EXACTLY ONE visible, enabled
   *      match at each step. Zero or two-plus matches = ABORT, with
   *      the reason on the panel, and nothing further is pressed.
   *   4. DRY mode (the default, and the mode every page load starts
   *      in) runs the whole sequence EXCEPT the final Place press,
   *      then reports "DRY — filled, did not place". LIVE mode
   *      completes it. Switching to LIVE itself takes a double-press;
   *      switching back to DRY is one press.
   * Switching decks never inherits an armed state: any arm dies and
   * the execute deck resets to DRY on every switch.
   *
   * The panel free-moves: drag it by its header, resize it by the
   * corner grip (bottom-right); position, size, and the minimized
   * state persist on-device (localStorage
   * "blobbtn.trigger.layout.v1"). The size fields are additive —
   * stores written before v0.2.1 carry no size and load at the
   * default size. The MINIMIZE button collapses it to a slim bar
   * ("🎯 PRACTICE ▸"); press the bar to restore it. Resizing
   * applies to the open panel only — the bar stays slim.
   *
   * This script makes NO network calls of any kind. The execute
   * deck's presses are limited to the discovered page controls inside
   * the fire sequence; every press and synthetic event it delivers is
   * written to the on-panel log and to localStorage
   * "blobbtn.trigger.log.v1". The two cross-pack streams (watcher,
   * Board journal) are read-only here — this file never writes them.
   *
   * David is deaf: the visual signal IS the interface. The armed
   * button carries the exact action in words; the coach's steps are
   * numbered words; an abort is a big red line with the reason —
   * never colour alone.
   * ------------------------------------------------------------------ */

  var SETTINGS_KEY = 'blobbtn.trigger.v1';   // {cents}
  var LOG_KEY = 'blobbtn.trigger.log.v1';    // [{t, m}]
  var LAYOUT_KEY = 'blobbtn.trigger.layout.v1'; // {x, y, minimized, w, h}
  var ROOT_ID = 'blobbtn-trigger';
  var DEFAULT_CENTS = 10;
  var HARD_CAP_CENTS = 75;                   // David's $0.75 hard cap, in code
  var ARM_MS = 3000;                         // double-press window
  var INPUT_WAIT_MS = 2000;                  // ticket amount-field wait
  var INPUT_POLL_MS = 100;
  var MAX_LOG = 200;                         // stored log entries
  var PANEL_LOG_LINES = 20;                  // lines shown on the panel
  var MIN_PANEL_W = 240;                     // resize floor, CSS px (content box)
  var MIN_PANEL_H = 140;                     // resize floor, CSS px (content box)

  /* ---------------- state ---------------- */

  var state = {
    cents: DEFAULT_CENTS,
    mode: 'DRY', // EXECUTE deck: always boots DRY, whatever happened last session
    panelMode: 'practice' // the panel itself always boots on the PRACTICE deck
  };
  var arm = null;     // {side, cents, expires, timer}
  var liveArm = null; // {expires, timer}
  var firing = false;
  var logArr = [];
  var layout = { x: null, y: null, minimized: false, w: null, h: null };

  function loadSettings() {
    try {
      var raw = window.localStorage.getItem(SETTINGS_KEY);
      if (!raw) return;
      var s = JSON.parse(raw);
      if (s && isFinite(s.cents)) state.cents = clampCents(s.cents).cents;
    } catch (e) {}
  }

  function saveSettings() {
    try {
      window.localStorage.setItem(SETTINGS_KEY, JSON.stringify({ cents: state.cents }));
    } catch (e) {}
  }

  function loadLog() {
    try {
      var raw = window.localStorage.getItem(LOG_KEY);
      if (raw) {
        var arr = JSON.parse(raw);
        if (Object.prototype.toString.call(arr) === '[object Array]') logArr = arr;
      }
    } catch (e) {}
  }

  function saveLog() {
    try {
      window.localStorage.setItem(LOG_KEY, JSON.stringify(logArr.slice(-MAX_LOG)));
    } catch (e) {}
  }

  function loadLayout() {
    try {
      var raw = window.localStorage.getItem(LAYOUT_KEY);
      if (!raw) return;
      var s = JSON.parse(raw);
      if (!s || typeof s !== 'object') return;
      if (isFinite(s.x) && isFinite(s.y)) { layout.x = Number(s.x); layout.y = Number(s.y); }
      if (typeof s.minimized === 'boolean') layout.minimized = s.minimized;
      // v0.2.1 additive size fields. Strict number checks: a stored
      // null must stay "no saved size", never collapse to 0.
      if (typeof s.w === 'number' && isFinite(s.w)) {
        layout.w = Math.max(MIN_PANEL_W, Math.round(s.w));
      }
      if (typeof s.h === 'number' && isFinite(s.h)) {
        layout.h = Math.max(MIN_PANEL_H, Math.round(s.h));
      }
    } catch (e) {}
  }

  function saveLayout() {
    try {
      window.localStorage.setItem(LAYOUT_KEY, JSON.stringify(layout));
    } catch (e) {}
  }

  /* ---------------- money ---------------- */

  // Returns {cents, clamped} — cents is always an integer in [1, 75],
  // or null when the raw value is not a usable number at all.
  function clampCents(raw) {
    var n = Math.round(Number(raw));
    if (!isFinite(n)) return { cents: null, clamped: false };
    if (n > HARD_CAP_CENTS) return { cents: HARD_CAP_CENTS, clamped: true };
    if (n < 1) return { cents: null, clamped: false };
    return { cents: n, clamped: false };
  }

  function fmtMoney(cents) {
    return '$' + (cents / 100).toFixed(2);
  }

  /* ---------------- the log ---------------- */

  var logEl = null, statusEl = null;

  function stamp() {
    var d = new Date();
    function p(x) { return (x < 10 ? '0' : '') + x; }
    return p(d.getHours()) + ':' + p(d.getMinutes()) + ':' + p(d.getSeconds());
  }

  function logStep(msg) {
    logArr.push({ t: new Date().toISOString(), m: msg });
    if (logArr.length > MAX_LOG) logArr = logArr.slice(-MAX_LOG);
    saveLog();
    renderLog();
    try { console.log('[blobbtn-trigger] ' + msg); } catch (e) {}
  }

  function renderLog() {
    if (!logEl) return;
    var lines = logArr.slice(-PANEL_LOG_LINES);
    logEl.innerHTML = '';
    for (var i = 0; i < lines.length; i++) {
      var div = document.createElement('div');
      div.className = 'bt-line';
      var hm = String(lines[i].t || '').match(/T(\d{2}:\d{2}:\d{2})/);
      div.textContent = (hm ? hm[1] : stamp()) + '  ' + lines[i].m;
      logEl.appendChild(div);
    }
    logEl.scrollTop = logEl.scrollHeight;
  }

  function setStatus(msg, kind) {
    if (!statusEl) return;
    statusEl.textContent = msg;
    statusEl.className = 'bt-status' + (kind ? ' bt-' + kind : '');
    statusEl.setAttribute('data-bt-status-kind', kind || 'info');
  }

  /* ---------------- page discovery (visible text, the watcher's way) ----
   * EXECUTE deck only. Strict at every step: exactly one visible,
   * enabled match, or the caller aborts with the reason. Nothing
   * inside our own panel is ever a candidate. */

  function normText(el) {
    try {
      return String(el.textContent || '').replace(/\s+/g, ' ').trim();
    } catch (e) { return ''; }
  }

  function isOurs(el) {
    var n = el;
    while (n) {
      if (n.id === ROOT_ID) return true;
      n = n.parentElement || n.parentNode || null;
    }
    return false;
  }

  function isVisible(el) {
    try {
      var r = el.getBoundingClientRect();
      if (!r || r.width === 0 || r.height === 0) return false;
      var cs = window.getComputedStyle(el);
      return cs && cs.display !== 'none' && cs.visibility !== 'hidden';
    } catch (e) { return false; }
  }

  function isEnabled(el) {
    try {
      if (el.disabled) return false;
      if (el.getAttribute && el.getAttribute('aria-disabled') === 'true') return false;
      return true;
    } catch (e) { return false; }
  }

  function clickables() {
    var out = [];
    try {
      var nodes = document.querySelectorAll(
        'button, a, [role="button"], input[type="button"], input[type="submit"]');
      for (var i = 0; i < nodes.length; i++) {
        var el = nodes[i];
        if (!isOurs(el) && isVisible(el) && isEnabled(el)) out.push(el);
      }
    } catch (e) {}
    return out;
  }

  // The side's buy control: a short clickable whose visible text starts
  // with the side word ("Up 58%", "Down", ...). UNVERIFIED against the
  // live page's real wording — see README.
  function findSideButton(side) {
    var word = (side === 'up') ? 'Up' : 'Down';
    var re = new RegExp('^' + word + '(\\s|$)');
    var hits = [];
    var cands = clickables();
    for (var i = 0; i < cands.length; i++) {
      var t = normText(cands[i]);
      if (t && t.length <= 40 && re.test(t)) hits.push({ el: cands[i], text: t });
    }
    if (hits.length === 1) return { ok: true, el: hits[0].el, text: hits[0].text };
    if (hits.length === 0) return { ok: false, reason: 'no visible ' + word + ' buy control found on the page' };
    return { ok: false, reason: 'ambiguous: ' + hits.length + ' visible ' + word + ' buy controls — refusing to guess' };
  }

  // The ticket's amount field: a visible text/number input that is not
  // ours. With several candidates, only an amount-ish label
  // (placeholder / aria-label / name) may break the tie.
  function amountCandidates() {
    var out = [];
    try {
      var nodes = document.querySelectorAll('input');
      for (var i = 0; i < nodes.length; i++) {
        var el = nodes[i];
        var type = String(el.getAttribute('type') || 'text').toLowerCase();
        var im = String(el.getAttribute('inputmode') || '').toLowerCase();
        if (type !== 'text' && type !== 'number' && im !== 'decimal' && im !== 'numeric') continue;
        if (!isOurs(el) && isVisible(el) && isEnabled(el)) out.push(el);
      }
    } catch (e) {}
    return out;
  }

  function findAmountInput() {
    var cands = amountCandidates();
    if (cands.length === 1) return { ok: true, el: cands[0] };
    if (cands.length === 0) return { ok: false, reason: 'amount input not found' };
    var labelled = [];
    for (var i = 0; i < cands.length; i++) {
      var hint = (cands[i].getAttribute('placeholder') || '') + ' ' +
                 (cands[i].getAttribute('aria-label') || '') + ' ' +
                 (cands[i].getAttribute('name') || '');
      if (/amount|usd|stake|\$/i.test(hint)) labelled.push(cands[i]);
    }
    if (labelled.length === 1) return { ok: true, el: labelled[0] };
    return { ok: false, reason: 'ambiguous: ' + cands.length + ' amount inputs — refusing to guess' };
  }

  // The ticket's Place/Buy confirm control (LIVE only). The side
  // control already pressed is excluded, so "Buy Up" as an outcome
  // button can never be mistaken for the ticket's confirm.
  function findConfirmButton(excludeEl) {
    var hits = [];
    var cands = clickables();
    for (var i = 0; i < cands.length; i++) {
      if (cands[i] === excludeEl) continue;
      var t = normText(cands[i]);
      if (t && t.length <= 40 && /(place|buy)/i.test(t)) hits.push({ el: cands[i], text: t });
    }
    if (hits.length === 1) return { ok: true, el: hits[0].el, text: hits[0].text };
    if (hits.length === 0) return { ok: false, reason: 'no Place/Buy confirm control found in the ticket' };
    return { ok: false, reason: 'ambiguous: ' + hits.length + ' Place/Buy controls — refusing to guess' };
  }

  // Sanctioned pages: the real 5M event URL, or the house mock page
  // (practice-exec.html carries the marker). Anything else: no fire.
  function pageOk() {
    try {
      var u = String(window.location.href || '');
      if (/polymarket\.us\/event\/btc-updown-5m-/i.test(u)) return true;
      if (document.getElementById('bb-mock-5m')) return true;
    } catch (e) {}
    return false;
  }

  /* ---------------- arming (the double-press protocol) ---------------- */

  var fireUpBtn = null, fireDownBtn = null, modeBtn = null,
      modeLine = null, centsInput = null, capNote = null;

  function fireBtn(side) { return side === 'up' ? fireUpBtn : fireDownBtn; }

  function restoreFireLabels() {
    if (fireUpBtn) fireUpBtn.textContent = 'FIRE UP';
    if (fireDownBtn) fireDownBtn.textContent = 'FIRE DOWN';
    if (fireUpBtn) fireUpBtn.classList.remove('bt-armed');
    if (fireDownBtn) fireDownBtn.classList.remove('bt-armed');
  }

  function disarm(why) {
    if (!arm) return;
    try { clearTimeout(arm.timer); } catch (e) {}
    var side = arm.side;
    arm = null;
    restoreFireLabels();
    logStep('disarmed (' + (why || 'cancelled') + ') — ' + side.toUpperCase() + ' will not fire');
  }

  function clearLiveArm() {
    if (!liveArm) return;
    try { clearTimeout(liveArm.timer); } catch (e) {}
    liveArm = null;
    if (modeBtn) modeBtn.textContent = 'GO LIVE';
    if (modeBtn) modeBtn.classList.remove('bt-armed');
  }

  // Read + sanitize the stake box into state. Returns the cents or null.
  function readStake() {
    if (!centsInput) return state.cents;
    var r = clampCents(centsInput.value);
    if (r.cents === null) {
      if (capNote) capNote.textContent = '⚠ stake must be 1–' + HARD_CAP_CENTS + '¢';
      return null;
    }
    state.cents = r.cents;
    if (r.clamped) {
      centsInput.value = String(HARD_CAP_CENTS);
      if (capNote) capNote.textContent = '⚠ capped at ' + HARD_CAP_CENTS + '¢ — the hard cap, enforced in code';
    } else if (capNote) {
      capNote.textContent = 'cap ' + HARD_CAP_CENTS + '¢ · $0.10 pref / $0.25 std';
    }
    saveSettings();
    return state.cents;
  }

  function pressFire(side) {
    if (firing) return;
    if (arm && arm.side !== side) {
      // A press on the other button resets — never a mid-arm switch.
      disarm('pressed the other button');
      return;
    }
    if (arm && arm.side === side && Date.now() < arm.expires) {
      var cents = arm.cents;
      try { clearTimeout(arm.timer); } catch (e) {}
      arm = null;
      restoreFireLabels();
      fire(side, cents);
      return;
    }
    // First press: arm only.
    var stake = readStake();
    if (stake === null) {
      setStatus('⛔ ABORTED — stake not set: enter 1–' + HARD_CAP_CENTS + '¢ first', 'abort');
      logStep('ABORTED — stake not set (fire press ignored)');
      return;
    }
    clearLiveArm();
    arm = {
      side: side, cents: stake, expires: Date.now() + ARM_MS,
      timer: setTimeout(function () {
        if (arm && arm.side === side) {
          arm = null;
          restoreFireLabels();
          logStep('arm window lapsed — disarmed silently');
        }
      }, ARM_MS)
    };
    var btn = fireBtn(side);
    btn.textContent = 'TAP AGAIN — ' + fmtMoney(stake) + ' ' + side.toUpperCase();
    btn.classList.add('bt-armed');
    setStatus('ARMED — tap again within 3s: ' + fmtMoney(stake) + ' ' + side.toUpperCase() +
              ' (' + state.mode + ')', 'arm');
    logStep('ARMED ' + side.toUpperCase() + ' ' + fmtMoney(stake) + ' — tap again within 3s to fire (' + state.mode + ')');
  }

  function pressMode() {
    if (firing) return;
    disarm('mode toggle pressed');
    if (state.mode === 'LIVE') {
      state.mode = 'DRY';
      clearLiveArm();
      logStep('mode → DRY (one press back to safe, by design)');
      renderMode();
      return;
    }
    if (liveArm && Date.now() < liveArm.expires) {
      state.mode = 'LIVE';
      clearLiveArm();
      logStep('mode → LIVE — the next confirmed double-press PLACES a real order');
      setStatus('🔴 LIVE MODE — double-press FIRE places for real', 'live');
      renderMode();
      return;
    }
    liveArm = {
      expires: Date.now() + ARM_MS,
      timer: setTimeout(function () {
        if (liveArm) { liveArm = null; if (modeBtn) { modeBtn.textContent = 'GO LIVE'; modeBtn.classList.remove('bt-armed'); } }
      }, ARM_MS)
    };
    modeBtn.textContent = 'TAP AGAIN — GO LIVE';
    modeBtn.classList.add('bt-armed');
    logStep('arming LIVE mode — tap GO LIVE again within 3s');
  }

  /* ---------------- the fire sequence (EXECUTE deck) ---------------- */

  function abort(reason) {
    firing = false;
    disarm('abort');
    setStatus('⛔ ABORTED — ' + reason, 'abort');
    logStep('ABORTED — ' + reason + ' — nothing further pressed');
  }

  function waitForInput(deadline) {
    return new Promise(function (resolve) {
      (function poll() {
        var found = findAmountInput();
        if (found.ok) { resolve(found); return; }
        if (Date.now() >= deadline) { resolve(found); return; }
        setTimeout(poll, INPUT_POLL_MS);
      })();
    });
  }

  // Set the amount with the native setter (framework-safe) and log
  // every synthetic event delivered — this pack is allowed to deliver
  // events, and the log is where that permission is accounted for.
  function setAmount(input, cents) {
    var str = (cents / 100).toFixed(2);
    try { input.focus(); logStep('focused the amount input'); } catch (e) {}
    var setter = null;
    try {
      var desc = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value');
      if (desc && desc.set) setter = desc.set;
    } catch (e) {}
    if (setter) { setter.call(input, str); logStep('set amount via native value setter: "' + str + '"'); }
    else { input.value = str; logStep('set amount via direct value assignment: "' + str + '"'); }
    input.dispatchEvent(new window.Event('input', { bubbles: true }));
    logStep('delivered synthetic "input" event to the amount field');
    input.dispatchEvent(new window.Event('change', { bubbles: true }));
    logStep('delivered synthetic "change" event to the amount field');
    var held = parseFloat(String(input.value || '').replace(/[^0-9.]/g, ''));
    return { ok: isFinite(held) && Math.abs(held - cents / 100) < 0.001, held: input.value };
  }

  function fire(side, cents) {
    if (firing) return;
    if (!pageOk()) {
      abort('not a BTC Up/Down 5M page (URL/marker check failed) — nothing pressed');
      return;
    }
    firing = true;
    var sideWord = side.toUpperCase();
    setStatus('FIRING ' + fmtMoney(cents) + ' ' + sideWord + ' (' + state.mode + ')…', 'arm');
    logStep('FIRE ' + sideWord + ' ' + fmtMoney(cents) + ' — mode ' + state.mode);

    var sideHit = findSideButton(side);
    if (!sideHit.ok) { abort(sideHit.reason); return; }
    logStep('pressing the ' + sideWord + ' buy control: "' + sideHit.text + '"');
    sideHit.el.click();
    logStep('pressed the ' + sideWord + ' buy control — waiting for the ticket');

    waitForInput(Date.now() + INPUT_WAIT_MS).then(function (found) {
      if (!found.ok) { abort(found.reason + ' (waited ' + (INPUT_WAIT_MS / 1000) + 's after opening the ticket)'); return; }
      logStep('amount input found');
      var set = setAmount(found.el, cents);
      if (!set.ok) { abort('amount did not stick — the field holds "' + set.held + '", expected "' + (cents / 100).toFixed(2) + '"'); return; }
      logStep('amount verified in the field: ' + fmtMoney(cents));

      if (state.mode === 'DRY') {
        firing = false;
        setStatus('DRY — filled ' + fmtMoney(cents) + ' ' + sideWord + ', did not place', 'dry');
        logStep('DRY — filled, did not place (the Place control was NOT pressed)');
        return;
      }
      var conf = findConfirmButton(sideHit.el);
      if (!conf.ok) { abort(conf.reason); return; }
      logStep('pressing the confirm control: "' + conf.text + '"');
      conf.el.click();
      firing = false;
      setStatus('✅ PLACED ' + fmtMoney(cents) + ' ' + sideWord, 'live');
      logStep('PLACED ' + fmtMoney(cents) + ' ' + sideWord + ' — confirm control pressed exactly once');
    });
  }

  /* ---------------- practice deck elements (built by buildPanel) ---- */

  var buyMarkInput = null, sellMarkInput = null,
      streamLineEl = null, reactionEl = null,
      stepCards = []; // [{card, label}] — the coach's three step cards

  /* ===== PRACTICE SECTION BEGIN ===== */
  /* The PRACTICE deck: marks, the watcher-stream watch, the press-
   * sequence coach, and the reaction clock. This section is the
   * whole practice code path, and it is press-free by construction:
   * it never touches a page control, never fills a ticket, and never
   * calls any helper from the execute deck. Its only outward signal
   * is the single sanctioned window event for the Lens, sent by
   * emitSequence below. The test harness greps THIS section to prove
   * all of that. Both streams it reads are read-only here.
   * ===== */

  var WATCH_KEY = 'blobbtn.poly5m.v1';      // Pack #2's sample stream (read-only)
  var TAPS_KEY = 'blobbtn.board.taps.v1';   // Pack #3's reaction journal (read-only)
  var PRACTICE_POLL_MS = 250;               // stream watch cadence
  var STREAM_FRESH_MS = 20000;              // older than this: stale, no coaching
  var PREFILL_OFFSET = 25;                  // marks prefill: beat ± $25
  var STEP_MS = 700;                        // coach cadence between step cards
  var TAP_WAIT_MS = 30000;                  // how long a sequence waits for a tap

  var practice = {
    buyMark: null, sellMark: null,   // price levels (numbers) or null
    touched: false,                  // David edited a mark: stop prefilling
    prevPrice: null,                 // last live price seen (cross baseline)
    markSide: { buy: null, sell: null }, // 'above' | 'below' | null per mark
    seq: null,                       // last sequence detail sent to the Lens
    seqAt: 0,                        // when it fired (ms epoch)
    stepTimers: [],
    awaitTap: null,                  // {sinceMs} while a sequence waits for a tap
    reaction: ''                     // the last reaction line, word for word
  };

  function fmtPrice(v) {
    return (typeof v === 'number' && isFinite(v))
      ? '$' + v.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })
      : '—';
  }

  function fmtSec(ms) {
    return (ms / 1000).toFixed(2);
  }

  // The newest watcher sample, read defensively: any problem at all
  // (no stream, bad JSON, no numbers) reads as "no live price".
  function practiceReadStream() {
    try {
      var raw = window.localStorage.getItem(WATCH_KEY);
      if (!raw) return null;
      var arr = JSON.parse(raw);
      if (!arr || Object.prototype.toString.call(arr) !== '[object Array]' || !arr.length) return null;
      var s = arr[arr.length - 1];
      if (!s || typeof s !== 'object') return null;
      var ageMs = Date.now() - Date.parse(s.ts || '');
      if (isNaN(ageMs)) ageMs = null;
      return {
        price: (typeof s.currentPrice === 'number' && isFinite(s.currentPrice)) ? s.currentPrice : null,
        beat: (typeof s.priceToBeat === 'number' && isFinite(s.priceToBeat)) ? s.priceToBeat : null,
        upPct: (typeof s.upPct === 'number' && isFinite(s.upPct)) ? s.upPct : null,
        ageMs: ageMs,
        fresh: ageMs !== null && ageMs <= STREAM_FRESH_MS
      };
    } catch (e) { return null; }
  }

  // The Board's reaction journal, read defensively. Read-only: this
  // deck never writes it, never clears it, never depends on it
  // existing.
  function practiceReadJournal() {
    try {
      var raw = window.localStorage.getItem(TAPS_KEY);
      if (!raw) return [];
      var arr = JSON.parse(raw);
      if (!arr || Object.prototype.toString.call(arr) !== '[object Array]') return [];
      return arr;
    } catch (e) { return []; }
  }

  // Until David edits a mark himself, the marks track the beat:
  // BUY a little under it, SELL a little over it.
  function practicePrefill(s) {
    if (practice.touched || typeof s.beat !== 'number') return;
    var buy = Math.round((s.beat - PREFILL_OFFSET) * 100) / 100;
    var sell = Math.round((s.beat + PREFILL_OFFSET) * 100) / 100;
    if (practice.buyMark !== buy) {
      practice.buyMark = buy;
      practice.markSide.buy = null; // the mark moved: re-baseline, never fire
      if (buyMarkInput) buyMarkInput.value = buy.toFixed(2);
    }
    if (practice.sellMark !== sell) {
      practice.sellMark = sell;
      practice.markSide.sell = null;
      if (sellMarkInput) sellMarkInput.value = sell.toFixed(2);
    }
  }

  // The one outward signal of this deck: a window event the Lens
  // listens for, carrying the sequence so it can draw the link from
  // the coach to the Board's buttons. Nothing on the page is touched.
  function emitSequence(detail) {
    try {
      window.dispatchEvent(new window.CustomEvent('blobbtn:sequence', { detail: detail }));
    } catch (e) {}
  }

  function practiceSetReaction(text) {
    practice.reaction = text;
    if (reactionEl) reactionEl.textContent = text;
  }

  function practiceLightStep(i) {
    if (stepCards[i]) stepCards[i].card.classList.add('bt-on');
  }

  // Which side the coach calls: the side the live price is winning
  // (price at or over the beat line is UP's game), with the stream's
  // own lean as the fallback when no beat is readable.
  function practiceSideFor(s) {
    if (typeof s.beat === 'number' && typeof s.price === 'number') {
      return s.price >= s.beat ? 'up' : 'down';
    }
    if (typeof s.upPct === 'number') return s.upPct >= 50 ? 'up' : 'down';
    return 'up';
  }

  // A mark was crossed: run the coach. The step cards light IN ORDER
  // at the coach cadence, the sequence goes out to the Lens, and the
  // reaction clock starts watching the Board journal for David's tap.
  function practiceRunSequence(kind, side, price) {
    var steps = (kind === 'buy')
      ? ['READ THE LIGHT', side === 'up' ? 'PRESS BUY UP' : 'PRESS BUY DOWN', 'SET YOUR SELL']
      : ['READ THE LIGHT', 'PRESS SELL', 'WATCH THE SETTLE'];
    var i;
    for (i = 0; i < practice.stepTimers.length; i++) {
      try { clearTimeout(practice.stepTimers[i]); } catch (e) {}
    }
    practice.stepTimers = [];
    practice.seq = { kind: 'practice', mark: kind, side: side, steps: steps, price: price };
    practice.seqAt = Date.now();
    for (i = 0; i < stepCards.length; i++) {
      stepCards[i].label.textContent = steps[i];
      stepCards[i].card.classList.remove('bt-on');
    }
    practiceLightStep(0);
    practice.stepTimers.push(setTimeout(function () { practiceLightStep(1); }, STEP_MS));
    practice.stepTimers.push(setTimeout(function () { practiceLightStep(2); }, STEP_MS * 2));
    emitSequence({ kind: 'practice', mark: kind, side: side, steps: steps.slice(), price: price });
    practice.awaitTap = { sinceMs: practice.seqAt };
    practiceSetReaction('⏱ sequence running — the clock is on your tap…');
    logStep('PRACTICE — price crossed your ' + kind.toUpperCase() + ' MARK at ' + fmtPrice(price) +
            ' → sequence: ' + steps.join(' → '));
  }

  // While a sequence waits, watch the Board journal for the tap that
  // answers it and show the reaction the journal recorded.
  function practiceWatchTap() {
    if (!practice.awaitTap) return;
    var recs = practiceReadJournal();
    var found = null;
    for (var i = 0; i < recs.length; i++) {
      var t = Date.parse((recs[i] && recs[i].t) || '');
      if (!isNaN(t) && t >= practice.awaitTap.sinceMs - 250) { found = recs[i]; break; }
    }
    if (found) {
      practice.awaitTap = null;
      if (typeof found.flashToTapMs === 'number' && isFinite(found.flashToTapMs)) {
        var word = found.flashToTapMs < 1000 ? 'sharp'
                 : found.flashToTapMs < 2000 ? 'steady' : 'good — keep tightening';
        practiceSetReaction('⚡ ' + fmtSec(found.flashToTapMs) + 's — ' + word);
        logStep('PRACTICE — your tap landed: ⚡ ' + fmtSec(found.flashToTapMs) + 's (' +
                (found.result || 'tap') + ')');
      } else {
        practiceSetReaction('⚡ tap seen — no light was lit for it (NO-LIGHT)');
        logStep('PRACTICE — tap seen, journal says NO-LIGHT (no reaction time)');
      }
      return;
    }
    if (Date.now() - practice.awaitTap.sinceMs > TAP_WAIT_MS) {
      practice.awaitTap = null;
      practiceSetReaction('no tap seen for that sequence — it stays on the practice log');
      logStep('PRACTICE — sequence timed out with no tap seen');
    }
  }

  function practiceRenderStream(s) {
    if (!streamLineEl) return;
    if (!s) {
      streamLineEl.textContent = 'no watcher stream yet — the watcher feeds me live prices';
      return;
    }
    if (typeof s.price !== 'number') {
      streamLineEl.textContent = 'stream live · price — (not readable this tick) · beat ' + fmtPrice(s.beat);
      return;
    }
    var age = (typeof s.ageMs === 'number') ? ' · stream ' + (s.ageMs / 1000).toFixed(1) + 's old' : '';
    streamLineEl.textContent = 'LIVE ' + fmtPrice(s.price) + ' · beat ' + fmtPrice(s.beat) + age +
      (s.fresh ? '' : ' · STALE — not coaching on old prices');
  }

  function practiceCheckMark(kind, mark, price, s) {
    if (typeof mark !== 'number') { practice.markSide[kind] = null; return; }
    var side = price >= mark ? 'above' : 'below';
    var prev = practice.markSide[kind];
    practice.markSide[kind] = side;
    if (prev && prev !== side) practiceRunSequence(kind, practiceSideFor(s), price);
  }

  // The 250 ms watch: read the stream, keep the marks honest, fire
  // the coach on a cross, and keep the reaction clock running. A
  // stale or missing stream never fires the coach — the baseline
  // just follows quietly until fresh prices return.
  function practiceTick() {
    if (state.panelMode !== 'practice') return;
    var s = practiceReadStream();
    practiceRenderStream(s);
    practiceWatchTap();
    if (!s || typeof s.price !== 'number') return;
    if (s.fresh) practicePrefill(s);
    var price = s.price;
    if (practice.prevPrice === null || !s.fresh) {
      practice.prevPrice = price;
      practice.markSide.buy = (typeof practice.buyMark === 'number')
        ? (price >= practice.buyMark ? 'above' : 'below') : null;
      practice.markSide.sell = (typeof practice.sellMark === 'number')
        ? (price >= practice.sellMark ? 'above' : 'below') : null;
      return;
    }
    practice.prevPrice = price;
    practiceCheckMark('buy', practice.buyMark, price, s);
    practiceCheckMark('sell', practice.sellMark, price, s);
  }

  /* ===== PRACTICE SECTION END ===== */

  /* ---------------- the panel chrome: decks, drag, resize, minimize ----
   * The header is the drag handle (the deck-switch and minimize
   * buttons inside it are press targets, never drag starts); the
   * corner grip is the resize handle. Position, size, and the
   * minimized state persist on-device. Switching decks is a hard
   * reset for the execute deck: any arm dies and DRY is restored —
   * an armed state is never inherited across the switch. */

  var panelRoot = null, headEl = null, bodyEl = null, slimEl = null,
      gripEl = null,
      modePracticeBtn = null, modeExecuteBtn = null,
      practiceSec = null, executeSec = null;
  var dragState = null;
  var resizeState = null;
  var suppressSlimPress = false;

  function renderPanelMode() {
    var prac = state.panelMode === 'practice';
    if (practiceSec) practiceSec.style.display = prac ? '' : 'none';
    if (executeSec) executeSec.style.display = prac ? 'none' : '';
    if (modePracticeBtn) modePracticeBtn.classList.toggle('bt-active', prac);
    if (modeExecuteBtn) modeExecuteBtn.classList.toggle('bt-active', !prac);
    if (slimEl) slimEl.textContent = '🎯 ' + (prac ? 'PRACTICE' : 'EXECUTE') + ' ▸';
  }

  function switchPanelMode(mode) {
    if (state.panelMode === mode) return;
    disarm('switched decks');
    clearLiveArm();
    if (state.mode !== 'DRY') {
      state.mode = 'DRY';
      renderMode();
      logStep('execute deck reset to DRY on the deck switch');
    }
    state.panelMode = mode;
    renderPanelMode();
    logStep('deck → ' + mode.toUpperCase() +
            (mode === 'practice' ? ' (coach + clock only — never presses)'
                                 : ' (execute — DRY, double-press discipline)'));
  }

  // The saved size is applied as inline style ONLY while the panel
  // is open. Minimized, the inline size is cleared so the slim bar
  // sizes itself by its class rule — the bar stays slim whatever
  // size the open panel was resized to.
  function applySize() {
    if (!panelRoot) return;
    var open = !layout.minimized;
    panelRoot.style.width = (open && layout.w !== null) ? layout.w + 'px' : '';
    panelRoot.style.height = (open && layout.h !== null) ? layout.h + 'px' : '';
  }

  function setMinimized(b, silent) {
    layout.minimized = !!b;
    if (panelRoot) panelRoot.classList.toggle('bt-min', layout.minimized);
    applySize();
    saveLayout();
    if (!silent) logStep(layout.minimized ? 'panel minimized to the slim bar' : 'panel restored from the slim bar');
  }

  function applyLayout() {
    if (!panelRoot) return;
    if (layout.x !== null && layout.y !== null) {
      panelRoot.style.left = layout.x + 'px';
      panelRoot.style.top = layout.y + 'px';
      panelRoot.style.bottom = 'auto';
    }
    panelRoot.classList.toggle('bt-min', layout.minimized);
    applySize();
  }

  function wireDrag() {
    headEl.addEventListener('pointerdown', function (ev) {
      if (ev.target && ev.target.closest &&
          ev.target.closest('button, input, select, textarea')) return;
      var rect = panelRoot.getBoundingClientRect();
      dragState = { startX: ev.clientX, startY: ev.clientY,
                    origX: rect.left, origY: rect.top, moved: false };
      panelRoot.style.left = rect.left + 'px';
      panelRoot.style.top = rect.top + 'px';
      panelRoot.style.bottom = 'auto';
      try { headEl.setPointerCapture(ev.pointerId); } catch (e) {}
    });
    headEl.addEventListener('pointermove', function (ev) {
      if (!dragState) return;
      var dx = ev.clientX - dragState.startX;
      var dy = ev.clientY - dragState.startY;
      if (Math.abs(dx) + Math.abs(dy) > 3) dragState.moved = true;
      var nx = Math.max(0, Math.min(window.innerWidth - 90, dragState.origX + dx));
      var ny = Math.max(0, Math.min(window.innerHeight - 34, dragState.origY + dy));
      panelRoot.style.left = nx + 'px';
      panelRoot.style.top = ny + 'px';
    });
    function endDrag() {
      if (!dragState) return;
      if (dragState.moved) {
        layout.x = parseInt(panelRoot.style.left, 10);
        layout.y = parseInt(panelRoot.style.top, 10);
        saveLayout();
        // A drag that ends on the slim bar must not read as its press.
        suppressSlimPress = true;
        setTimeout(function () { suppressSlimPress = false; }, 400);
      }
      dragState = null;
    }
    headEl.addEventListener('pointerup', endDrag);
    headEl.addEventListener('pointercancel', endDrag);
  }

  // The corner grip resizes the OPEN panel. Sizes are tracked in
  // CSS content-box pixels (the panel's box model), so the style
  // values saved here re-apply exactly on the next load. The grip
  // is hidden while minimized, so the slim bar can never be
  // resized. Ending a resize persists the size in the same layout
  // store as the position — one store, additive fields.
  function wireResize() {
    gripEl.addEventListener('pointerdown', function (ev) {
      if (layout.minimized) return;
      var cs = window.getComputedStyle(panelRoot);
      var rect = panelRoot.getBoundingClientRect();
      resizeState = {
        startX: ev.clientX, startY: ev.clientY,
        startW: parseFloat(cs.width) || rect.width,
        startH: parseFloat(cs.height) || rect.height,
        w: null, h: null
      };
      try { gripEl.setPointerCapture(ev.pointerId); } catch (e) {}
      ev.preventDefault();
    });
    gripEl.addEventListener('pointermove', function (ev) {
      if (!resizeState) return;
      var w = Math.round(resizeState.startW + (ev.clientX - resizeState.startX));
      var h = Math.round(resizeState.startH + (ev.clientY - resizeState.startY));
      w = Math.max(MIN_PANEL_W, Math.min(window.innerWidth, w));
      h = Math.max(MIN_PANEL_H, Math.min(window.innerHeight, h));
      panelRoot.style.width = w + 'px';
      panelRoot.style.height = h + 'px';
      resizeState.w = w;
      resizeState.h = h;
    });
    function endResize() {
      if (!resizeState) return;
      if (resizeState.w !== null && resizeState.h !== null) {
        layout.w = resizeState.w;
        layout.h = resizeState.h;
        saveLayout();
        logStep('panel resized to ' + layout.w + '×' + layout.h + ' — size saved on-device');
      }
      resizeState = null;
    }
    gripEl.addEventListener('pointerup', endResize);
    gripEl.addEventListener('pointercancel', endResize);
  }

  /* ---------------- the panel (ours only, bottom-left by default) ---- */

  var CSS = [
    '#' + ROOT_ID + '{position:fixed;left:8px;bottom:8px;z-index:2147483647;width:308px;',
    'background:rgba(11,14,20,0.94);color:#e8ecf1;border:1px solid #22303f;border-radius:10px;',
    'padding:8px 10px;font-family:Arial,Helvetica,sans-serif;-webkit-user-select:none;user-select:none;}',
    '#' + ROOT_ID + '.bt-min{width:auto;}',
    '#' + ROOT_ID + '{display:flex;flex-direction:column;}',
    '#' + ROOT_ID + ' .bt-body{flex:1 1 auto;min-height:0;overflow-y:auto;}',
    '#' + ROOT_ID + ' .bt-grip{position:absolute;right:3px;bottom:2px;width:20px;height:20px;',
    'cursor:nwse-resize;touch-action:none;color:#54687e;font-size:13px;line-height:20px;',
    'text-align:center;z-index:2;}',
    '#' + ROOT_ID + '.bt-min .bt-grip{display:none;}',
    '#' + ROOT_ID + ' .bt-head{display:flex;align-items:center;gap:6px;cursor:move;touch-action:none;}',
    '#' + ROOT_ID + ' .bt-title{font-size:12px;font-weight:bold;color:#7ee787;letter-spacing:0.5px;}',
    '#' + ROOT_ID + ' .bt-slim{display:none;font-size:13px;font-weight:bold;color:#ffd94d;letter-spacing:0.5px;}',
    '#' + ROOT_ID + '.bt-min .bt-slim{display:block;}',
    '#' + ROOT_ID + '.bt-min .bt-title,' + '#' + ROOT_ID + '.bt-min .bt-switch,' +
    '#' + ROOT_ID + '.bt-min .bt-minbtn,' + '#' + ROOT_ID + '.bt-min .bt-body{display:none;}',
    '#' + ROOT_ID + ' .bt-switch{display:flex;gap:4px;margin-left:auto;}',
    '#' + ROOT_ID + ' .bt-switch button.bt-active{background:#22303f;color:#ffd94d;border-color:#ffd94d;}',
    '#' + ROOT_ID + ' button{pointer-events:auto;padding:5px 10px;border-radius:6px;border:1px solid #22303f;',
    'background:#10151d;color:#e8ecf1;font-size:12px;font-weight:bold;cursor:pointer;}',
    '#' + ROOT_ID + ' .bt-marks{display:flex;align-items:center;gap:6px;margin-top:7px;font-size:12px;flex-wrap:wrap;}',
    '#' + ROOT_ID + ' input.bt-mark{width:92px;padding:5px 6px;border-radius:6px;border:1px solid #22303f;',
    'background:#0b0e14;color:#ffd94d;font-size:14px;font-weight:bold;}',
    '#' + ROOT_ID + ' .bt-stream{margin-top:7px;font-size:11.5px;color:#9fb4c8;line-height:1.4;}',
    '#' + ROOT_ID + ' .bt-steps{display:flex;flex-direction:column;gap:5px;margin-top:8px;}',
    '#' + ROOT_ID + ' .bt-step{border:2px solid #3a4656;border-radius:8px;padding:7px 9px;',
    'font-size:13px;font-weight:bold;color:#9fb4c8;background:#10151d;}',
    '#' + ROOT_ID + ' .bt-step.bt-on{border-color:#ffd94d;color:#fff;background:#665410;}',
    '#' + ROOT_ID + ' .bt-stepnum{display:inline-block;min-width:20px;height:20px;line-height:20px;',
    'text-align:center;border-radius:50%;background:#22303f;color:#e8ecf1;margin-right:8px;font-size:12px;}',
    '#' + ROOT_ID + ' .bt-step.bt-on .bt-stepnum{background:#ffd94d;color:#0b0e14;}',
    '#' + ROOT_ID + ' .bt-reaction{margin-top:8px;font-size:14px;font-weight:bold;color:#ffd94d;min-height:19px;}',
    '#' + ROOT_ID + ' .bt-pnote{margin-top:5px;font-size:10.5px;color:#9fb4c8;line-height:1.35;}',
    '#' + ROOT_ID + ' .bt-moderow{display:flex;align-items:center;gap:8px;margin-top:6px;}',
    '#' + ROOT_ID + ' .bt-mode{font-size:13px;font-weight:bold;}',
    '#' + ROOT_ID + ' .bt-mode.dry{color:#7ee787;}',
    '#' + ROOT_ID + ' .bt-mode.live{color:#ff7b72;}',
    '#' + ROOT_ID + ' .bt-stakerow{display:flex;align-items:center;gap:6px;margin-top:7px;font-size:12px;}',
    '#' + ROOT_ID + ' input.bt-cents{width:64px;padding:5px 6px;border-radius:6px;border:1px solid #22303f;',
    'background:#0b0e14;color:#ffd94d;font-size:15px;font-weight:bold;}',
    '#' + ROOT_ID + ' .bt-cap{font-size:10.5px;color:#9fb4c8;line-height:1.35;}',
    '#' + ROOT_ID + ' .bt-firerow{display:flex;gap:8px;margin-top:8px;}',
    '#' + ROOT_ID + ' .bt-fire{flex:1;padding:13px 4px;font-size:16px;border-radius:9px;border:3px solid #3a4656;}',
    '#' + ROOT_ID + ' .bt-fire.up{background:#14532d;color:#d3f8db;}',
    '#' + ROOT_ID + ' .bt-fire.down{background:#5c161a;color:#ffdcd8;}',
    '#' + ROOT_ID + ' .bt-fire.bt-armed{border-color:#ffd94d;background:#665410;color:#fff;animation:btPulse 0.6s infinite alternate;}',
    '@keyframes btPulse{from{filter:brightness(1);}to{filter:brightness(1.45);}}',
    '#' + ROOT_ID + ' .bt-status{margin-top:8px;font-size:12.5px;font-weight:bold;line-height:1.4;',
    'border-radius:6px;padding:5px 7px;background:#10151d;color:#c8d4e2;white-space:pre-line;}',
    '#' + ROOT_ID + ' .bt-status.bt-arm{color:#ffd94d;}',
    '#' + ROOT_ID + ' .bt-status.bt-dry{color:#7ee787;}',
    '#' + ROOT_ID + ' .bt-status.bt-live{color:#ff7b72;}',
    '#' + ROOT_ID + ' .bt-status.bt-abort{color:#fff;background:#8c1d18;font-size:14px;}',
    '#' + ROOT_ID + ' .bt-log{margin-top:7px;max-height:118px;overflow-y:auto;font-size:10.5px;',
    'line-height:1.5;color:#9fb4c8;border-top:1px solid #22303f;padding-top:5px;}',
    '#' + ROOT_ID + ' .bt-line{white-space:nowrap;overflow:hidden;text-overflow:ellipsis;}'
  ].join('\n');

  function renderMode() {
    if (!modeLine) return;
    modeLine.textContent = state.mode === 'LIVE' ? '🔴 MODE: LIVE' : '🟢 MODE: DRY (safe)';
    modeLine.className = 'bt-mode ' + (state.mode === 'LIVE' ? 'live' : 'dry');
    if (modeBtn) modeBtn.textContent = state.mode === 'LIVE' ? 'BACK TO DRY' : 'GO LIVE';
  }

  function buildPanel() {
    var style = document.createElement('style');
    style.textContent = CSS;
    (document.head || document.documentElement).appendChild(style);

    var root = document.createElement('div');
    root.id = ROOT_ID;
    panelRoot = root;

    /* ----- header: drag handle + deck switch + minimize ----- */
    headEl = document.createElement('div');
    headEl.className = 'bt-head';
    var title = document.createElement('span');
    title.className = 'bt-title';
    title.textContent = '🎯 THE TRIGGER';
    headEl.appendChild(title);
    slimEl = document.createElement('span');
    slimEl.className = 'bt-slim';
    slimEl.setAttribute('data-bt-id', 'slimBar');
    slimEl.textContent = '🎯 PRACTICE ▸';
    headEl.appendChild(slimEl);
    // Restore lives on the header, not the bar itself: the drag
    // wiring captures the pointer to the header, which retargets the
    // press's click event to the header — a bar-level listener would
    // never see it. Any header press while minimized (that was not a
    // drag) restores the panel.
    headEl.addEventListener('click', function (ev) {
      if (!layout.minimized) return;
      // The MIN button's own press bubbles here a moment after it
      // minimizes — button presses are never the bar's restore press.
      if (ev.target && ev.target.closest &&
          ev.target.closest('button, input, select, textarea')) return;
      if (suppressSlimPress) { suppressSlimPress = false; return; }
      setMinimized(false);
    });
    var switchWrap = document.createElement('span');
    switchWrap.className = 'bt-switch';
    modePracticeBtn = document.createElement('button');
    modePracticeBtn.type = 'button';
    modePracticeBtn.setAttribute('data-bt-id', 'modePractice');
    modePracticeBtn.textContent = 'PRACTICE';
    modePracticeBtn.addEventListener('click', function () { switchPanelMode('practice'); });
    modeExecuteBtn = document.createElement('button');
    modeExecuteBtn.type = 'button';
    modeExecuteBtn.setAttribute('data-bt-id', 'modeExecute');
    modeExecuteBtn.textContent = 'EXECUTE';
    modeExecuteBtn.addEventListener('click', function () { switchPanelMode('execute'); });
    switchWrap.appendChild(modePracticeBtn);
    switchWrap.appendChild(modeExecuteBtn);
    headEl.appendChild(switchWrap);
    var minBtn = document.createElement('button');
    minBtn.type = 'button';
    minBtn.className = 'bt-minbtn';
    minBtn.setAttribute('data-bt-id', 'minBtn');
    minBtn.textContent = '— MIN';
    minBtn.addEventListener('click', function () { setMinimized(true); });
    headEl.appendChild(minBtn);
    root.appendChild(headEl);
    wireDrag();

    bodyEl = document.createElement('div');
    bodyEl.className = 'bt-body';
    root.appendChild(bodyEl);

    /* ----- resize grip: the open panel's bottom-right corner ----- */
    gripEl = document.createElement('span');
    gripEl.className = 'bt-grip';
    gripEl.setAttribute('data-bt-id', 'resizeGrip');
    gripEl.setAttribute('title', 'drag to resize the panel');
    gripEl.textContent = '◢';
    root.appendChild(gripEl);
    wireResize();

    /* ----- PRACTICE deck ----- */
    practiceSec = document.createElement('div');
    practiceSec.className = 'bt-practice';
    practiceSec.setAttribute('data-bt-id', 'practiceDeck');

    var marksRow = document.createElement('div');
    marksRow.className = 'bt-marks';
    var buyLab = document.createElement('span');
    buyLab.textContent = 'BUY MARK $';
    buyMarkInput = document.createElement('input');
    buyMarkInput.className = 'bt-mark';
    buyMarkInput.setAttribute('data-bt-id', 'buyMark');
    buyMarkInput.setAttribute('type', 'text');
    buyMarkInput.setAttribute('inputmode', 'decimal');
    buyMarkInput.setAttribute('placeholder', 'beat − 25');
    buyMarkInput.addEventListener('input', function () {
      practice.touched = true;
      var v = parseFloat(String(buyMarkInput.value || '').replace(/[^0-9.]/g, ''));
      practice.buyMark = isFinite(v) ? v : null;
      practice.markSide.buy = null; // the mark moved: re-baseline, never fire
    });
    var sellLab = document.createElement('span');
    sellLab.textContent = 'SELL MARK $';
    sellMarkInput = document.createElement('input');
    sellMarkInput.className = 'bt-mark';
    sellMarkInput.setAttribute('data-bt-id', 'sellMark');
    sellMarkInput.setAttribute('type', 'text');
    sellMarkInput.setAttribute('inputmode', 'decimal');
    sellMarkInput.setAttribute('placeholder', 'beat + 25');
    sellMarkInput.addEventListener('input', function () {
      practice.touched = true;
      var v = parseFloat(String(sellMarkInput.value || '').replace(/[^0-9.]/g, ''));
      practice.sellMark = isFinite(v) ? v : null;
      practice.markSide.sell = null; // the mark moved: re-baseline, never fire
    });
    marksRow.appendChild(buyLab);
    marksRow.appendChild(buyMarkInput);
    marksRow.appendChild(sellLab);
    marksRow.appendChild(sellMarkInput);
    practiceSec.appendChild(marksRow);

    streamLineEl = document.createElement('div');
    streamLineEl.className = 'bt-stream';
    streamLineEl.setAttribute('data-bt-id', 'streamLine');
    streamLineEl.textContent = 'no watcher stream yet — the watcher feeds me live prices';
    practiceSec.appendChild(streamLineEl);

    var stepsWrap = document.createElement('div');
    stepsWrap.className = 'bt-steps';
    stepCards = [];
    var idleSteps = ['READ THE LIGHT', 'PRESS BUY —', 'SET YOUR SELL'];
    for (var si = 0; si < 3; si++) {
      var card = document.createElement('div');
      card.className = 'bt-step';
      card.setAttribute('data-bt-id', 'step' + (si + 1));
      var num = document.createElement('span');
      num.className = 'bt-stepnum';
      num.textContent = String(si + 1);
      var lab = document.createElement('span');
      lab.className = 'bt-steplabel';
      lab.textContent = idleSteps[si];
      card.appendChild(num);
      card.appendChild(lab);
      stepsWrap.appendChild(card);
      stepCards.push({ card: card, label: lab });
    }
    practiceSec.appendChild(stepsWrap);

    reactionEl = document.createElement('div');
    reactionEl.className = 'bt-reaction';
    reactionEl.setAttribute('data-bt-id', 'reaction');
    reactionEl.textContent = '';
    practiceSec.appendChild(reactionEl);

    var pnote = document.createElement('div');
    pnote.className = 'bt-pnote';
    pnote.textContent = 'PRACTICE — coach + clock only. Set your marks; when the live price crosses one, ' +
      'the steps light in order and the clock times your tap on the Board. Nothing here presses anything, ever.';
    practiceSec.appendChild(pnote);
    bodyEl.appendChild(practiceSec);

    /* ----- EXECUTE deck (the v0.1.0 trigger, unchanged) ----- */
    executeSec = document.createElement('div');
    executeSec.className = 'bt-execute';
    executeSec.setAttribute('data-bt-id', 'executeDeck');

    var modeRow = document.createElement('div');
    modeRow.className = 'bt-moderow';
    modeLine = document.createElement('span');
    modeBtn = document.createElement('button');
    modeBtn.type = 'button';
    modeBtn.setAttribute('data-bt-id', 'modeToggle');
    modeBtn.addEventListener('click', pressMode);
    modeRow.appendChild(modeLine);
    modeRow.appendChild(modeBtn);
    executeSec.appendChild(modeRow);

    var stakeRow = document.createElement('div');
    stakeRow.className = 'bt-stakerow';
    var lab2 = document.createElement('span');
    lab2.textContent = 'STAKE ¢';
    centsInput = document.createElement('input');
    centsInput.className = 'bt-cents';
    centsInput.setAttribute('data-bt-id', 'cents');
    centsInput.setAttribute('type', 'number');
    centsInput.setAttribute('min', '1');
    centsInput.setAttribute('max', String(HARD_CAP_CENTS));
    centsInput.setAttribute('step', '1');
    centsInput.value = String(state.cents);
    centsInput.addEventListener('input', function () { readStake(); });
    centsInput.addEventListener('change', function () { readStake(); });
    capNote = document.createElement('span');
    capNote.className = 'bt-cap';
    capNote.setAttribute('data-bt-id', 'capNote');
    capNote.textContent = 'cap ' + HARD_CAP_CENTS + '¢ · $0.10 pref / $0.25 std';
    stakeRow.appendChild(lab2);
    stakeRow.appendChild(centsInput);
    stakeRow.appendChild(capNote);
    executeSec.appendChild(stakeRow);

    var fireRow = document.createElement('div');
    fireRow.className = 'bt-firerow';
    fireUpBtn = document.createElement('button');
    fireUpBtn.type = 'button';
    fireUpBtn.className = 'bt-fire up';
    fireUpBtn.setAttribute('data-bt-id', 'fireUp');
    fireUpBtn.textContent = 'FIRE UP';
    fireUpBtn.addEventListener('click', function () { pressFire('up'); });
    fireDownBtn = document.createElement('button');
    fireDownBtn.type = 'button';
    fireDownBtn.className = 'bt-fire down';
    fireDownBtn.setAttribute('data-bt-id', 'fireDown');
    fireDownBtn.textContent = 'FIRE DOWN';
    fireDownBtn.addEventListener('click', function () { pressFire('down'); });
    fireRow.appendChild(fireUpBtn);
    fireRow.appendChild(fireDownBtn);
    executeSec.appendChild(fireRow);
    bodyEl.appendChild(executeSec);

    /* ----- shared status + log (both decks write here) ----- */
    statusEl = document.createElement('div');
    statusEl.className = 'bt-status';
    statusEl.setAttribute('data-bt-id', 'status');
    statusEl.textContent = 'ready — PRACTICE deck: set your marks and wait for the cross';
    bodyEl.appendChild(statusEl);

    logEl = document.createElement('div');
    logEl.className = 'bt-log';
    logEl.setAttribute('data-bt-id', 'log');
    bodyEl.appendChild(logEl);

    // Disarm discipline: a press anywhere that is not the armed
    // button's own confirming press cancels the arm. Panel-internal
    // presses are handled by the controls' own handlers (the other
    // fire button, the toggle, the stake box each reset explicitly);
    // presses out on the page land here.
    document.addEventListener('click', function (ev) {
      if (firing) return;
      var t = ev.target;
      var inPanel = false;
      var n = t;
      while (n) { if (n.id === ROOT_ID) { inPanel = true; break; } n = n.parentElement || n.parentNode || null; }
      if (!inPanel) { disarm('pressed elsewhere on the page'); clearLiveArm(); }
    }, true);
    root.addEventListener('click', function (ev) {
      if (firing) return;
      if (arm && ev.target !== fireBtn(arm.side)) disarm('pressed elsewhere on the panel');
      if (liveArm && ev.target !== modeBtn) clearLiveArm();
    });

    (document.body || document.documentElement).appendChild(root);
    renderMode();
    renderPanelMode();
    applyLayout();
    renderLog();
  }

  /* ---------------- go ---------------- */

  function start() {
    loadSettings();
    loadLog();
    loadLayout();
    buildPanel();
    if (centsInput) centsInput.value = String(state.cents);
    logStep('trigger v0.2.1 loaded — PRACTICE deck (coach only, never presses); execute deck DRY, stake ' +
            fmtMoney(state.cents) + ', hard cap ' + HARD_CAP_CENTS + '¢');
    setInterval(practiceTick, PRACTICE_POLL_MS);
    practiceTick();
  }

  // Read-only snapshot for the test harness (and David's console).
  try {
    window.BlobTriggerState = function () {
      return JSON.parse(JSON.stringify({
        cents: state.cents,
        mode: state.mode,
        panelMode: state.panelMode,
        minimized: layout.minimized,
        layout: { x: layout.x, y: layout.y, w: layout.w, h: layout.h },
        armed: arm ? { side: arm.side, cents: arm.cents } : null,
        liveArmed: !!liveArm,
        firing: firing,
        practice: {
          buyMark: practice.buyMark,
          sellMark: practice.sellMark,
          sequence: practice.seq,
          reaction: practice.reaction
        },
        log: logArr.slice(-PANEL_LOG_LINES)
      }));
    };
  } catch (e) {}

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', start);
  } else {
    start();
  }
})();
